<template>
    <aside class="collapse show collapse-horizontal col-sm-2 p-3 border-end bg-body-tertiary" id="collapseWidthExample">
      <a href="/" class="d-flex align-items-center mb-3 mb-md-0 me-md-auto link-body-emphasis text-decoration-none">
        <span class="d-print-block">
          <img src="https://www.degesch.cl/wp-content/uploads/2023/02/Logo_DD_Claim.png" alt="Detia Degesch Logo" class="logo">
        </span>
      </a>
      <hr>
      <ul class="nav nav-pills flex-column mb-auto">
        <li class="nav-item">
          <a href="#" class="nav-link link-body-emphasis" aria-current="page">
            <p class="bi bi-house-door" @click="goToInicio()"> Inicio</p>
            <p class="bi bi-speedometer2" @click="goToRoute('dashboard')"> Dashboard</p>
          </a>
        </li>
      </ul>
      <hr>
      <ul class="list-unstyled ps-0">
        <li class="mb-1">
          <button class="btn btn-toggle d-inline-flex align-items-center rounded border-0 collapsed"
            data-bs-toggle="collapse" data-bs-target="#home-collapse" aria-expanded="false">
            Formulación
          </button>
          <div class="collapse" id="home-collapse">
            <ul class="btn-toggle-nav list-unstyled fw-normal pb-1 small">
              <li><a class="link-body-emphasis d-inline-flex text-decoration-none rounded" @click="goToRoute('preparacionmezcla')">Ingreso de preparación de mezcla</a></li>
              <li><a class="link-body-emphasis d-inline-flex text-decoration-none rounded" @click="goToRoute('ingresoproductoterminado')">Ingreso de producto terminado</a></li>
              <li><a class="link-body-emphasis d-inline-flex text-decoration-none rounded" @click="goToRoute('entregaproductoterminado')">Entrega de producto terminado</a></li>
            </ul>
          </div>
        </li>
        <li class="mb-1">
          <button class="btn btn-toggle d-inline-flex align-items-center rounded border-0 collapsed"
            data-bs-toggle="collapse" data-bs-target="#dashboard-collapse" aria-expanded="false">
            Control de calidad
          </button>
          <div class="collapse" id="dashboard-collapse">
            <ul class="btn-toggle-nav list-unstyled fw-normal pb-1 small">
              <li><a class="link-body-emphasis d-inline-flex text-decoration-none rounded" @click="goToRoute('analisisparametrosquimicos')">Analizar parámetros químicos</a></li>
              <li><a class="link-body-emphasis d-inline-flex text-decoration-none rounded" @click="goToRoute('ingresoparametrosproductoterminado')">Ingreso parámetros producto terminado</a></li>
              <li><a class="link-body-emphasis d-inline-flex text-decoration-none rounded" @click="goToRoute('aprobacionproductoterminado')">Aprobación de producto terminado</a></li>
              <li><a class="link-body-emphasis d-inline-flex text-decoration-none rounded" @click="goToRoute('generarinformeautorizacionproductoterminado')">Generar Autorización Producto Terminado</a></li>
              <li><a class="link-body-emphasis d-inline-flex text-decoration-none rounded" @click="goToRoute('generarinformeautorizacionparametrosquimicos')">Generar autorización parámetros químicos</a></li>
              <li><a class="link-body-emphasis d-inline-flex text-decoration-none rounded" @click="goToRoute('generarinformerechazoproductoterminado')">Generar Rechazo Producto Terminado</a></li>
            </ul>
          </div>
        </li>
        
      </ul>
      <hr>
      <div class="dropdown">
        <a href="#" class="d-flex align-items-center link-body-emphasis text-decoration-none dropdown-toggle"
          data-bs-toggle="dropdown" aria-expanded="true">
          <i class="bi bi-person-fill me-2" style="font-size: 32px;"></i> <!-- Ícono de persona -->
          <span class="d-print-block"><strong>{{nombreUsuario}}</strong></span>
        </a>
        <ul class="dropdown-menu text-small shadow">
          <li><a class="dropdown-item" href="#">Ajustes</a></li>
          <li>
            <hr class="dropdown-divider">
          </li>
          <li>
            <button class="dropdown-item" @click="logout">Cerrar sesión</button>
          </li>
        </ul>
      </div>
    </aside>
  </template>
  
<script>
//import axios from 'axios';
  export default {
    name: 'BaseLayout',
    data() {
      return {
        nombreUsuario: localStorage.getItem('nombre_usuario'),
      };
    },
    methods: {
      goToInicio() {
        const seccionUsuario = localStorage.getItem('id_seccion_usuario');
        if (seccionUsuario === '2'){
          this.$router.push({ name: 'controlcalidad' });
        } else if (seccionUsuario === '4'){
          this.$router.push({ name: 'formulacion' });
        }
      },
      async logout() {
        try {
          const response = await this.$axios.post("private.com/logout", {}, {
            withCredentials: true
          });

          if (response.status === 200) {
            console.log("Logout exitoso");
            localStorage.removeItem('user_token');
            localStorage.removeItem('id_seccion_usuario');
            localStorage.removeItem('id_cargo_usuario');
            this.$router.push({ name: 'login' });
          }
        } catch (error) {
          console.error("Error al realizar el logout:", error);
          this.error = "Hubo un problema al cerrar sesión. Intenta nuevamente.";
        }
      },
      goToRoute(routeName) {
        this.$router.push({ name: routeName });
    },
  }
};
</script>
  
<style scoped>
/* CSS para efectos de Hover y escalar en Bootstrap 5 */
.cursor-pointer {
  cursor: pointer;
}

.hover-scale:hover {
  transform: scale(1.05);
  transition: transform 0.3s ease;
}
body {
      height: 100%;
    }

    aside {
      /* border: 1px yellow solid; */
      position: fixed;
      overflow: auto;
      height: calc(100vh - 12px);
      justify-content: flex-start;
      align-self: flex-start;

    }
    nav{
      position:sticky;
    }
    main {
      position: relative;
      overflow: visible;
      margin-left: auto;
      justify-content: flex-end;
      align-self: flex-end;
    }

    #sidebarshow {
      display: none;

    }

    @media screen and (max-width: 575px) {
      #sidebarshow {
        display: inline;
      }

      #sidebartoggle {
        display: none;
      }
    }


    .b-example-divider {
  width: 100%;
  height: 3rem;
  background-color: rgba(0, 0, 0, .1);
  border: solid rgba(0, 0, 0, .15);
  border-width: 1px 0;
  box-shadow: inset 0 .5em 1.5em rgba(0, 0, 0, .1), inset 0 .125em .5em rgba(0, 0, 0, .15);
}

.b-example-vr {
  flex-shrink: 0;
  width: 1.5rem;
  height: 100vh;
}

.bi {
  vertical-align: -.125em;
  fill: currentColor;
}

.bd-mode-toggle {
  z-index: 1500;
}

.btn-toggle {
  padding: .25rem .5rem;
  font-weight: 600;
  color: var(--bs-emphasis-color);
  background-color: transparent;
}

.btn-toggle::before {
  width: 1.25em;
  line-height: 0;
  content: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' width='16' height='16' viewBox='0 0 16 16'%3e%3cpath fill='none' stroke='rgba%280,0,0,.5%29' stroke-linecap='round' stroke-linejoin='round' stroke-width='2' d='M5 14l6-6-6-6'/%3e%3c/svg%3e");
  transition: transform .35s ease;
  transform-origin: .5em 50%;
}

[data-bs-theme="dark"] .btn-toggle::before {
  content: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' width='16' height='16' viewBox='0 0 16 16'%3e%3cpath fill='none' stroke='rgba%28255,255,255,.5%29' stroke-linecap='round' stroke-linejoin='round' stroke-width='2' d='M5 14l6-6-6-6'/%3e%3c/svg%3e");
}



.btn-toggle[aria-expanded="true"]::before {
  transform: rotate(90deg);
}

.btn-toggle-nav a {
  padding: .1875rem .5rem;
  margin-top: .125rem;
  margin-left: 1.25rem;
}
.logo {
  max-width: 100%;
  height: auto;
  margin-bottom: 20px;
  border-radius: 8px;
}

.link-body-emphasis {
  cursor: pointer; /* Esto cambia el cursor a una mano cuando se pasa por encima */
}

</style>

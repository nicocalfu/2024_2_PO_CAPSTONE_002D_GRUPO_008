// src/store/index.js

import { createStore } from 'vuex';

export default createStore({
  state: {
    sessionToken: null,  // Aquí almacenaremos el token   
  },
  mutations: {
    setToken(state, token) {
      state.sessionToken = token;  // Guardamos el token en el estado
    },
    clearToken(state) {
      state.sessionToken = null;  // Limpiamos el token
    },
  },
  actions: {
    login({ commit }, token) {
      commit('setToken', token);  // Acción para setear el token
    },
    logout({ commit }) {
      commit('clearToken');  // Acción para limpiar el token
    },
  },
  getters: {
    isAuthenticated(state) {
      return !!state.sessionToken;  // Verifica si el token está presente
    },
    getToken(state) {
      return state.sessionToken;  // Obtiene el token
    },
  },
});

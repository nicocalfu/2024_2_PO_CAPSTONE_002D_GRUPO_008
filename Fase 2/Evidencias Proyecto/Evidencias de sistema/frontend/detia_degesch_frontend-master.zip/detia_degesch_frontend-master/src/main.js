import { createApp } from 'vue'
import App from './App.vue'
import store from './store';  // Importamos el store
import router from './router'
import navigationPlugin from './plugins/navigation'; // Importamos el plugin
import 'bootstrap/dist/css/bootstrap.min.css'; // Para los estilos de Bootstrap
import 'bootstrap-icons/font/bootstrap-icons.css';
import 'bootstrap';
import Cookies from 'js-cookie'
import axios from 'axios'

// Crear la instancia de la aplicación Vue
const app = createApp(App);
console.log("Vue App iniciada");

// Configuración global de axios
axios.defaults.withCredentials = true;

// Configurar axios y Cookies globalmente
app.config.globalProperties.$axios = axios;
app.config.globalProperties.$cookies = Cookies;

app.use(store).use(router).use(navigationPlugin);
// Montar la aplicación en el DOM
app.mount('#app');
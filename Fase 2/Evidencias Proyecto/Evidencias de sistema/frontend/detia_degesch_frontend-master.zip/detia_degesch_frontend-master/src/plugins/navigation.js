export default {
  install(app) {
    // Definir la función goBackToFormulacion globalmente
    app.config.globalProperties.$goBackToFormulacion = function() {
      // Navegar a la ruta de 'formulacion' definida en vue-router
      app.config.globalProperties.$router.push({ name: 'formulacion' });
    };

    // Definir la función goBackToControlCalidad globalmente
    app.config.globalProperties.$goBackToControlCalidad = function() {
      // Navegar a la ruta de 'controlcalidad' definida en vue-router
      app.config.globalProperties.$router.push({ name: 'controlcalidad' });
    };
  }
};
  
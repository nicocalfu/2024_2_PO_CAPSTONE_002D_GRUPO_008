// src/router/index.js
import { createRouter, createWebHistory } from 'vue-router'; // Importar Vue Router
import AnalisisParametrosQuimicos from '@/views/AnalisisParametrosQuimicos.vue';
import ControlCalidad from '@/views/ControlCalidad.vue';
import GenerarInformeAutorizacionProductoTerminado from '@/views/GenerarInformeAutorizacionProductoTerminado.vue';
import IngresoParametrosProductoTerminado from '@/views/IngresoParametrosProductoTerminado.vue';
import Register from '@/views/Register.vue';
import AprobacionProductoTerminado from '@/views/AprobacionProductoTerminado.vue';
import EntregaProductoTerminado from '@/views/EntregaProductoTerminado.vue';
import GenerarInformeRechazoProductoTerminado from '@/views/GenerarInformeRechazoProductoTerminado.vue';
import IngresoProductoTerminado from '@/views/IngresoProductoTerminado.vue';
import ConsultarEstadoAnalisisLote from '@/views/ConsultarEstadoAnalisisLote.vue';
import Formulacion from '@/views/Formulacion.vue';
//import Home from '@/views/Home.vue';
import Login from '@/views/Login.vue';
import ConsultarOrdenTrabajo from '@/views/ConsultarOrdenTrabajo.vue';
import GenerarInformeAutorizacionParametrosQuimicos from '@/views/GenerarInformeAutorizacionParametrosQuimicos.vue';
import IngresoGranulo from '@/views/IngresoGranulo.vue';
import PreparacionMezcla from '@/views/PreparacionMezcla.vue';
import Dashboard from '@/views/Dashboard.vue';

// Definir las rutas
const routes = [
  {
    path: '/analisisparametrosquimicos',
    name: 'analisisparametrosquimicos',
    component: AnalisisParametrosQuimicos,
    meta: { requiresAuth: true, idRequiredSection: 2, idRequiredRole: 18, title: 'Analisis parametros quimicos' }
  },
  {
    path: '/controlcalidad',
    name: 'controlcalidad',
    component: ControlCalidad,
    meta: { requiresAuth: true, idRequiredSection: 2, idRequiredRole: 18, title: 'Control de calidad' }
  },
  {
    path: '/generarinformeautorizacionproductoterminado',
    name: 'generarinformeautorizacionproductoterminado',
    component: GenerarInformeAutorizacionProductoTerminado,
    meta: { requiresAuth: true, idRequiredSection: 2, idRequiredRole: 18, title: 'Generar informe autorizacion producto terminado' }
  },
  {
    path: '/ingresoparametrosproductoterminado',
    name: 'ingresoparametrosproductoterminado',
    component: IngresoParametrosProductoTerminado,
    meta: { requiresAuth: true, idRequiredSection: 2, idRequiredRole: 18, title: 'Ingreso parametros producto terminado' }
  },
  {
    path: '/register',
    name: 'register',
    component: Register,
  },
  {
    path: '/aprobacionproductoterminado',
    name: 'aprobacionproductoterminado',
    component: AprobacionProductoTerminado,
    meta: { requiresAuth: true, idRequiredSection: 2, idRequiredRole: 18, title: 'Aprobación de producto terminado' }
  },
  {
    path: '/entregaproductoterminado',
    name: 'entregaproductoterminado',
    component: EntregaProductoTerminado,
    meta: { requiresAuth: true, idRequiredSection: 4, idRequiredRole: 13, title: 'Entrega producto terminado' }
  },
  {
    path: '/generarinformerechazoproductoterminado',
    name: 'generarinformerechazoproductoterminado',
    component: GenerarInformeRechazoProductoTerminado,
    meta: { requiresAuth: true, idRequiredSection: 2, idRequiredRole: 18, title: 'Generar informe rechazo producto terminado' }
  },
  {
    path: '/ingresoproductoterminado',
    name: 'ingresoproductoterminado',
    component: IngresoProductoTerminado,
    meta: { requiresAuth: true, idRequiredSection: 4, idRequiredRole: 13, title: 'Ingreso producto terminado' }
  },
  {
    path: '/consultarestadoanalisislote',
    name: 'consultarestadoanalisislote',
    component: ConsultarEstadoAnalisisLote,
  },
  {
    path: '/formulacion',
    name: 'formulacion',
    component: Formulacion,
    meta: { requiresAuth: true, idRequiredSection: 4, idRequiredRole: 13, title: 'Formulación' }
  },
  {
    path: '/',           // La ruta raíz
    redirect: '/login',  // Redirige a '/login'
  },
  {
    path: '/login',
    name: 'login',
    component: Login,
    meta: { title: 'Iniciar Sesión' }
  },
  {
    path: '/consultarordentrabajo',
    name: 'consultarordentrabajo',
    component: ConsultarOrdenTrabajo,
    meta: { requiresAuth: true, idRequiredSection: 4, idRequiredRole: 13 }
  },
  {
    path: '/generarinformeautorizacionparametrosquimicos',
    name: 'generarinformeautorizacionparametrosquimicos',
    component: GenerarInformeAutorizacionParametrosQuimicos,
    meta: { requiresAuth: true, idRequiredSection: 2, idRequiredRole: 18, title: 'Generar informe autorizacion parametros quimicos' }
  },
  {
    path: '/ingresogranulo',
    name: 'ingresogranulo',
    component: IngresoGranulo,
    meta: { requiresAuth: true, idRequiredSection: 4, idRequiredRole: 13 }
  },
  {
    path: '/preparacionmezcla',
    name: 'preparacionmezcla',
    component: PreparacionMezcla,
    meta: { requiresAuth: true, idRequiredSection: 4, idRequiredRole: 13, title: 'Preparación de mezcla' }
  },
  {
    path: '/dashboard',
    name: 'dashboard',
    component: Dashboard,
    meta: { title: 'Dashboard' }
  },
];

// Crear el enrutador
const router = createRouter({
  history: createWebHistory(), // Usar historial estándar
  routes, // Rutas definidas
});

router.beforeEach((to, from, next) => {
  const token = localStorage.getItem('user_token');
  const idSeccion = parseInt(localStorage.getItem('id_seccion_usuario'), 10);
  const idCargo = parseInt(localStorage.getItem('id_cargo_usuario'), 10);

  document.title = to.meta.title || ' ';

  // Comprobamos si la ruta requiere autenticación
  if (to.matched.some(record => record.meta.requiresAuth)) {
    // Comprobar si no hay token
    if (!token) {
      alert('No estás autenticado. Redirigiendo al login...');
      return next({ name: 'login' });
    }

    // Verificar si el usuario tiene permisos según su seccion y cargo
    const idRequiredSection = to.meta.idRequiredSection;
    const idRequiredRole = to.meta.idRequiredRole;

    if (idRequiredSection && idRequiredRole) {
      if (idSeccion !== idRequiredSection || idCargo !== idRequiredRole) {
        alert('No tienes permisos para acceder a esta sección.');
        //return next({ name: 'login' });  // Redirige a login si no tiene los permisos adecuados
        if (idSeccion === 2){
          return next({ name: 'controlcalidad' });
        } else if (idSeccion === 4){
          return next({ name: 'formulacion' });
        }
      }
    }

    next();  // Si todo está bien, permitir la navegación
  } else {
    next();  // Permite la navegación si no requiere autenticación
  }
});

// Exportar el enrutador como exportación por defecto
export default router;

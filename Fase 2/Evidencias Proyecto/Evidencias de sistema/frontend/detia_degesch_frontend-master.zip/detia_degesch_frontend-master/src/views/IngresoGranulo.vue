<template>
  <div class="granulo-container">
    <div class="top-bar">
      <img src="https://www.degesch.cl/wp-content/uploads/2023/02/Logo_DD_Claim.png" alt="Detia Degesch Logo" class="logo">
      <h1>Ingresar Stock Granulo</h1>
    </div>
    <form class="granulo-form" @submit.prevent="ingresarLote">
      <label>Ingrese Número de Lote:</label>
      <input type="text" v-model="numeroLote" placeholder="Ingrese el número de lote">
      <button type="submit" class="add-lote-button">Ingresar Lote</button>
    </form>
    <button class="back-button" @click="$goBackToFormulacion()">Volver</button>
  </div>
</template>

<script>
export default {
  data() {
    return {
      numeroLote: ''
    };
  },
  methods: {
    ingresarLote() {
      if (this.numeroLote) {
        alert(`Lote ${this.numeroLote} ingresado (funcionalidad no implementada).`);
        this.numeroLote = '';
      }
    },
    goToRoute(routeName) {
      this.$router.push({ name: routeName });
    },
  }
};
</script>

<style scoped>
.granulo-container {
  background-color: #fff;
  padding: 20px;
  border-radius: 10px;
  box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
  width: 600px;
  margin: 20px auto;
  text-align: center;
  font-family: 'Arial', sans-serif;
}
.top-bar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  background-color: #007BFF;
  padding: 10px 20px;
  border-radius: 10px 10px 0 0;
  color: white;
}
.logo {
  max-width: 100px;
  height: auto;
}
h1 {
  margin: 0;
  font-size: 24px;
}
.granulo-form {
  margin-top: 20px;
}
label {
  display: block;
  margin-bottom: 8px;
  font-weight: bold;
  color: #555;
}
input {
  width: 100%;
  padding: 10px;
  margin-bottom: 15px;
  border: 1px solid #ccc;
  border-radius: 5px;
  box-sizing: border-box;
  transition: border-color 0.3s;
}
input:focus {
  border-color: #007BFF;
}
.add-lote-button {
  width: 100%;
  padding: 12px;
  background-color: #e74c3c;
  color: white;
  border: none;
  border-radius: 5px;
  cursor: pointer;
  font-weight: bold;
  transition: background-color 0.3s;
}
.add-lote-button:hover {
  background-color: #c0392b;
}
.back-button {
  width: 100%;
  padding: 12px;
  background-color: #DC3545;
  color: white;
  border: none;
  border-radius: 5px;
  cursor: pointer;
  font-weight: bold;
  transition: background-color 0.3s;
  margin-top: 20px;
}
.back-button:hover {
  background-color: #c82333;
}
</style>

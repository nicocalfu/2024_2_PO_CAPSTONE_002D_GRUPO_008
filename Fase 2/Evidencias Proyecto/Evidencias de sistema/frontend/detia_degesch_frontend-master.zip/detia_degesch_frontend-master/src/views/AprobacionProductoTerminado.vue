<template>
  <BaseLayout>
  </BaseLayout>
  <main class="col-sm-10 bg-body-tertiary" id="main">
    <div class="container-fluid">
      <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom" id="title">
          <h1 class="h2">Aprobación de producto terminado</h1>
      </div>
        <div class="mezcla-container container bg-light p-4 shadow-sm rounded">
          <div class="sample-section mt-4">
            <div class="container mt-5">

              <div class="d-flex justify-content-center">
                <div class="column col-md-4">
                  <label for="numeroLote" class="form-label">Ingrese Número de Lote:</label>
                  <input type="text" id="numeroLote" v-model="numeroLote" class="form-control mb-3"/>
                  <button type="button" class="btn btn-primary w-100" @click.prevent="obtenerMuestra">Seleccionar Lote</button>
                </div>
              </div>

              <br/><br/>
              <div class="d-flex justify-content-center">
                <div class="column col-md-6">
                      <div class="card">
                        <h5 class="card-header">Información del lote</h5>
                        <div class="card-body">
                          <p class="card-text"><strong>Fecha de Análisis:</strong> {{fechaAnalisis}} </p>
                          <p class="card-text"> <strong>Formato:</strong> {{formato}} </p>
                          <p class="card-text"> <strong>Operadores:</strong> {{operadores}} </p>
                          <p class="card-text"> <strong>Máquinas:</strong> {{maquinas}} </p>
                          <p class="card-text"> <strong>Cantidad Producida:</strong> {{cantidadProducida}} </p>
                          <p class="card-text"> <strong>Promedio Gramos Peso Neto:</strong> {{calcularPromedio(pesosNetos)}} </p>
                          <p class="card-text"> <strong>Promedio Fracturado: </strong> {{calcularPromedio(fracturados)}} </p>
                          <p class="card-text"> <strong>Promedio Gramos Polvo:</strong> {{calcularPromedio(polvos)}} </p>
                          <p class="card-text"> <strong>Promedio Peso Tabletas:</strong> {{calcularPromedio(pesosTabletas)}} </p>
                          <p class="card-text"> <strong>Promedio Dureza Tabletas:</strong> {{calcularPromedio(durezasTabletas)}} </p>
                        </div>
                      </div>
                </div>
              </div>

              <br/><br/>
              <div class="d-flex justify-content-center">
                  <!-- Recorremos las muestras con un v-for -->
                  <div
                    class="col-12 col-md-6 col-lg-3 mb-4 mb-lg-0"
                    v-for="(muestra, index) in muestras" :key="muestra.id" >
                    <div class="card">
                      <h5 class="card-header">Muestra {{ index + 1 }}</h5>
                      <div class="card-body">
                        <p class="card-text"><strong>Peso Neto:</strong> {{ muestra.pesoNeto }}</p>
                        <p class="card-text"><strong>Fracturado:</strong> {{ muestra.fracturado }}</p>
                        <p class="card-text"><strong>Polvo:</strong> {{ muestra.polvo }}</p>
                        <p class="card-text"><strong>Promedio peso tableta:</strong> {{ muestra.promedioPesoTableta }}</p>
                        <p class="card-text"><strong>Promedio dureza tableta:</strong> {{ muestra.promedioDurezaTableta }}</p>
                      </div>
                    </div>
                  </div>
              </div>

            </div>
          </div>
        </div>
      </div>

      <br/>
      <div class="container-fluid">
        <div class="mezcla-container container bg-light p-4 shadow-sm rounded">
          <h3 class="mb-4">Registrar determinación</h3>
          <div class="sample-section mt-4">
            <div class="container mt-5">

              <div class="row">
                <!-- Creacion de estructura de ingreso de filas y columnas -->
                <div class="row g-4 mb-4">
                  <!-- Columnas que van a la izquierda -->
                  <div class="col-md-6">
                    <div class="p-4 bg-light shadow-sm rounded">
                      <!-- Creacion de ingreso de datos -->
                      <div class="mb-3">
                        <label for="determinacion">Determinacion</label>
                        <select id="determinacion" v-model="id_determinacion" class="form-select">
                            <option v-for="determinacion in determinaciones" :key="determinacion.id" :value="determinacion.id">
                            {{ determinacion.nombre }}
                            </option>
                        </select>
                      </div>

                      <!-- Creacion de ingreso de datos -->
                      <div class="mb-3">
                        <div v-if="id_determinacion === 1 || id_determinacion === 2">
                          <label for="cantidad_aprobada">Cantidad aprobada:</label>
                          <input type="text" id="cantidad_aprobada" v-model="cantidadAprobada" placeholder="Ingrese la cantidad" class="form-control mb-3">
                        </div>
                      </div>

                      <div class="mb-3">
                        <div v-if="id_determinacion === 2 || id_determinacion === 3">
                          <label for="cantidad_rechazada">Cantidad rechazada:</label>
                          <input type="text" id="cantidad_rechazada" v-model="cantidadRechazada" placeholder="Ingrese la cantidad" class="form-control mb-3">
                        </div>
                      </div>

                    </div>
                  </div>
                  <!-- Columnas que van a la derecha -->
                  <div class="col-md-6">
                    <div class="p-4 bg-light shadow-sm rounded">

                      <!-- Creacion de ingreso de datos -->
                      <div class="mb-3">
                        <div v-if="id_determinacion === 2 || id_determinacion === 3">
                          <label for="causa_rechazo">Causa rechazo:</label>
                          <input type="text" id="causa_rechazo" v-model="causaRechazo" placeholder="Describa la causa del rechazo" class="form-control mb-3">
                        </div>
                      </div>

                      <!-- Creacion de ingreso de datos -->
                      <div class="mb-3">
                        <div v-if="id_determinacion === 1 || id_determinacion === 2">
                          <label for="numero_autorizacion">Número autorización:</label>
                          <input type="text" id="numero_autorizacion" v-model="numeroAutorizacion" placeholder="Ingrese el número de autorizacion" class="form-control mb-3">
                        </div>
                      </div>

                      <!-- Creacion de ingreso de datos -->
                      <div class="mb-3">
                        <div v-if="id_determinacion === 2 || id_determinacion === 3">
                          <label for="numero_rechazo">Número rechazo:</label>
                          <input type="text" id="numero_rechazo" v-model="numeroRechazo" placeholder="Ingrese el número de rechazo" class="form-control mb-3">
                        </div>
                      </div>
                      
                    </div>
                  </div>

                </div>
              </div>

              <div class="container mt-4">
                <!-- Contenedor flex con botones separados -->
                <div class="d-flex justify-content-between">
                  <!-- Botón de Cancelar alineado a la izquierda -->
                  <button type="submit" class="btn btn-lg btn-secondary" @click="$goBackToControlCalidad()">
                      <i class="bi bi-backspace-fill"></i> Volver
                  </button>
                  <!-- Botón de Guardar alineado a la derecha -->
                  <button type="submit" class="btn btn-lg btn-primary" @click="guardarAutorizacion">
                    <i class="bi bi-save"></i> Guardar
                  </button>
                </div>
              </div>

            </div>
          </div>
        </div>
      </div>

      <br/>
      <div class="container-fluid">
        <div class="mezcla-container container bg-light p-4 shadow-sm rounded">
          <h3 class="mb-4">Busqueda de lotes por fecha de producción</h3>
          <div class="sample-section mt-4">
          <br>
          <div class="container mt-4">
            <div class="sample-section">
              <div class="row mb-4">
                <div class="col-md-5">
                  <label for="fecha_inicio" class="form-label">Fecha de inicio:</label>
                  <input type="date" id="fecha_inicio" v-model="fechaInicio" class="form-control" />
                </div>
                <div class="col-md-5">
                  <label for="fecha_termino" class="form-label">Fecha de término:</label>
                  <input type="date" id="fecha_termino" v-model="fechaTermino" class="form-control" />
                </div>
                <div class="col-md-2 d-flex align-items-end">
                  <button class="btn btn-primary w-100" @click="obtenerLotes">🔍</button>
                </div>
              </div>
            </div>
    
    
    <!-- Tabla de lotes -->
            <div class="container mt-5">
              <div class="table-responsive">
                <table class="table table-bordered table-hover">
                  <thead>
                    <tr>
                      <th scope="col">N° de Lote</th>
                      <th scope="col">Estado Análisis Lote</th>
                      <th scope="col">Fecha Producción</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr
                      v-for="lote in lotes"
                      :key="lote.nro_lote"
                      @click="seleccionarFila(lote)"
                      :class="{ 'table-primary': loteSeleccionado === lote.nro_lote }">
                      <td>{{ lote.nro_lote }}</td>
                      <td>{{ lote.estado }}</td>
                      <td>{{ lote.fecha_produccion }}</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
          </div>
        </div>
      </div>

  </main>
</template>

<script>
import axios from 'axios';
import BaseLayout from '@/layouts/BaseLayout.vue';
export default {
  name: 'AprobacionProductoTerminado',
  components: {
    BaseLayout
  },
  data() {
    return {
      determinaciones: [],
      id_determinacion: '',
      fechaAnalisis: '',
      formato: '',
      operadores: '',
      maquinas: '',
      cantidadProducida: '',
      fracturados: [],
      pesosNetos: [],
      polvos: [],
      pesosTabletas: [],
      durezasTabletas: [],
      muestras: [
        {
          id: 1,
          fracturado: '',
          pesoNeto: '',
          polvo: '',
          promedioPesoTableta: '',
          promedioDurezaTableta: '',
        },
        {
          id: 2,
          fracturado: '',
          pesoNeto: '',
          polvo: '',
          promedioPesoTableta: '',
          promedioDurezaTableta: '',
        },
        {
          id: 3,
          fracturado: '',
          pesoNeto: '',
          polvo: '',
          promedioPesoTableta: '',
          promedioDurezaTableta: '',
        }
      ],
      responseMuestra: '',
      // fracturado: '',
      numeroAutorizacion: '',
      cantidadAprobada: '',
      numeroRechazo: '',
      cantidadRechazada: '',
      causaRechazo: '',
      numeroLote: '',
      fechaInicio: '',
      fechaTermino: '',
      lotes: [],
      loteSeleccionado: null
    };
  },
  methods: {
    async guardarAutorizacion() {
      try {
        let datosLote;
        if (this.id_determinacion === 1) {
          datosLote = {
            nro_lote: String(this.numeroLote),
            id_determinacion: 1, 
            numero_autorizacion: parseInt(this.numeroAutorizacion), 
            cantidad_aprobada: parseInt(this.cantidadAprobada)
          };
        }
        else if (this.id_determinacion === 2) {
          datosLote = {
            nro_lote: String(this.numeroLote),
            id_determinacion: 2, 
            numero_autorizacion: parseInt(this.numeroAutorizacion), 
            cantidad_aprobada: parseInt(this.cantidadAprobada), 
            numero_rechazo: parseInt(this.numeroRechazo), 
            cantidad_rechazada: parseInt(this.cantidadRechazada), 
            causa: String(this.causaRechazo)
          };
        }
        else if (this.id_determinacion === 3) {
          datosLote = {
            nro_lote: String(this.numeroLote),
            id_determinacion: 3, 
            numero_rechazo: parseInt(this.numeroRechazo), 
            cantidad_rechazada: parseInt(this.cantidadRechazada), 
            causa: String(this.causaRechazo)
          };
        }

        const response = await axios.post('https://private.com/addAutorizacionProductoTerminado', datosLote);

        if (response.data.status === true) {
          alert('Lote guardado exitosamente');
        } else {
          alert(`Error: ${response.data.message}`);
        }
      } catch (error) {
        console.error('Error al guardar la determinacion:', error);
        alert('Hubo un error al guardar la determinacion. Intenta nuevamente.');
      }
    },
    async obtenerMuestra() {
      for (let i = 1; i <= 3; i++) {
      // Aquí se puede hacer algo asincrónico por cada iteración
        try {
          const response = await axios.get('https://private.com/listPromedioMuestra', {
            params: {
              nro_lote: this.numeroLote,
              nro_muestra: i
            }
          });
          if (response.data.status === false) {
            alert(`Error: ${response.data.message}`);
            return(response.data.message);
          } else {
            this.responseMuestra = response.data.data;
            //this.fracturado = this.muestra.fracturado;
            this.fracturados.push(parseInt(this.responseMuestra.fracturado));
            this.pesosNetos.push(parseInt(this.responseMuestra.peso_neto));
            this.polvos.push(parseInt(this.responseMuestra.polvo));
            this.pesosTabletas.push(parseInt(this.responseMuestra.promedio_peso_tableta));
            this.durezasTabletas.push(parseInt(this.responseMuestra.promedio_dureza_tableta));
            this.fechaAnalisis = this.responseMuestra.fecha;
            this.formato = this.responseMuestra.nombre_producto;
            this.operadores = this.responseMuestra.operadores;
            this.maquinas = this.responseMuestra.maquinas;
            this.cantidadProducida = this.responseMuestra.cantidad;

            this.actualizarMuestraPorId(i, {fracturado: this.responseMuestra.fracturado, pesoNeto: this.responseMuestra.peso_neto,
              polvo: this.responseMuestra.polvo, promedioPesoTableta: this.responseMuestra.promedio_peso_tableta,
              promedioDurezaTableta: this.responseMuestra.promedio_dureza_tableta
            });
          }
        } catch (error) {
          console.error('Error al obtener la muestra:', error);
        }
      }
    },
    calcularPromedio(arreglo) {
      // Verificar que el arreglo no esté vacío
      if (arreglo.length === 0) {
        return ''; // Si el arreglo está vacío, devolvemos 0
      }
      const suma = arreglo.reduce((acumulado, numero) => acumulado + numero, 0);
      return (suma / arreglo.length).toFixed(2);
    },
    actualizarMuestraPorId(id, nuevosValores) {
      // Usamos find() para encontrar la muestra por su id
      const muestra = this.muestras.find(muestra => muestra.id === id);

      // Si la muestra existe, actualizamos el valor de polvo
      if (muestra) {
        Object.assign(muestra, nuevosValores);
        //muestra.fracturado = nuevosValores;
      }
    },
    async obtenerLotes() {
      try {
        const response = await axios.get('https://private.com/listProductoTerminado', {
          params: {
            start_date: this.fechaInicio,
            end_date: this.fechaTermino
          }
        });
        this.lotes = response.data;
      } catch (error) {
        console.error('Error al obtener los lotes:', error);
      }
    },
    seleccionarFila(lote) {
      this.loteSeleccionado = this.loteSeleccionado === lote.nro_lote ? null : lote.nro_lote;
      this.numeroLote = lote.nro_lote;
    },
    $goBackToControlCalidad() {
      this.$router.push({ name: 'controlcalidad' });
    },
    goToRoute(routeName) {
      this.$router.push({ name: routeName });
    },
    async obtenerDeterminacion() {
      try {
        const response = await axios.get('https://private.com/listDeterminacion');
        this.determinaciones = response.data; 
      } catch (error) {
        console.error('Error al obtener los tipo de determinacion:', error);
      }
    },
  },
  created() {
    this.obtenerDeterminacion();
  },
};
</script>

<style scoped>
/* CSS para efectos de Hover y escalar en Bootstrap 5 */
.cursor-pointer {
  cursor: pointer;
}

.hover-scale:hover {
  transform: scale(1.05);
  transition: transform 0.3s ease;
}
body {
      height: 100%;
    }

    aside {
      /* border: 1px yellow solid; */
      position: fixed;
      overflow: auto;
      height: calc(100vh - 12px);
      justify-content: flex-start;
      align-self: flex-start;

    }
    nav{
      position:sticky;
    }
    main {
      position: relative;
      overflow: visible;
      margin-left: auto;
      justify-content: flex-end;
      align-self: flex-end;
    }

    #sidebarshow {
      display: none;

    }

    @media screen and (max-width: 575px) {
      #sidebarshow {
        display: inline;
      }

      #sidebartoggle {
        display: none;
      }
    }


    .b-example-divider {
  width: 100%;
  height: 3rem;
  background-color: rgba(0, 0, 0, .1);
  border: solid rgba(0, 0, 0, .15);
  border-width: 1px 0;
  box-shadow: inset 0 .5em 1.5em rgba(0, 0, 0, .1), inset 0 .125em .5em rgba(0, 0, 0, .15);
}

.b-example-vr {
  flex-shrink: 0;
  width: 1.5rem;
  height: 100vh;
}

.bi {
  vertical-align: -.125em;
  fill: currentColor;
}

.bd-mode-toggle {
  z-index: 1500;
}

.btn-toggle {
  padding: .25rem .5rem;
  font-weight: 600;
  color: var(--bs-emphasis-color);
  background-color: transparent;
}

.btn-toggle::before {
  width: 1.25em;
  line-height: 0;
  content: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' width='16' height='16' viewBox='0 0 16 16'%3e%3cpath fill='none' stroke='rgba%280,0,0,.5%29' stroke-linecap='round' stroke-linejoin='round' stroke-width='2' d='M5 14l6-6-6-6'/%3e%3c/svg%3e");
  transition: transform .35s ease;
  transform-origin: .5em 50%;
}

[data-bs-theme="dark"] .btn-toggle::before {
  content: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' width='16' height='16' viewBox='0 0 16 16'%3e%3cpath fill='none' stroke='rgba%28255,255,255,.5%29' stroke-linecap='round' stroke-linejoin='round' stroke-width='2' d='M5 14l6-6-6-6'/%3e%3c/svg%3e");
}



.btn-toggle[aria-expanded="true"]::before {
  transform: rotate(90deg);
}

.btn-toggle-nav a {
  padding: .1875rem .5rem;
  margin-top: .125rem;
  margin-left: 1.25rem;
}
.logo {
  max-width: 100%;
  height: auto;
  margin-bottom: 20px;
  border-radius: 8px;
}
</style>

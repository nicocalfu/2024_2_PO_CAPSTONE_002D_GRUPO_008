<template>
  <BaseLayout>
  </BaseLayout>
  <main class="col-sm-10 bg-body-tertiary" id="main">
    <div class="container-fluid">
      <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom" id="title">
        <h1 class="h2">Análisis parametros quimicos</h1>
      </div>

      <div>
        <!-- Modal -->
        <div v-if="modalVisible" class="modal fade show" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
          <!-- Usamos modal-dialog-centered para centrar el modal verticalmente -->
          <div class="modal-dialog modal-dialog-centered" style="max-width: 90%; margin: auto;">
            <div class="modal-content">
              <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Edición de Analisis de Parámetros Quimicos</h5>
                <button type="button" class="btn-close" @click="cerrarModal" data-bs-dismiss="modal" aria-label="Close"></button>
              </div>
              <div class="modal-body">
                <!-- Contenedor de tabla que se adapta sin barra de desplazamiento horizontal -->
                <div class="table-responsive">
                  <table class="table table-striped">
                    <thead>
                      <tr>
                        <th>Fecha Análisis</th>
                        <th>Aprobada</th>
                        <th>NH4</th>
                        <th>AIP</th>
                        <th>Observaciones</th>
                        <th>Acciones</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr v-for="lote in lotesParaEdicion" :key="lote.nro_lote">
                        <td><input v-model="lote.fecha" type="date" class="form-control" /></td>
                        <td><input v-model="lote.aprobada" type="text" class="form-control" /></td>
                        <td><input v-model="lote.NH4" type="text" class="form-control" /></td>
                        <td><input v-model="lote.AIP" type="text" class="form-control" /></td>
                        <td><input v-model="lote.observaciones" type="number" class="form-control" /></td>
                        <td>
                          <button @click="guardarRegistro(lote)" class="btn btn-primary">Guardar</button>
                          <button @click="eliminarRegistro(lote)" class="btn btn-danger">Eliminar</button>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
              <!-- Footer sin uso 
              <div class="modal-footer">
                <button @click="cerrarModal" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
              </div>
              -->
            </div>
          </div>
        </div>
      </div>



      

      <div class="row">
        
        <!-- Formulario de análisis -->
    <div class="row g-4 mb-4">
      <!-- Sección de formulario principal -->
      <div class="col-md-6">
        <div class="p-4 bg-light shadow-sm rounded">
          <div class="mb-3">
            <label for="numeroLote" class="form-label">Número de Lote</label>
            <input type="text" id="numeroLote" v-model="numeroLote" class="form-control">
          </div>

          <div class="mb-3">
            <label for="fechaAnalisis" class="form-label">Fecha Análisis</label>
            <input type="date" id="fechaAnalisis" v-model="fechaAnalisis" class="form-control">
          </div>

          <div class="mb-3">
            <label for="porcentajeAIP" class="form-label">% AIP</label>
            <input type="text" id="porcentajeAIP" v-model="AIP" class="form-control">
          </div>

          <div class="mb-3">
            <label for="porcentajeNH4" class="form-label">% NH4</label>
            <input type="text" id="porcentajeNH4" v-model="NH4" class="form-control">
          </div>

          <div class="mb-3 form-check">
            <input type="checkbox" id="aprobada" v-model="aprobada" class="form-check-input">
            <label for="aprobada" class="form-check-label">Aprobada</label>
          </div>
        </div>
      </div>

      <!-- Sección de observaciones y botón de guardar -->
      <div class="col-md-6">
        <div class="p-4 bg-light shadow-sm rounded">
          <div class="mb-3">
            <label for="observaciones" class="form-label">Observaciones</label>
            <textarea id="observaciones" v-model="observaciones" class="form-control" rows="4"></textarea>
          </div>
          <!--<button class="btn btn-primary w-100" @click="guardarAnalisisMezcla">Guardar</button>-->
            <button type="submit" class="btn btn-lg btn-primary" @click="guardarAnalisisMezcla">
              <i class="bi bi-save"></i> Guardar
            </button>
        </div>
      </div>
    </div>

    <hr class="hr" />
    <div class="search-section mb-4">
      <h3>Busqueda de mezclas por fecha de producción</h3>
        <div class="d-flex gap-3">
          <div class="form-group">
            <label for="fecha_inicio">Fecha de inicio:</label>
            <input type="date" id="fecha_inicio" v-model="fechaInicio" class="form-control">
          </div>
          <div class="form-group">
            <label for="fecha_termino">Fecha de termino:</label>
            <input type="date" id="fecha_termino" v-model="fechaTermino" class="form-control">
          </div>
            <button class="btn btn-info align-self-end" @click="obtenerLotes">🔍</button>
          </div>
    </div>
    
    
    <!-- Tabla de resultados -->
    <div class="table-responsive mt-5">
      <table class="table table-bordered table-striped">
        <thead>
          <tr>
            <th scope="col">N° de Lote</th>
            <th scope="col">Estado Análisis Mezcla</th>
            <th scope="col">Fecha Producción</th>
            <th scope="col"></th>
          </tr>
        </thead>
        <tbody>
          <tr
            v-for="lote in lotes"
            :key="lote.nro_lote"
            @click="seleccionarFila(lote)"
            :class="{ 'table-primary': loteSeleccionado === lote.nro_lote }">
            <td>{{ lote.nro_lote }}</td>
            <td>{{ transformarAprobacion(lote.aprobada) }}</td>
            <td>{{ lote.fecha }}</td>
            <td><button @click="abrirModal" class="bi bi-pencil-fill"></button></td>
          </tr>
        </tbody>
      </table>
    </div>

        <div class="container">
          <div class="row justify-content-center">
            <div class="col-md-6 col-12">
              <div class="form-container mt-4">
                <button class="btn btn-secondary w-100 mt-4" @click="$goBackToControlCalidad()">
                  <i class="bi bi-backspace-fill"></i> Volver
                </button>
              </div>
            </div>
          </div>
        </div>
        
      </div>
    </div>
  </main>
</template>

<script>
import axios from 'axios';
import BaseLayout from '@/layouts/BaseLayout.vue';
export default {
  components: {
    BaseLayout
  },
  data() {
    return {

      modalVisible: false,
      lotesParaEdicion: [],
      codProductoEdicion: '',


      lotes: [], // Lista de lotes que se llenará con la respuesta de la API
      fechaInicio: '',
      fechaTermino: '',
      numeroLote: '',
      fechaAnalisis: '',
      AIP: '',
      NH4: '',
      observaciones: '',
      aprobada: null,
      loteSeleccionado: null,
    };
  },
  methods: {


    async abrirModal() {
      // Primero, obtenemos los lotes para edición
      await this.obtenerLotesParaEdicion();

      // Luego verificamos si hay lotes disponibles
      if (this.lotesParaEdicion && this.lotesParaEdicion.length > 0) {
        // Si los lotes están listos, entonces mostramos el modal
        this.modalVisible = true;
      } else {
        // Si no hay lotes, puedes manejar el error o mostrar un mensaje
        console.log('No hay lotes para edición.');
      }
    },
    // Función para cerrar el modal
    cerrarModal() {
      this.lotesParaEdicion = [];
      this.modalVisible = false;
    },
    async obtenerLotesParaEdicion() {
      try {
        const response = await axios.get('https://private.com/listLoteAnalisisParametrosQuimicos', {
          params: {
            //nro_lote: this.loteSeleccionado, // nro_lote
            nro_lote: this.loteSeleccionado,
          },
        });
        
        this.lotesParaEdicion = response.data; 
      } catch (error) {
        console.error('Error al obtener los lotes:', error);
      }
    },
    async guardarRegistro(lote) {
      console.log(lote);
      try {
        const response = await axios.put(
          `https://private.com/editAnalisisMezcla/${lote.id}`, // Usamos el ID en la URL
          {
            fecha: lote.fecha,
            aprobada: lote.aprobada,
            NH4: lote.NH4,  // Cantidad que se va a actualizar
            AIP: lote.AIP,
            observaciones: lote.observaciones  // Observaciones que se van a actualizar
          }
        );

        if (response.data.status === true) {
          alert('Analisis mezcla guardado exitosamente');
        } else {
          alert(`Error: ${response.data.message}`);
        }
      } catch (error) {
        console.error('Error al guardar el analisis de mezcla:', error);
        alert('Hubo un error al guardar el analisis de mezcla. Intenta nuevamente.');
      }
    },



    async guardarAnalisisMezcla() {
      try {
        const datosLote = {
          nro_lote: String(this.numeroLote),
          fecha: String(this.fechaAnalisis),
          aprobada: this.aprobada,
          NH4: parseInt(this.NH4),
          AIP: parseInt(this.AIP),
          observaciones: String(this.observaciones),
        };

        const response = await axios.post('https://private.com/addAnalisisMezcla', datosLote);

        if (response.data.status === true) {
          alert('Análisis guardado exitosamente');
        } else {
          alert(`Error: ${response.data.error}`);
        }
      } catch (error) {
        console.error('Error al guardar el lote:', error);
        alert('Hubo un error al guardar el lote. Intenta nuevamente.');
      }
    },

    async obtenerLotes() {
      try {
        const response = await axios.get('https://private.com/listMezclas', {
          params: {
            start_date: this.fechaInicio,
            end_date: this.fechaTermino,
          },
        });
        
        this.lotes = response.data; 
      } catch (error) {
        console.error('Error al obtener los lotes:', error);
      }
    },

    transformarAprobacion(aprobada) {
      if (aprobada === true) {
        return 'Aprobada';
      } else if (aprobada === false) {
        return 'Rechazada';
      } else {
        return 'No analizada';
      }
    },

    seleccionarFila(lote) {
      this.loteSeleccionado = this.loteSeleccionado === lote.nro_lote ? null : lote.nro_lote;
      this.numeroLote = lote.nro_lote;
    },

    goToRoute(routeName) {
      this.$router.push({ name: routeName });
    },
  },
};
</script>

<style scoped>
/* CSS para efectos de Hover y escalar en Bootstrap 5 */
.cursor-pointer {
  cursor: pointer;
}

.hover-scale:hover {
  transform: scale(1.05);
  transition: transform 0.3s ease;
}
body {
      height: 100%;
    }

    aside {
      /* border: 1px yellow solid; */
      position: fixed;
      overflow: auto;
      height: calc(100vh - 12px);
      justify-content: flex-start;
      align-self: flex-start;

    }
    nav{
      position:sticky;
    }
    main {
      position: relative;
      overflow: visible;
      margin-left: auto;
      justify-content: flex-end;
      align-self: flex-end;
    }

    #sidebarshow {
      display: none;

    }

    @media screen and (max-width: 575px) {
      #sidebarshow {
        display: inline;
      }

      #sidebartoggle {
        display: none;
      }
    }


    .b-example-divider {
  width: 100%;
  height: 3rem;
  background-color: rgba(0, 0, 0, .1);
  border: solid rgba(0, 0, 0, .15);
  border-width: 1px 0;
  box-shadow: inset 0 .5em 1.5em rgba(0, 0, 0, .1), inset 0 .125em .5em rgba(0, 0, 0, .15);
}

.b-example-vr {
  flex-shrink: 0;
  width: 1.5rem;
  height: 100vh;
}

.bi {
  vertical-align: -.125em;
  fill: currentColor;
}

.bd-mode-toggle {
  z-index: 1500;
}

.btn-toggle {
  padding: .25rem .5rem;
  font-weight: 600;
  color: var(--bs-emphasis-color);
  background-color: transparent;
}

.btn-toggle::before {
  width: 1.25em;
  line-height: 0;
  content: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' width='16' height='16' viewBox='0 0 16 16'%3e%3cpath fill='none' stroke='rgba%280,0,0,.5%29' stroke-linecap='round' stroke-linejoin='round' stroke-width='2' d='M5 14l6-6-6-6'/%3e%3c/svg%3e");
  transition: transform .35s ease;
  transform-origin: .5em 50%;
}

[data-bs-theme="dark"] .btn-toggle::before {
  content: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' width='16' height='16' viewBox='0 0 16 16'%3e%3cpath fill='none' stroke='rgba%28255,255,255,.5%29' stroke-linecap='round' stroke-linejoin='round' stroke-width='2' d='M5 14l6-6-6-6'/%3e%3c/svg%3e");
}



.btn-toggle[aria-expanded="true"]::before {
  transform: rotate(90deg);
}

.btn-toggle-nav a {
  padding: .1875rem .5rem;
  margin-top: .125rem;
  margin-left: 1.25rem;
}
.logo {
  max-width: 100%;
  height: auto;
  margin-bottom: 20px;
  border-radius: 8px;
}



.modal {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: rgba(0, 0, 0, 0.5);
  display: flex;
  justify-content: center;
  align-items: center;
}

.modal-content {
  background: white;
  padding: 20px;
  border-radius: 5px;
  width: 80%;
  overflow-y: auto;
}

table {
  width: 100%;
  border-collapse: collapse;
}

table th, table td {
  padding: 8px;
  border: 1px solid #ccc;
}

button {
  padding: 10px;
  margin-top: 10px;
  cursor: pointer;
}




</style>

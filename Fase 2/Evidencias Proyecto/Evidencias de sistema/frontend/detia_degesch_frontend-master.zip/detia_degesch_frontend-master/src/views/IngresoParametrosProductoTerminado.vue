<template>
  <BaseLayout>
  </BaseLayout>
  <main class="col-sm-10 bg-body-tertiary" id="main">
    
    <div class="container-fluid"> 
    <!-- Titulo -->
      <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom" id="title">
          <h1 class="h2">Ingreso parámetros producto terminado</h1>
      </div>

      <!-- Creacion de filas para separación ordenada -->
      <div class="row">
        <!-- Creacion de estructura de ingreso de filas y columnas -->
        <div class="row g-4 mb-4">
          <!-- Columnas que van a la izquierda -->
          <div class="col-md-6">
            <div class="p-4 bg-light shadow-sm rounded">
              <!-- Creacion de ingreso de datos -->
              <div class="mb-3">
                <label for="numeroLote" class="form-label">Número de Lote</label>
                <input type="text" id="numeroLote" v-model="numeroLote" class="form-control mb-3"/>
              </div>

              <!-- Creacion de ingreso de datos -->
              <div class="mb-3">
                <label for="fechaAnalisis" class="form-label">Fecha Análisis</label>
                <input type="date" id="fechaAnalisis" v-model="fechaAnalisis" class="form-control mb-3" />
              </div>

            </div>
          </div>
          <!-- Columnas que van a la derecha -->
          <div class="col-md-6">
            <div class="p-4 bg-light shadow-sm rounded">

               <!-- Creacion de ingreso de datos -->
               <div class="mb-3">
                <label for="cajaContramuestra" class="form-label">Caja Contramuestra</label>
                <input type="text" id="cajaContramuestra" v-model="cajaContramuestra" class="form-control mb-3" />
              </div>

               <!-- Creacion de ingreso de datos -->
               <div class="mb-3">
                <label for="turno" >Turno</label>
                <select id="turno" v-model="id_turno" class="form-select mb-3">
                  <option v-for="turno in turnos" :key="turno.id" :value="turno.id">{{ turno.tipo }}</option>
                </select>
              </div>
              
            </div>
          </div>

        </div>
      </div>
    </div>

    <div class="container-fluid">
        <div class="mezcla-container container bg-light p-4 shadow-sm rounded">
          <h3 class="mb-4">Ingreso de muestra tabletas</h3>
          <div class="sample-section mt-4">
            <div class="container mt-5">
                <ul class="nav nav-tabs" id="myTab" role="tablist">
                    <li class="nav-item" role="presentation" v-for="(tab, index) in tabs" :key="index">
                    <a
                        class="nav-link" 
                        :class="{'active': index === activeTabIndex}" 
                        :id="'tab-' + index" 
                        data-bs-toggle="tab"
                        :href="'#content-' + index"
                        role="tab"
                        :aria-controls="'content-' + index"
                        :aria-selected="index === activeTabIndex ? 'true' : 'false'">
                        {{ tab }}
                    </a>
                    </li>
                </ul>

                <div class="tab-content mt-3" id="myTabContent">
                    <div v-for="(tab, index) in tabs" :key="index" class="tab-pane fade" :class="{'show active': index === activeTabIndex}" :id="'content-' + index" role="tabpanel" :aria-labelledby="'tab-' + index">
                      <div class="mb-4">
                          <div class="mb-3">
                          <label class="form-label">Polvo (gr.)</label>
                          <input type="text" v-model="tabData[index].polvo" class="form-control" />
                          </div>
                          <div class="mb-3">
                          <label class="form-label">Fracturado (cantidad)</label>
                          <input type="text" v-model="tabData[index].fracturado" class="form-control" />
                          </div>
                          <div class="mb-3">
                          <label class="form-label">Peso Neto (gr.)</label>
                          <input type="text" v-model="tabData[index].pesoNeto" class="form-control" />
                          </div>
                          <table class="table table-bordered">
                            <thead>
                                <tr>
                                  <th>N°</th>
                                  <th>Peso (gr.)</th>
                                  <th>Dureza</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr v-for="(item, indexPesoDureza) in getTablePesosDurezas(index)" :key="indexPesoDureza">
                                  <td>{{indexPesoDureza+1}}</td>
                                  <td><input type="text" v-model="item.peso" class="form-control" /></td>
                                  <td><input type="text" v-model="item.dureza" class="form-control" /></td>
                                </tr>
                            </tbody>
                          </table>
                      </div>
                    </div>
                </div>
                <div class="container mt-4">
                  <!-- Contenedor flex con botones separados -->
                  <div class="d-flex justify-content-between">
                    <!-- Botón de Cancelar alineado a la izquierda -->
                    <button type="submit" class="btn btn-lg btn-secondary" @click="$goBackToControlCalidad()">
                      <i class="bi bi-backspace-fill"></i> Volver
                    </button>
                    <!-- Botón de Guardar alineado a la derecha -->
                    <button type="submit" class="btn btn-lg btn-primary" @click="guardarAnalisisLote">
                      <i class="bi bi-save"></i> Guardar
                    </button>
                  </div>
                </div>
              </div>
          </div>
        </div>
      </div>
      <br/>

      <div class="container-fluid">
        <div class="mezcla-container container bg-light p-4 shadow-sm rounded">
          <h3 class="mb-4">Busqueda de lotes por fecha de producción</h3>
          <div class="sample-section mt-4">
          <br>
          <div class="container mt-4">
            <div class="sample-section">
              <div class="row mb-4">
                <div class="col-md-5">
                  <label for="fecha_inicio" class="form-label">Fecha de inicio:</label>
                  <input type="date" id="fecha_inicio" v-model="fechaInicio" class="form-control" />
                </div>
                <div class="col-md-5">
                  <label for="fecha_termino" class="form-label">Fecha de término:</label>
                  <input type="date" id="fecha_termino" v-model="fechaTermino" class="form-control" />
                </div>
                <div class="col-md-2 d-flex align-items-end">
                  <button class="btn btn-primary w-100" @click="obtenerLotes">🔍</button>
                </div>
              </div>
            </div>
    
    
    <!-- Tabla de lotes -->
            <div class="container mt-5">
              <div class="table-responsive">
                <table class="table table-bordered table-hover">
                  <thead>
                    <tr>
                      <th scope="col">N° de Lote</th>
                      <th scope="col">Estado Análisis Lote</th>
                      <th scope="col">Fecha Producción</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr
                      v-for="lote in lotes"
                      :key="lote.nro_lote"
                      @click="seleccionarFila(lote)"
                      :class="{ 'table-primary': loteSeleccionado === lote.nro_lote }">
                      <td>{{ lote.nro_lote }}</td>
                      <td>{{ lote.estado }}</td>
                      <td>{{ lote.fecha_produccion }}</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
          </div>
        </div>
      </div>

    </main>
</template>

<script>
import axios from 'axios';
import BaseLayout from '@/layouts/BaseLayout.vue';
export default {
  name: 'IngresoParametrosProductoTerminado',
  components: {
    BaseLayout
  },
  data() {
    return {
      tablaPesosDurezas1: Array.from({ length: 10 }, () => ({
        peso: '',
        dureza: ''
      })),
      tablaPesosDurezas2: Array.from({ length: 10 }, () => ({
        peso: '',
        dureza: ''
      })),
      tablaPesosDurezas3: Array.from({ length: 10 }, () => ({
        peso: '',
        dureza: ''
      })),
      tabs: ['Muestra 1', 'Muestra 2', 'Muestra 3'],
      activeTabIndex: 0,
      tabData: [
        { polvo: '', fracturado: '', pesoNeto: '', tablaPesosDurezas: [{ peso: '', dureza: '' }] },
        { polvo: '', fracturado: '', pesoNeto: '', tablaPesosDurezas: [{ peso: '', dureza: '' }] },
        { polvo: '', fracturado: '', pesoNeto: '', tablaPesosDurezas: [{ peso: '', dureza: '' }] }
      ],
      fechaInicio: '',
      fechaTermino: '',
      numeroLote: '',
      id_turno: '',
      fechaAnalisis: '',
      cajaContramuestra: '',
      lotes: [],
      turnos: [],
      loteSeleccionado: null
    };
  },
  methods: {
    goToRoute(routeName) {
      this.$router.push({ name: routeName });
    },
    getTablePesosDurezas(index) {
      return this[`tablaPesosDurezas${index + 1}`] || [];
    },
    async guardarAnalisisLote() {
      try {
        const datosLote = {
          nro_lote: this.numeroLote,
          fecha: String(this.fechaAnalisis),
          id_turno: parseInt(this.id_turno),
          caja_contramuestra: parseInt(this.cajaContramuestra)
        };

        const response = await axios.post('private.com/addAnalisisProductoTerminado', datosLote);

        if (response.data.status === true) {
          alert('Análisis de lote guardado exitosamente');
          this.guardarMuestraProductoTerminado();
        } else {
          alert(`Error: ${response.data.message}`);
        }
      } catch (error) {
        console.error('Error al guardar el análisis de lote:', error);
        alert('Hubo un error al guardar el análisis de lote. Intenta nuevamente.');
      }
    },
    async guardarMuestraProductoTerminado() {
      for (let index = 0; index < this.tabData.length; index++) {
        const tab = this.tabData[index];
        const todasLasTablas = [this.tablaPesosDurezas1, this.tablaPesosDurezas2, this.tablaPesosDurezas3];
        this.pesos = [];
        this.durezas = [];
        const tablaActual = todasLasTablas[index];

        for (let i = 0; i < tablaActual.length; i++) {
          const item = tablaActual[i];
          if (item.peso !== "") this.pesos.push(parseFloat(item.peso));
          if (item.dureza !== "") this.durezas.push(parseFloat(item.dureza));
        }
        
        try {
          const datosLote = {
            nro_lote: this.numeroLote,
            polvo: tab.polvo,
            fracturado: tab.fracturado,
            peso_neto: tab.pesoNeto,
            pesos: this.pesos,
            durezas: this.durezas
          };

          const response = await axios.post('private.com/addMuestraProductoTerminado', datosLote);
          if (response.data.status === true) {
            alert('Muestra guardada exitosamente');
          } else {
            alert(`Error: ${response.data.message}`);
          }
        } catch (error) {
          console.error('Error al guardar la muestra:', error);
        }
      }
    },
    changeTab(index) {
      this.activeTabIndex = index;
    },
    seleccionarFila(lote) {
      this.loteSeleccionado = this.loteSeleccionado === lote.nro_lote ? null : lote.nro_lote;
      this.numeroLote = lote.nro_lote;
    },
    async obtenerLotes() {
      try {
        const response = await axios.get('private.com/listProductoTerminado', {
          params: {
            start_date: this.fechaInicio,
            end_date: this.fechaTermino
          }
        });
        this.lotes = response.data;
      } catch (error) {
        console.error('Error al obtener los lotes:', error);
      }
    },
    transformarAprobacion(aprobada) {
      if (aprobada === true) {
        return 'Aprobada';
      } else if (aprobada === false) {
        return 'Rechazada';
      } else {
        return 'No analizada';
      }
    },
    async obtenerTurnos() {
      try {
        const response = await axios.get('private.com/listTurno');
        this.turnos = response.data;
      } catch (error) {
        console.error('Error al obtener los turnos:', error);
      }
    },
  },
  created() {
    this.obtenerTurnos();
  }
};
</script>

<style scoped>
/* CSS para efectos de Hover y escalar en Bootstrap 5 */
.cursor-pointer {
  cursor: pointer;
}

.hover-scale:hover {
  transform: scale(1.05);
  transition: transform 0.3s ease;
}
body {
      height: 100%;
    }

    aside {
      /* border: 1px yellow solid; */
      position: fixed;
      overflow: auto;
      height: calc(100vh - 12px);
      justify-content: flex-start;
      align-self: flex-start;

    }
    nav{
      position:sticky;
    }
    main {
      position: relative;
      overflow: visible;
      margin-left: auto;
      justify-content: flex-end;
      align-self: flex-end;
    }

    #sidebarshow {
      display: none;

    }

    @media screen and (max-width: 575px) {
      #sidebarshow {
        display: inline;
      }

      #sidebartoggle {
        display: none;
      }
    }


    .b-example-divider {
  width: 100%;
  height: 3rem;
  background-color: rgba(0, 0, 0, .1);
  border: solid rgba(0, 0, 0, .15);
  border-width: 1px 0;
  box-shadow: inset 0 .5em 1.5em rgba(0, 0, 0, .1), inset 0 .125em .5em rgba(0, 0, 0, .15);
}

.b-example-vr {
  flex-shrink: 0;
  width: 1.5rem;
  height: 100vh;
}

.bi {
  vertical-align: -.125em;
  fill: currentColor;
}

.bd-mode-toggle {
  z-index: 1500;
}

.btn-toggle {
  padding: .25rem .5rem;
  font-weight: 600;
  color: var(--bs-emphasis-color);
  background-color: transparent;
}

.btn-toggle::before {
  width: 1.25em;
  line-height: 0;
  content: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' width='16' height='16' viewBox='0 0 16 16'%3e%3cpath fill='none' stroke='rgba%280,0,0,.5%29' stroke-linecap='round' stroke-linejoin='round' stroke-width='2' d='M5 14l6-6-6-6'/%3e%3c/svg%3e");
  transition: transform .35s ease;
  transform-origin: .5em 50%;
}

[data-bs-theme="dark"] .btn-toggle::before {
  content: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' width='16' height='16' viewBox='0 0 16 16'%3e%3cpath fill='none' stroke='rgba%28255,255,255,.5%29' stroke-linecap='round' stroke-linejoin='round' stroke-width='2' d='M5 14l6-6-6-6'/%3e%3c/svg%3e");
}



.btn-toggle[aria-expanded="true"]::before {
  transform: rotate(90deg);
}

.btn-toggle-nav a {
  padding: .1875rem .5rem;
  margin-top: .125rem;
  margin-left: 1.25rem;
}
.logo {
  max-width: 100%;
  height: auto;
  margin-bottom: 20px;
  border-radius: 8px;
}
</style>

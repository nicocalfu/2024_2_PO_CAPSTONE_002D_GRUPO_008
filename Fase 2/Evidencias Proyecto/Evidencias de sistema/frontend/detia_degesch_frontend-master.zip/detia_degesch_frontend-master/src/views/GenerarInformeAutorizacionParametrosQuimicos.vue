<template>
  <BaseLayout>
  </BaseLayout>
  
  <main class="col-sm-10 bg-body-tertiary" id="main">
    <div class="container-fluid">
      <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom" id="title">
        <h1 class="h2">Generar Informe de Receta de mezclas</h1>
      </div>

      <div class="row">
        
        <div class="container">
          <div class="row justify-content-center">
            <div class="col-md-6 col-12">
              <div class="form-container mt-4">
                <div class="mb-3">
                  <label for="numeroAutorizacion" class="form-label">Ingrese número de receta</label>
                  <input type="text" id="numeroAutorizacion" class="form-control" v-model="numeroReceta"/>
                </div>

                <button class="btn btn-danger w-100" @click="obtenerInformeProductoTerminado">Generar Autorización</button>
                <button class="btn btn-secondary w-100 mt-4" @click="$goBackToControlCalidad()">Volver</button>
                
              </div>
            </div>
          </div>
        </div>
        
      </div>
    </div>
  </main>
</template>

<script>
import axios from 'axios';
import BaseLayout from '@/layouts/BaseLayout.vue';
export default {
  name: 'GenerarAutorizacionParametrosQuimicosMezclas',
  components: {
    BaseLayout
  },
  data(){
    return{
      numeroReceta: "",
      linkPDF: [],
    }
  },
  methods: {
    async obtenerInformeProductoTerminado() {
      try {
        const response = await axios.get('private.com/generateInformePorReceta', {
          params: {
            nro_receta: this.numeroReceta,
          },
        });
        
        this.linkPDF = response.data; 
        //console.log(this.linkPDF.pdf_link);
        const url = 'private.com/' + this.linkPDF.pdf_link;
        window.open(url, '_blank');
      } catch (error) {
        console.error('Error al obtener los lotes:', error);
      }
    },
    goToRoute(routeName) {
      this.$router.push({ name: routeName });
    },
  }
};
</script>

<style scoped>
/* CSS para efectos de Hover y escalar en Bootstrap 5 */
.cursor-pointer {
  cursor: pointer;
}

.hover-scale:hover {
  transform: scale(1.05);
  transition: transform 0.3s ease;
}
body {
      height: 100%;
    }

    aside {
      /* border: 1px yellow solid; */
      position: fixed;
      overflow: auto;
      height: calc(100vh - 12px);
      justify-content: flex-start;
      align-self: flex-start;

    }
    nav{
      position:sticky;
    }
    main {
      position: relative;
      overflow: visible;
      margin-left: auto;
      justify-content: flex-end;
      align-self: flex-end;
    }

    #sidebarshow {
      display: none;

    }

    @media screen and (max-width: 575px) {
      #sidebarshow {
        display: inline;
      }

      #sidebartoggle {
        display: none;
      }
    }


    .b-example-divider {
  width: 100%;
  height: 3rem;
  background-color: rgba(0, 0, 0, .1);
  border: solid rgba(0, 0, 0, .15);
  border-width: 1px 0;
  box-shadow: inset 0 .5em 1.5em rgba(0, 0, 0, .1), inset 0 .125em .5em rgba(0, 0, 0, .15);
}

.b-example-vr {
  flex-shrink: 0;
  width: 1.5rem;
  height: 100vh;
}

.bi {
  vertical-align: -.125em;
  fill: currentColor;
}

.bd-mode-toggle {
  z-index: 1500;
}

.btn-toggle {
  padding: .25rem .5rem;
  font-weight: 600;
  color: var(--bs-emphasis-color);
  background-color: transparent;
}

.btn-toggle::before {
  width: 1.25em;
  line-height: 0;
  content: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' width='16' height='16' viewBox='0 0 16 16'%3e%3cpath fill='none' stroke='rgba%280,0,0,.5%29' stroke-linecap='round' stroke-linejoin='round' stroke-width='2' d='M5 14l6-6-6-6'/%3e%3c/svg%3e");
  transition: transform .35s ease;
  transform-origin: .5em 50%;
}

[data-bs-theme="dark"] .btn-toggle::before {
  content: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' width='16' height='16' viewBox='0 0 16 16'%3e%3cpath fill='none' stroke='rgba%28255,255,255,.5%29' stroke-linecap='round' stroke-linejoin='round' stroke-width='2' d='M5 14l6-6-6-6'/%3e%3c/svg%3e");
}



.btn-toggle[aria-expanded="true"]::before {
  transform: rotate(90deg);
}

.btn-toggle-nav a {
  padding: .1875rem .5rem;
  margin-top: .125rem;
  margin-left: 1.25rem;
}
.logo {
  max-width: 100%;
  height: auto;
  margin-bottom: 20px;
  border-radius: 8px;
}
</style>

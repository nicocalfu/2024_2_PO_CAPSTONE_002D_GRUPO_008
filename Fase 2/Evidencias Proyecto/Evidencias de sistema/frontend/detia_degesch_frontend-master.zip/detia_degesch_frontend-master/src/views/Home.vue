<template>
  <div class="Home-container">
    <img src="https://www.degesch.cl/wp-content/uploads/2023/02/Logo_DD_Claim.png" alt="Detia Degesch Logo" class="logo">
    <h2>Registro de Usuario</h2>
    <input type="text" placeholder="Usuario" v-model="username">
    <input type="email" placeholder="Correo" v-model="email">
    <div class="phone-input">
      <span class="phone-prefix">+56</span>
      <input type="text" placeholder="Teléfono" v-model="phone">
    </div>
    <input type="password" placeholder="Contraseña" v-model="password">
    <input type="password" placeholder="Confirmar Contraseña" v-model="confirmPassword">
    <button @click="register">Registrar</button>
    <p v-if="error" class="error-message">{{ error }}</p>
    <p v-if="success" class="success-message">{{ success }}</p>
    <p>¿Ya tienes una cuenta? <a href="#" @click.prevent="$emit('switch-view', 'Login')">Inicia sesión aquí</a></p>
  </div>
</template>

<script>
export default {
  name: 'UserRegister',
  data() {
    return {
      username: '',
      email: '',
      phone: '',
      password: '',
      confirmPassword: '',
      error: '',
      success: ''
    };
  },
  methods: {
    register() {
      if (this.password !== this.confirmPassword) {
        this.error = 'Las contraseñas no coinciden.';
        this.success = '';
      } else {
        this.success = 'Registro exitoso. Ahora puedes iniciar sesión.';
        this.error = '';
      }
    }
  }
};
</script>

<style scoped>
.register-container {
  background-color: white;
  padding: 20px;
  border-radius: 8px;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
  width: 300px;
  margin: 0 auto;
  text-align: center;
}
.logo {
  max-width: 100%;
  height: auto;
  margin-bottom: 20px;
}
.register-container input {
  width: 100%;
  padding: 10px;
  margin-bottom: 10px;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
}
.phone-input {
  display: flex;
  align-items: center;
  margin-bottom: 10px;
}
.phone-prefix {
  background-color: #f0f0f0;
  border: 1px solid #ccc;
  border-radius: 4px 0 0 4px;
  padding: 10px;
  margin-right: -1px;
}
.phone-input input {
  flex: 1;
  border-radius: 0 4px 4px 0;
}
.register-container button {
  width: 100%;
  padding: 10px;
  background-color: #4CAF50;
  color: white;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}
.register-container button:hover {
  background-color: #45a049;
}
.error-message {
  color: red;
  margin-top: 10px;
}
.success-message {
  color: green;
  margin-top: 10px;
}
.register-container p {
  margin-top: 10px;
}
.register-container a {
  color: #4CAF50;
  text-decoration: none;
}
.register-container a:hover {
  text-decoration: underline;
}
</style>

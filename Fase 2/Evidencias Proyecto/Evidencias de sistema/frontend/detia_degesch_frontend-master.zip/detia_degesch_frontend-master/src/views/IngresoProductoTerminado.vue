<template>
  <BaseLayout>
  </BaseLayout>

  <main class="col-sm-10 bg-body-tertiary" id="main">
    <div class="container-fluid">
      <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom" id="title">
        <h1 class="h2">Ingreso de producto terminado</h1>
      </div>


      <div>
        <!-- Modal -->
        <div v-if="modalVisible" class="modal fade show" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
          <!-- Usamos modal-dialog-centered para centrar el modal verticalmente -->
          <div class="modal-dialog modal-dialog-centered" style="max-width: 90%; margin: auto;">
            <div class="modal-content">
              <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Edición de Lote Producto Terminado</h5>
                <button type="button" class="btn-close" @click="cerrarModal" data-bs-dismiss="modal" aria-label="Close"></button>
              </div>
              <div class="modal-body">
                <!-- Contenedor de tabla que se adapta sin barra de desplazamiento horizontal -->
                <div class="table-responsive">
                  <table class="table table-striped">
                    <thead>
                      <tr>
                        <th>Fecha</th>
                        <th>ID Operador</th>
                        <th>ID Máquina</th>
                        <th>ID Turno</th>
                        <th>Cantidad</th>
                        <th>Formato</th>
                        <th>Acciones</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr v-for="lote in lotesParaEdicion" :key="lote.nro_lote">
                        <td><input v-model="lote.fecha" type="date" class="form-control" /></td>
                        <td><input v-model="lote.id_operador" type="text" class="form-control" /></td>
                        <td><input v-model="lote.id_maquina" type="text" class="form-control" /></td>
                        <td><input v-model="lote.id_turno" type="text" class="form-control" /></td>
                        <td><input v-model="lote.cantidad" type="number" class="form-control" /></td>
                        <td><input v-model="lote.cod_producto" type="text" class="form-control" /></td>
                        <td>
                          <button @click="guardarRegistro(lote)" class="btn btn-primary">Guardar</button>
                          <button @click="eliminarRegistro(lote)" class="btn btn-danger">Eliminar</button>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
              <!-- Footer sin uso 
              <div class="modal-footer">
                <button @click="cerrarModal" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
              </div>
              -->
            </div>
          </div>
        </div>
      </div>
        



      <div class="row">
        <!-- Formulario -->
        <div class="form-container row g-4 mb-4">
        <div class="col-md-6">
            <!-- Número de Lote -->
            <div class="form-group">
            <label for="numeroLote">Número de Lote</label>
            <input type="text" id="numeroLote" v-model="numeroLote" class="form-control">
            </div>

            <!-- Fecha -->
            <div class="form-group">
            <label for="fecha">Fecha</label>
            <input type="date" id="fecha" v-model="fecha" class="form-control">
            </div>

            <!-- Turno -->
            <div class="form-group">
            <label for="turno">Turno</label>
            <select id="turno" v-model="id_turno" class="form-select">
                <option v-for="turno in turnos" :key="turno.id" :value="turno.id">
                {{ turno.tipo }}
                </option>
            </select>
            </div>

            <!-- Operador -->
            <div class="form-group">
            <label for="operador">Operador</label>
            <select id="operador" v-model="id_operador" class="form-select">
                <option v-for="empleado in empleados" :key="empleado.id" :value="empleado.id">
                {{ empleado.nombre }} {{ empleado.apellido }}
                </option>
            </select>
            </div>

            <!-- Máquina -->
            <div class="form-group">
            <label for="maquina">Máquina</label>
            <select id="maquina" v-model="id_maquina" class="form-select">
                <option v-for="maquina in maquinas" :key="maquina.id" :value="maquina.id">
                {{ maquina.nombre }}
                </option>
            </select>
            </div>

            <!-- Producto -->
            <div class="form-group">
            <label for="producto">Presentación</label>
            <select id="producto" v-model="cod_producto" class="form-select">
                <option v-for="producto in productos" :key="producto.cod_producto" :value="producto.cod_producto">
                {{ producto.nombre }}
                </option>
            </select>
            </div>

            <!-- Cantidad -->
            <div class="form-group">
            <label for="cantidad">Cantidad</label>
            <input type="text" id="Cantidad" v-model="cantidad" class="form-control">
            </div>
        </div>

        <!-- Observaciones -->
        <div class="col-md-6">
            <div class="form-group">
            <label for="observaciones">Observaciones</label>
            <input type="text" v-model="observaciones" class="form-control">
            </div>
        </div>

        <div class="container mt-4">
            <!-- Contenedor flex con botones separados -->
            <div class="d-flex justify-content-between">
              <!-- Botón de Cancelar alineado a la izquierda -->
              <button type="submit" class="btn btn-lg btn-secondary" @click="$goBackToFormulacion()">
                <i class="bi bi-backspace-fill"></i> Volver
              </button>
              <!-- Botón de Guardar alineado a la derecha -->
              <button type="submit" class="btn btn-lg btn-primary" @click="guardarLote">
                <i class="bi bi-save"></i> Guardar
              </button>
            </div>
          </div>

        </div>
        
        
        <!-- Botón para guardar lote 
        <button class="btn btn-primary w-100 mb-4" @click="guardarLote">Guardar Lote</button>
        -->
        
        <!-- Sección de búsqueda -->
        <div class="container mt-4">
          <hr class="hr" />
          <!-- Container de la sección de búsqueda con fondo de Bootstrap -->
          <div class="bg-light p-4 rounded shadow-sm">
            <div class="search-section mb-4">
              <h3>Busqueda de mezclas por fecha de producción</h3>
              <div class="d-flex gap-3">
                <div class="form-group">
                  <label for="fecha_inicio">Fecha de inicio:</label>
                  <input type="date" id="fecha_inicio" v-model="fechaInicio" class="form-control">
                </div>
                <div class="form-group">
                  <label for="fecha_termino">Fecha de termino:</label>
                  <input type="date" id="fecha_termino" v-model="fechaTermino" class="form-control">
                </div>
                <button class="btn btn-info align-self-end" @click="buscarLotes">🔍</button>
              </div>
            </div>

            <!-- Tabla de lotes -->
            <div class="table-responsive mt-5">
              <table class="table table-bordered table-striped">
                <thead>
                  <tr>
                    <th scope="col">N° de Lote</th>
                    <th scope="col">Estado Analisis Mezcla</th>
                    <th scope="col">Fecha Producción</th>
                    <th scope="col"></th>
                  </tr>
                </thead>
                <tbody>
                  <tr
                    v-for="lote in lotes"
                    :key="lote.nro_lote"
                    @click="seleccionarFila(lote)"
                    :class="{ 'table-primary': loteSeleccionado === lote.nro_lote }">
                    <td>{{ lote.nro_lote }}</td>
                    <td>{{ transformarAprobacion(lote.aprobada) }}</td>
                    <td>{{ lote.fecha }}</td>
                    <td><button @click="abrirModal" class="bi bi-pencil-fill"></button></td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
        <!--  
        <button class="btn btn-danger w-100 mt-4" @click="$goBackToFormulacion()">Volver</button>
        -->
      </div>
    </div>
  </main>
</template>

<script>
import axios from 'axios';
import BaseLayout from '@/layouts/BaseLayout.vue';
export default {
  components: {
    BaseLayout
  },
  data() {
    return {

      modalVisible: false,
      lotesParaEdicion: [],
      codProductoEdicion: '',


      empleados: [],
      productos: [],
      maquinas: [],
      turnos: [],
      lotes: [], // Lista de lotes que se llenará con la respuesta de la API
      loteSeleccionado: null, // Variable que guarda el número del lote seleccionado
      fechaInicio: '',
      fechaTermino: '',
      numeroLote: '',
      buscarFecha: '', // Variable para búsqueda por fecha
      id_turno: '',
      id_operador: '',
      id_maquina: '',
      cod_producto: '',
      cantidad: '',
      observaciones: '',
      fecha: '', // Fecha de fabricación
    };
  },
  methods: {


    async abrirModal() {
      // Primero, obtenemos los lotes para edición
      await this.obtenerLotesParaEdicion();

      // Luego verificamos si hay lotes disponibles
      if (this.lotesParaEdicion && this.lotesParaEdicion.length > 0) {
        // Si los lotes están listos, entonces mostramos el modal
        this.modalVisible = true;
      } else {
        // Si no hay lotes, puedes manejar el error o mostrar un mensaje
        console.log('No hay lotes para edición.');
      }
    },
    // Función para cerrar el modal
    cerrarModal() {
      this.lotesParaEdicion = [];
      this.modalVisible = false;
    },
    async obtenerLotesParaEdicion() {
      try {
        const response = await axios.get('private.com/listLoteProductoTerminado', {
          params: {
            //nro_lote: this.loteSeleccionado, // nro_lote
            nro_lote: this.loteSeleccionado,
          },
        });
        
        this.lotesParaEdicion = response.data; 
      } catch (error) {
        console.error('Error al obtener los lotes:', error);
      }
    },
    async obtenerCodProducto(codProducto) {
      try {
        const response = await axios.get('private.com/listCodProducto', {
          params: {
            //nro_lote: this.loteSeleccionado, // nro_lote
            cod_producto: codProducto,
          },
        });
        
        this.codProductoEdicion = response.data; 
      } catch (error) {
        console.error('Error al obtener los tipos de producto:', error);
      }
    },
    async guardarRegistro(lote) {
      console.log(lote);
      try {
        const response = await axios.put(
          `private.com/editProductoTerminado/${lote.id}`, // Usamos el ID en la URL
          {
            fecha: lote.fecha,
            id_operador: lote.id_operador,
            id_maquina: lote.id_maquina,
            cantidad: lote.cantidad,
            cod_producto: lote.cod_producto,
          }
        );

        if (response.data.status === true) {
          alert('Producto terminado guardado exitosamente');
          location.reload();
        } else {
          alert(`Error: ${response.data.message}`);
        }
      } catch (error) {
        console.error('Error al guardar el producto terminado:', error);
        alert('Hubo un error al guardar el producto terminado. Intenta nuevamente.');
      }
    },





    goToRoute(routeName) {
      this.$router.push({ name: routeName });
    },
    // Método para realizar la consulta asincrónica a la API
    async obtenerLotes() {
      try {
        const response = await axios.get('private.com/listMezclas', {
          params: {
            start_date: this.fechaInicio, // Fechas de inicio
            end_date: this.fechaTermino, // Fechas de fin
          },
        });
        
        this.lotes = response.data; 
      } catch (error) {
        console.error('Error al obtener los lotes:', error);
      }
    },

    buscarLotes() {
      this.obtenerLotes();
    },

    transformarAprobacion(aprobada) {
      if (aprobada === true) {
        return 'Aprobada';
      } else if (aprobada === false) {
        return 'Rechazada';
      } else {
        return 'No analizada';
      }
    },

    seleccionarFila(lote) {
      this.loteSeleccionado = this.loteSeleccionado === lote.nro_lote ? null : lote.nro_lote;
      this.numeroLote = lote.nro_lote;
    },

    async guardarLote() {
      try {
        const datosLote = {
          nro_lote: String(this.numeroLote),
          fecha: String(this.fecha),
          id_turno: parseInt(this.id_turno),
          id_operador: parseInt(this.id_operador),
          id_maquina: parseInt(this.id_maquina),
          cod_producto: String(this.cod_producto),
          cantidad: parseInt(this.cantidad),
          observaciones: String(this.observaciones)
        };

        const response = await axios.post('private.com/addProductoTerminado', datosLote);

        if (response.data.status === true) {
          alert('Lote guardado exitosamente');
        } else {
          alert(`Error: ${response.data.error}`);
        }
      } catch (error) {
        console.error('Error al guardar el lote:', error);
        alert('Hubo un error al guardar el lote. Intenta nuevamente.');
      }
    },

    async obtenerEmpleados() {
      try {
        const response = await axios.get('private.com/listEmpleado', {
          params: {
            id_seccion: localStorage.getItem('id_seccion_usuario')
          }
        });
        this.empleados = response.data; 
      } catch (error) {
        console.error('Error al obtener los empleados:', error);
      }
    },

    async obtenerProductos() {
      try {
        const response = await axios.get('private.com/listTipoProducto');
        this.productos = response.data; 
      } catch (error) {
        console.error('Error al obtener los productos:', error);
      }
    },

    async obtenerMaquinas() {
      try {
        const response = await axios.get('private.com/listMaquina');
        this.maquinas = response.data; 
      } catch (error) {
        console.error('Error al obtener las maquinas:', error);
      }
    },

    async obtenerTurnos() {
      try {
        const response = await axios.get('private.com/listTurno');
        this.turnos = response.data; 
      } catch (error) {
        console.error('Error al obtener los turnos:', error);
      }
    },
  },

  created() {
    this.obtenerProductos();
    this.obtenerEmpleados();
    this.obtenerMaquinas();
    this.obtenerTurnos();
  }
};
</script>

<style scoped>
/* CSS para efectos de Hover y escalar en Bootstrap 5 */
.cursor-pointer {
  cursor: pointer;
}

.hover-scale:hover {
  transform: scale(1.05);
  transition: transform 0.3s ease;
}
body {
      height: 100%;
    }

    aside {
      /* border: 1px yellow solid; */
      position: fixed;
      overflow: auto;
      height: calc(100vh - 12px);
      justify-content: flex-start;
      align-self: flex-start;

    }
    nav{
      position:sticky;
    }
    main {
      position: relative;
      overflow: visible;
      margin-left: auto;
      justify-content: flex-end;
      align-self: flex-end;
    }

    #sidebarshow {
      display: none;

    }

    @media screen and (max-width: 575px) {
      #sidebarshow {
        display: inline;
      }

      #sidebartoggle {
        display: none;
      }
    }


    .b-example-divider {
  width: 100%;
  height: 3rem;
  background-color: rgba(0, 0, 0, .1);
  border: solid rgba(0, 0, 0, .15);
  border-width: 1px 0;
  box-shadow: inset 0 .5em 1.5em rgba(0, 0, 0, .1), inset 0 .125em .5em rgba(0, 0, 0, .15);
}

.b-example-vr {
  flex-shrink: 0;
  width: 1.5rem;
  height: 100vh;
}

.bi {
  vertical-align: -.125em;
  fill: currentColor;
}

.bd-mode-toggle {
  z-index: 1500;
}

.btn-toggle {
  padding: .25rem .5rem;
  font-weight: 600;
  color: var(--bs-emphasis-color);
  background-color: transparent;
}

.btn-toggle::before {
  width: 1.25em;
  line-height: 0;
  content: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' width='16' height='16' viewBox='0 0 16 16'%3e%3cpath fill='none' stroke='rgba%280,0,0,.5%29' stroke-linecap='round' stroke-linejoin='round' stroke-width='2' d='M5 14l6-6-6-6'/%3e%3c/svg%3e");
  transition: transform .35s ease;
  transform-origin: .5em 50%;
}

[data-bs-theme="dark"] .btn-toggle::before {
  content: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' width='16' height='16' viewBox='0 0 16 16'%3e%3cpath fill='none' stroke='rgba%28255,255,255,.5%29' stroke-linecap='round' stroke-linejoin='round' stroke-width='2' d='M5 14l6-6-6-6'/%3e%3c/svg%3e");
}



.btn-toggle[aria-expanded="true"]::before {
  transform: rotate(90deg);
}

.btn-toggle-nav a {
  padding: .1875rem .5rem;
  margin-top: .125rem;
  margin-left: 1.25rem;
}
.logo {
  max-width: 100%;
  height: auto;
  margin-bottom: 20px;
  border-radius: 8px;
}




.modal {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: rgba(0, 0, 0, 0.5);
  display: flex;
  justify-content: center;
  align-items: center;
}

.modal-content {
  background: white;
  padding: 20px;
  border-radius: 5px;
  width: 80%;
  overflow-y: auto;
}

table {
  width: 100%;
  border-collapse: collapse;
}

table th, table td {
  padding: 8px;
  border: 1px solid #ccc;
}

button {
  padding: 10px;
  margin-top: 10px;
  cursor: pointer;
}




</style>

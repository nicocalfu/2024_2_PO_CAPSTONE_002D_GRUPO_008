<template>
  <div class="login-container">
    <img src="https://www.degesch.cl/wp-content/uploads/2023/02/Logo_DD_Claim.png" alt="Detia Degesch Logo" class="logo">
    <h2>Iniciar Sesión</h2>
    
    <!-- Formulario que maneja el submit -->
    <form @submit.prevent="login">
      <input type="text" placeholder="Usuario" v-model="username" />
      <input type="password" placeholder="Contraseña" v-model="password" />
      <button type="submit">Entrar</button> <!-- Este botón ahora dispara el submit del formulario -->
    </form>

    <p v-if="error" class="error-message">{{ error }}</p>
    <!--
      <p>¿Eres nuevo? <a href="#" @click.prevent="$emit('switch-view', 'Register')">Regístrate aquí</a></p>
    -->
  </div>
</template>

<script>
import axios from 'axios';
//import Cookies from 'js-cookie';
import { mapActions } from 'vuex';

// Configurar axios para enviar credenciales (cookies) con cada solicitud
axios.defaults.withCredentials = true;

// Puedes configurar los encabezados por defecto también si es necesario
axios.defaults.headers.common['Content-Type'] = 'application/json';

export default {
  name: 'UserLogin',
  mounted() {
    //console.log("Componente login cargado");
    //document.title = 'Iniciar Sesión';
  },
  data() {
    return {
      username: '',
      password: '',
      error: ''
    };
  },
  methods: {
    ...mapActions(['login']), // Mapeamos la acción de login de Vuex
    //login  : async () => {
    async login() {
        try {
          // Hacemos la solicitud de login al backend
          const response = await axios.post("private.com/login", {
            nombre_usuario: this.username,
            contrasena: this.password
          }, {
            withCredentials: true  // Esto asegura que las cookies se envíen con la solicitud
          });

          const status = response.data['status'];

          if (status) {
            console.log("Login exitoso");

            if(response.data['id_usuario']===7){
              window.location.href = 'private.com/admin/';
            } else {
              // Aquí podemos manejar la cookie de sesión (si la configura el backend)
              //const userToken = response.data['token'];  // Verifica si el token está disponible en la cookie
              localStorage.setItem('user_token', response.data['token']);
              localStorage.setItem('id_seccion_usuario', response.data['id_seccion']);
              localStorage.setItem('id_cargo_usuario', response.data['id_cargo']);
              localStorage.setItem('nombre_usuario', response.data['nombre']);

              // Redirigir según el rol del usuario
              if (response.data['id_seccion'] === 4 && response.data['id_cargo'] === 13) {
                this.$router.push({ name: 'formulacion' });
              } else if (response.data['id_seccion'] === 2 && response.data['id_cargo'] === 18) {
                this.$router.push({ name: 'controlcalidad' });
              }
            }

          } else {
            // Si el login falla
            console.log("Error en el login: ", response.data['message']);
            this.error = response.data['message'] || "Error en el login.";
          }
        } catch (error) {
          // Maneja errores aquí
          console.error("Error en la solicitud de login:", error);
          this.error = "Hubo un error al procesar tu solicitud. Intenta de nuevo.";
        }
      }
    }
};
</script>

<style scoped>
.login-container {
  background-color: white;
  padding: 20px;
  border-radius: 8px;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
  width: 300px;
  margin: 0 auto;
  text-align: center;
}
.logo {
  max-width: 100%;
  height: auto;
  margin-bottom: 20px;
}
.login-container input {
  width: 100%;
  padding: 10px;
  margin-bottom: 10px;
  border: 1px solid #ccc;
  border-radius: 4px;
}
.login-container button {
  width: 100%;
  padding: 10px;
  background-color: #4CAF50;
  color: white;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}
.login-container button:hover {
  background-color: #45a049;
}
.error-message {
  color: red;
  margin-top: 10px;
}
.login-container p {
  margin-top: 10px;
}
.login-container a {
  color: #4CAF50;
  text-decoration: none;
}
.login-container a:hover {
  text-decoration: underline;
}
</style>

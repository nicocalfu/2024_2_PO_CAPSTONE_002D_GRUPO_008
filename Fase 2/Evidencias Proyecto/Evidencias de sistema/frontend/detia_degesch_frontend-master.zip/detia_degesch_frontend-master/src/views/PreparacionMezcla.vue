<template>
  <BaseLayout>
  </BaseLayout>
  <main class="col-sm-10 bg-body-tertiary" id="main">
    <div class="container-fluid">
      <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom" id="title">
        <h1 class="h2">Preparación de mezcla</h1>
      </div>

      <div class="row">
        <div class="mezcla-container container bg-light p-4 shadow-sm rounded">
          <form class="mezcla-form row mt-4">
            <div class="column col-md-6">
              <label for="recetaNumero">Número de Receta:</label>
              <input type="number" id="recetaNumero" v-model="recetaNumero" placeholder="Ingrese el número de receta" class="form-control mb-3">

              <label for="ingrediente_activo">Ingrediente Activo:</label>
              <select id="ingrediente_activo" v-model="id_ingrediente_activo" class="form-select mb-3">
                <option v-for="ingrediente_activo in ingredientes_activos" :key="ingrediente_activo.id" :value="ingrediente_activo.id">
                  {{ ingrediente_activo.nombre }}
                </option>
              </select>

              <label for="cantidadIngrediente">Cantidad Ingrediente Activo (en KG):</label>
              <input type="text" id="cantidadIngrediente" v-model="cantidadIngrediente" placeholder="Ingrese la cantidad" class="form-control mb-3">
              
              <label for="carbamato">Carbamato de amonio (en KG):</label>
              <input type="text" id="carbamato" v-model="carbamato" placeholder="Ingrese la cantidad" class="form-control mb-3">

              <label for="talco">Talco (sulfato de bario) (en KG):</label>
              <input type="text" id="talco" v-model="talco" placeholder="Ingrese la cantidad" class="form-control mb-3">

              <label for="grafito">Grafito (en KG):</label>
              <input type="text" id="grafito" v-model="grafito" placeholder="Ingrese la cantidad" class="form-control mb-3">

              <label for="estearato">Estearato de zinc (en KG):</label>
              <input type="text" id="estearato" v-model="estearato" placeholder="Ingrese la cantidad" class="form-control mb-3">
            </div>

            <div class="column col-md-6">
              <label for="fechaFabricacion">Fecha Fabricación:</label>
              <input type="date" id="fechaFabricacion" v-model="fechaFabricacion" class="form-control mb-3">

              <label for="operador_1">Seleccionar Operador N°1:</label>
              <select id="operador_1" v-model="id_operadores[0]" class="form-select mb-3">
                <option v-for="empleado in empleados" :key="empleado.id" :value="empleado.id">
                  {{ empleado.nombre }} {{ empleado.apellido }}
                </option>
              </select>

              <label for="operador_2">Seleccionar Operador N°2:</label>
              <select id="operador_2" v-model="id_operadores[1]" class="form-select mb-3">
                <option v-for="empleado in empleados" :key="empleado.id" :value="empleado.id">  
                  {{ empleado.nombre }} {{ empleado.apellido }}
                </option>
              </select>
            </div>
          </form>

          <div class="sample-section mt-4">
            <div class="mb-3">
              <label for="cantidadLotes" class="form-label">¿Cuántos lotes desea ingresar?</label>
              <input type="number" class="form-control" id="cantidadLotes" v-model="cantidadLotes" min="1" />
            </div>

            <div class="container mt-5">
              <h3>Ingresar Números de Lote</h3>
              <form>
                <table class="table table-bordered table-striped">
                  <thead>
                    <tr>
                      <th>#</th>
                      <th>Número de Lote</th>
                      <th>Número de Lote Parafinado</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr v-for="(lote, index) in lotes" :key="index">
                      <td>{{ index + 1 }}</td>
                      <td><input type="text" class="form-control" v-model="lote.value" placeholder="Ingrese el lote"></td>
                      <td><input type="text" class="form-control" v-model="lotes_parafinado[index].value" placeholder="Ingrese el lote parafinado"></td>
                    </tr>
                  </tbody>
                </table>
              </form>
            </div>
          </div>

          <br>
          <div class="container mt-4">
            <!-- Contenedor flex con botones separados -->
            <div class="d-flex justify-content-between">
              <!-- Botón de Cancelar alineado a la izquierda -->
              <button type="submit" class="btn btn-lg btn-secondary" @click="$goBackToFormulacion()">
                <i class="bi bi-backspace-fill"></i> Volver
              </button>
              <!-- Botón de Guardar alineado a la derecha -->
              <button type="submit" class="btn btn-lg btn-primary" @click="guardarRecetaMezcla">
                <i class="bi bi-save"></i> Guardar
              </button>
            </div>
          </div>
        </div>
      </div>


    </div>
  </main>
</template>

<script>
import axios from 'axios';
import BaseLayout from '@/layouts/BaseLayout.vue';
export default {
  components: {
    BaseLayout
  },
  data() {
    return {
      cantidadLotes: 1,
      lotes: [],
      lotes_parafinado: [],
      ingredientes_activos: [],
      recetaNumero: '',
      id_ingrediente_activo: '',
      cantidadIngrediente: '',
      carbamato: '',
      talco: '',
      grafito: '',
      estearato: '',
      fechaFabricacion: '',
      id_operadores: [0, 0],
      empleados: [],
    };
  },
  watch: {
    cantidadLotes(newCantidad) {
      const cantidadActual = this.lotes.length;
      if (newCantidad > cantidadActual) {
        for (let i = cantidadActual; i < newCantidad; i++) {
          this.lotes.push({ value: '' });
          this.lotes_parafinado.push({ value: '' });
        }
      } else if (newCantidad < cantidadActual) {
        this.lotes.splice(newCantidad);
        this.lotes_parafinado.splice(newCantidad);
      }
    }
  },
  methods: {
    goToRoute(routeName) {
      this.$router.push({ name: routeName });
    },
    async guardarRecetaMezcla() {
      const datosRecetaMezcla = {
        nro_receta: parseInt(this.recetaNumero),
        fecha_fabricacion: String(this.fechaFabricacion),
        id_ingrediente_activo: parseInt(this.id_ingrediente_activo),
        cantidad_ingrediente_activo: parseFloat(this.cantidadIngrediente),
        carbamato_de_amonio: parseFloat(this.carbamato),
        sulfato_de_bario: parseFloat(this.talco),
        grafito: parseFloat(this.grafito),
        estearato_de_zinc: parseFloat(this.estearato),
        id_operadores: this.id_operadores,
      };

      try {
        console.log(datosRecetaMezcla);
        const response = await axios.post('private.com/addRecetaMezcla', datosRecetaMezcla);
        if (response.data.status) {
          alert('Receta guardada exitosamente');
          //console.log(this.lotes);
          this.guardarMezclas();
          location.reload();
        } else {
          alert(`Error: ${response.data.error}`);
        }
      } catch (error) {
        alert('Error al enviar mezcla:', error);
      }
    },
    async guardarMezclas() {
      //let list_lotes = this.lotes.map(lote => parseInt(lote.value, 10));
      let list_lotes = this.lotes.map(lote => String(lote.value));
      //let list_lotes_parafinado = this.lotes_parafinado.map(lote => parseInt(lote.value, 10));
      let list_lotes_parafinado = this.lotes_parafinado.map(lote => String(lote.value));
      const datosMezclas = {
        nro_receta: parseInt(this.recetaNumero),
        fecha: String(this.fechaFabricacion),
        lotes: list_lotes,
        lotes_parafinado: list_lotes_parafinado,
      };

      try {
        const response = await axios.post('private.com/addMezcla', datosMezclas);
        if (response.data.status) {
          //alert('Mezcla guardada exitosamente');
        } else {
          alert(`Error: ${response.data.error}`);
        }
      } catch (error) {
        alert('Error al enviar mezcla:', error);
      }
    },
    async obtenerEmpleados() {
      try {
        const response = await axios.get('private.com/listEmpleado', {
          params: {
            id_seccion: localStorage.getItem('id_seccion_usuario')
          }
        });
        this.empleados = response.data; 
      } catch (error) {
        console.error('Error al obtener los empleados:', error);
      }
    },
    async obtenerIgredienteActivo() {
      try {
        const response = await axios.get('private.com/listIngredienteActivo');
        this.ingredientes_activos = response.data;
      } catch (error) {
        console.error('Error al obtener los ingredientes activos:', error);
      }
    }
  },
  created() {
    this.obtenerEmpleados();
    this.obtenerIgredienteActivo();
  }
};
</script>

<style scoped>
/* CSS para efectos de Hover y escalar en Bootstrap 5 */
.cursor-pointer {
  cursor: pointer;
}

.hover-scale:hover {
  transform: scale(1.05);
  transition: transform 0.3s ease;
}
body {
      height: 100%;
    }

    aside {
      /* border: 1px yellow solid; */
      position: fixed;
      overflow: auto;
      height: calc(100vh - 12px);
      justify-content: flex-start;
      align-self: flex-start;

    }
    nav{
      position:sticky;
    }
    main {
      position: relative;
      overflow: visible;
      margin-left: auto;
      justify-content: flex-end;
      align-self: flex-end;
    }

    #sidebarshow {
      display: none;

    }

    @media screen and (max-width: 575px) {
      #sidebarshow {
        display: inline;
      }

      #sidebartoggle {
        display: none;
      }
    }


    .b-example-divider {
  width: 100%;
  height: 3rem;
  background-color: rgba(0, 0, 0, .1);
  border: solid rgba(0, 0, 0, .15);
  border-width: 1px 0;
  box-shadow: inset 0 .5em 1.5em rgba(0, 0, 0, .1), inset 0 .125em .5em rgba(0, 0, 0, .15);
}

.b-example-vr {
  flex-shrink: 0;
  width: 1.5rem;
  height: 100vh;
}

.bi {
  vertical-align: -.125em;
  fill: currentColor;
}

.bd-mode-toggle {
  z-index: 1500;
}

.btn-toggle {
  padding: .25rem .5rem;
  font-weight: 600;
  color: var(--bs-emphasis-color);
  background-color: transparent;
}

.btn-toggle::before {
  width: 1.25em;
  line-height: 0;
  content: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' width='16' height='16' viewBox='0 0 16 16'%3e%3cpath fill='none' stroke='rgba%280,0,0,.5%29' stroke-linecap='round' stroke-linejoin='round' stroke-width='2' d='M5 14l6-6-6-6'/%3e%3c/svg%3e");
  transition: transform .35s ease;
  transform-origin: .5em 50%;
}

[data-bs-theme="dark"] .btn-toggle::before {
  content: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' width='16' height='16' viewBox='0 0 16 16'%3e%3cpath fill='none' stroke='rgba%28255,255,255,.5%29' stroke-linecap='round' stroke-linejoin='round' stroke-width='2' d='M5 14l6-6-6-6'/%3e%3c/svg%3e");
}



.btn-toggle[aria-expanded="true"]::before {
  transform: rotate(90deg);
}

.btn-toggle-nav a {
  padding: .1875rem .5rem;
  margin-top: .125rem;
  margin-left: 1.25rem;
}
.logo {
  max-width: 100%;
  height: auto;
  margin-bottom: 20px;
  border-radius: 8px;
}
</style>

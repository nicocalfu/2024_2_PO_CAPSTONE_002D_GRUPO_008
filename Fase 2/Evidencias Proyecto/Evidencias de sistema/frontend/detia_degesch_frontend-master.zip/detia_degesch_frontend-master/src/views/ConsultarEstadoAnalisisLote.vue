<template>
  <div class="consulta-container">
    <div class="top-bar">
      <img src="https://www.degesch.cl/wp-content/uploads/2023/02/Logo_DD_Claim.png" alt="Detia Degesch Logo" class="logo">
      <h1>Consultar Estado de Análisis de Lote</h1>
    </div>
    <div class="search-section">
      <label>Buscar por Fecha:</label>
      <input type="date" v-model="fechaBusqueda">
      <button class="search-button" @click="buscar">🔍</button>
    </div>
    <table class="analisis-table">
      <thead>
        <tr>
          <th>Nro Lote</th>
          <th>Fecha Fabricación</th>
          <th>Estado Análisis</th>
          <th>Cantidad Rec.</th>
          <th>Causa</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="(analisis, index) in analisisLotes" :key="index">
          <td>{{ analisis.nroLote }}</td>
          <td>{{ analisis.fechaFabricacion }}</td>
          <td>{{ analisis.estadoAnalisis }}</td>
          <td>{{ analisis.cantidadRec }}</td>
          <td>{{ analisis.causa }}</td>
        </tr>
      </tbody>
    </table>
    <button class="back-button" @click="$goBackToFormulacion()">Volver</button>
  </div>
</template>

<script>
export default {
  data() {
    return {
      fechaBusqueda: '',
      analisisLotes: [
        { nroLote: '001', fechaFabricacion: '2023-11-01', estadoAnalisis: 'Completado', cantidadRec: 100, causa: 'N/A' },
        { nroLote: '002', fechaFabricacion: '2023-11-02', estadoAnalisis: 'Pendiente', cantidadRec: 50, causa: 'Falta de material' }
        // Datos de ejemplo
      ]
    };
  },
  methods: {
    buscar() {
      alert('Buscar por fecha (funcionalidad no implementada).');
    },
    goToRoute(routeName) {
      this.$router.push({ name: routeName });
    },
  }
};
</script>

<style scoped>
.consulta-container {
  background-color: #fff;
  padding: 20px;
  border-radius: 10px;
  box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
  width: 800px;
  margin: 20px auto;
  text-align: left;
  font-family: 'Arial', sans-serif;
}
.top-bar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  background-color: #007BFF;
  padding: 10px 20px;
  border-radius: 10px 10px 0 0;
  color: white;
}
.logo {
  max-width: 100px;
  height: auto;
}
h1 {
  margin: 0;
  font-size: 24px;
}
.search-section {
  display: flex;
  align-items: center;
  margin: 20px 0;
}
label {
  font-weight: bold;
  color: #555;
  margin-right: 10px;
}
input[type="date"] {
  padding: 10px;
  border: 1px solid #ccc;
  border-radius: 5px;
  margin-right: 10px;
  transition: border-color 0.3s;
}
input:focus {
  border-color: #007BFF;
}
.search-button {
  padding: 10px 15px;
  background-color: #007BFF;
  color: white;
  border: none;
  border-radius: 5px;
  cursor: pointer;
  transition: background-color 0.3s;
}
.search-button:hover {
  background-color: #0056b3;
}
.analisis-table {
  width: 100%;
  border-collapse: collapse;
  margin-top: 10px;
}
.analisis-table th, .analisis-table td {
  border: 1px solid #ccc;
  padding: 8px;
  text-align: center;
}
.back-button {
  width: 100%;
  padding: 12px;
  background-color: #DC3545;
  color: white;
  border: none;
  border-radius: 5px;
  cursor: pointer;
  font-weight: bold;
  transition: background-color 0.3s;
  margin-top: 20px;
}
.back-button:hover {
  background-color: #c82333;
}
</style>

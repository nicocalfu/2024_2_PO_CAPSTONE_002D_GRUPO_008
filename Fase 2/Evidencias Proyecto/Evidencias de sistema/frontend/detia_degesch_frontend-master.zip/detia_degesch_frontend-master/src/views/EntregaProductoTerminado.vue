<template>
  <div class="entrega-container">
    <div class="top-bar">
      <img src="https://www.degesch.cl/wp-content/uploads/2023/02/Logo_DD_Claim.png" alt="Detia Degesch Logo" class="logo">
      <h1>Entrega de Producto Terminado</h1>
    </div>
    <form class="entrega-form">
      <div class="form-row">
        <label>Presentación:</label>
        <select v-model="presentacion">
          <option disabled value="">Seleccione una presentación</option>
          <option>Presentación 1</option>
          <option>Presentación 2</option>
        </select>
      </div>

      <div class="form-row">
        <label>Fecha:</label>
        <input type="date" v-model="fecha">
      </div>

      <div class="form-row">
        <label>Orden de Trabajo:</label>
        <input type="text" v-model="ordenTrabajo" placeholder="Ingrese la orden de trabajo">
      </div>

      <div class="lote-section">
        <table>
          <thead>
            <tr>
              <th>N° Lote</th>
              <th>Cantidad</th>
              <th>Kgs</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="(lote, index) in lotes" :key="index">
              <td><input type="text" v-model="lote.numero" placeholder="Número de lote"></td>
              <td><input type="text" v-model="lote.cantidad" placeholder="Cantidad"></td>
              <td><input type="text" v-model="lote.kgs" placeholder="Kgs"></td>
            </tr>
          </tbody>
        </table>
      </div>

      <div class="responsables-section">
        <div class="responsable">
          <label>Entrega Formulación:</label>
          <input type="text" v-model="entregaFormulacion" placeholder="Responsable">
        </div>
        <div class="responsable">
          <label>Control de Calidad:</label>
          <input type="text" v-model="controlCalidad" placeholder="Responsable">
        </div>
        <div class="responsable">
          <label>N° Ingreso:</label>
          <input type="text" v-model="numeroIngreso" placeholder="Número de ingreso">
        </div>
        <div class="responsable">
          <label>Recibe Logística:</label>
          <input type="text" v-model="recibeLogistica" placeholder="Responsable">
          <input type="date" v-model="fechaLogistica">
        </div>
      </div>

      <div class="buttons">
        <button type="button" class="save-button" @click="guardar">Guardar</button>
        <button type="button" class="print-button" @click="imprimir">Imprimir</button>
      </div>
    </form>
    <br>
    <button class="back-button" @click="$goBackToFormulacion()">Volver</button>
  </div>
</template>

<script>
export default {
  data() {
    return {
      presentacion: '',
      fecha: '',
      ordenTrabajo: '',
      lotes: [
        { numero: '', cantidad: '', kgs: '' }
      ],
      entregaFormulacion: '',
      controlCalidad: '',
      numeroIngreso: '',
      recibeLogistica: '',
      fechaLogistica: ''
    };
  },
  methods: {
    guardar() {
      alert('Datos guardados (funcionalidad no implementada).');
    },
    imprimir() {
      alert('Imprimiendo (funcionalidad no implementada).');
    },
    goToRoute(routeName) {
      this.$router.push({ name: routeName });
    },
  }
};
</script>

<style scoped>
.entrega-container {
  background-color: #fff;
  padding: 20px;
  border-radius: 10px;
  box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
  width: 800px;
  margin: 20px auto;
  text-align: left;
  font-family: 'Arial', sans-serif;
}
.top-bar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  background-color: #007BFF;
  padding: 10px 20px;
  border-radius: 10px 10px 0 0;
  color: white;
}
.logo {
  max-width: 100px;
  height: auto;
}
h1 {
  margin: 0;
  font-size: 24px;
}
.entrega-form {
  margin-top: 20px;
}
.form-row {
  margin-bottom: 15px;
}
label {
  display: block;
  margin-bottom: 8px;
  font-weight: bold;
  color: #555;
}
input, select {
  width: 100%;
  padding: 10px;
  margin-bottom: 10px;
  border: 1px solid #ccc;
  border-radius: 5px;
  box-sizing: border-box;
  transition: border-color 0.3s;
}
input:focus, select:focus {
  border-color: #007BFF;
}
.lote-section table {
  width: 100%;
  border-collapse: collapse;
  margin-bottom: 20px;
}
.lote-section th, .lote-section td {
  border: 1px solid #ccc;
  padding: 8px;
  text-align: center;
}
.responsables-section {
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 10px;
  margin-bottom: 20px;
}
.responsable {
  display: flex;
  flex-direction: column;
}
.buttons {
  display: flex;
  justify-content: space-between;
}
.save-button, .print-button {
  width: 48%;
  padding: 12px;
  background-color: #e74c3c;
  color: white;
  border: none;
  border-radius: 5px;
  cursor: pointer;
  font-weight: bold;
  transition: background-color 0.3s;
}
.save-button:hover, .print-button:hover {
  background-color: #c0392b;
}
.back-button {
  width: 30%;
  padding: 12px;
  background-color: #DC3545;
  color: white;
  border: none;
  border-radius: 5px;
  cursor: pointer;
  font-weight: bold;
  transition: background-color 0.3s;
  margin-top: 20px;
}
.back-button:hover {
  background-color: #c82333;
}
</style>

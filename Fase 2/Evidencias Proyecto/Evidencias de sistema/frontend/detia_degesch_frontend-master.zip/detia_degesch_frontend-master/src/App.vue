<!-- src/App.vue -->
<template>
  <div id="app">
    <!-- Aquí se renderizarán las vistas de acuerdo a las rutas definidas -->
    <router-view></router-view>
  </div>
</template>

<script>
export default {
  name: 'App',
};
</script>

<style>
/* Agrega estilos si es necesario */
</style>

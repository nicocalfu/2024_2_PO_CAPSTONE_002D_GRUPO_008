const { defineConfig } = require('@vue/cli-service')
module.exports = defineConfig({
  transpileDependencies: true
})

module.exports = {
  devServer: {
    host: '0.0.0.0', // Aceptar conexiones desde cualquier IP
    port: 8080,
    client: {
      webSocketURL: 'wss://localhost:8080/ws', // Usar WebSocket seguro si es necesario
    },
  },
};
from main import db, bcrypt

class IngredienteActivo(db.Model):
    __tablename__ = 'ingrediente_activo'
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    nombre = db.Column(db.String(50), nullable=False)

class Maquina(db.Model):
  __tablename__ = 'maquina'
  id = db.Column(db.Integer, primary_key=True, autoincrement=True)
  nombre = db.Column(db.String(50), nullable=False)

#Recordar, voy a separar seccion y cargo de la tabla operador
class Seccion(db.Model):
  __tablename__ = 'seccion'
  id = db.Column(db.Integer, primary_key=True, autoincrement=True)
  nombre = db.Column(db.String(50), nullable=False)

class Cargo(db.Model):
  __tablename__ = 'cargo'
  id = db.Column(db.Integer, primary_key=True, autoincrement=True)
  nombre = db.Column(db.String(50), nullable=False)

class Empleado(db.Model):
  __tablename__ = 'empleado'
  id = db.Column(db.Integer, primary_key=True, autoincrement=True)
  nombre = db.Column(db.String(50), nullable=False)
  apellido = db.Column(db.String(50), nullable=False)
  id_seccion = db.Column(db.Integer, db.ForeignKey('seccion.id'), nullable=False)
  id_cargo = db.Column(db.Integer, db.ForeignKey('cargo.id'), nullable=False)
  # Relaciones explícitas para facilitar la carga de los datos en el formulario
  #seccion = db.relationship('Seccion', backref='empleados', lazy=True)
  #cargo = db.relationship('Cargo', backref='empleados', lazy=True)

class Usuario(db.Model):
  __tablename__ = 'usuario'
  id = db.Column(db.Integer, primary_key=True, autoincrement=True)
  nombre_usuario = db.Column(db.String(50), unique=True, nullable=False)
  contrasena = db.Column(db.String(250), nullable=False)
  id_empleado = db.Column(db.Integer, db.ForeignKey('empleado.id'), nullable=False, unique=True)
  #empleado = db.relationship('Empleado', backref='empleados', lazy=True)
  def set_password(self, password):
    """Generar el hash de la contraseña"""
    self.contrasena = bcrypt.generate_password_hash(password).decode('utf-8')


class Producto(db.Model):
  __tablename__ = 'producto'
  cod_producto = db.Column(db.String(50), primary_key=True)
  nombre = db.Column(db.String(50), nullable=False)

class Turno(db.Model):
  __tablename__ = 'turno'
  id = db.Column(db.Integer, primary_key=True, autoincrement=True)
  tipo = db.Column(db.String(20), nullable=False)

class RecetaMezcla(db.Model):
  __tablename__ = 'receta_mezcla'
  nro_receta = db.Column(db.Integer, primary_key=True, unique=True, nullable=False)
  fecha_fabricacion = db.Column(db.Date, nullable=False)
  id_ingrediente_activo = db.Column(db.Integer, db.ForeignKey('ingrediente_activo.id'), nullable=False)
  cantidad_ingrediente_activo = db.Column(db.Float, nullable=False)
  carbamato_de_amonio = db.Column(db.Float, nullable=False)
  sulfato_de_bario = db.Column(db.Float, nullable=False)
  grafito = db.Column(db.Float, nullable=False)
  estearato_de_zinc = db.Column(db.Float, nullable=False)
  #ingrediente_activo = db.relationship('IngredienteActivo', backref='recetas')

class OperadorReceta(db.Model):
  __tablename__ = 'operador_receta'
  nro_receta = db.Column(db.Integer, db.ForeignKey('receta_mezcla.nro_receta'), primary_key=True)
  id_operador = db.Column(db.Integer, db.ForeignKey('empleado.id'), primary_key=True)
  receta_mezcla = db.relationship('RecetaMezcla', backref='operador_receta', cascade='all, delete-orphan', single_parent=True)

class Mezcla(db.Model):
  __tablename__ = 'mezcla'
  nro_lote = db.Column(db.String(50), primary_key=True, unique=True, nullable=False)
  nro_lote_parafinado = db.Column(db.String(50), nullable=False)
  fecha = db.Column(db.Date, nullable=False)
  nro_receta = db.Column(db.Integer, db.ForeignKey('receta_mezcla.nro_receta'), nullable=False)
  #receta_mezcla = db.relationship('RecetaMezcla', backref='mezcla', cascade='all, delete-orphan', single_parent=True)

class AnalisisParametrosQuimicos(db.Model):
  __tablename__ = 'analisis_parametros_quimicos'
  id = db.Column(db.Integer, primary_key=True, autoincrement=True)
  nro_lote = db.Column(db.String(50), db.ForeignKey('mezcla.nro_lote'), nullable=False, unique=True)
  aprobada = db.Column(db.Boolean, nullable=False)
  id_responsable = db.Column(db.Integer, db.ForeignKey('empleado.id'), nullable=False)
  fecha = db.Column(db.Date, nullable=False)
  NH4 = db.Column(db.Integer, nullable=False)
  AIP = db.Column(db.Integer, nullable=False)
  observaciones = db.Column(db.Text, nullable=False)
  mezcla = db.relationship('Mezcla', backref='analisis_parametros_quimicos', cascade='all, delete-orphan', single_parent=True)

class ProductoTerminado(db.Model):
  __tablename__ = 'producto_terminado'
  id = db.Column(db.Integer, primary_key=True, autoincrement=True)
  nro_lote = db.Column(db.String(50), db.ForeignKey('mezcla.nro_lote'), nullable=False)
  observaciones = db.Column(db.Text, nullable=False)
  cod_producto = db.Column(db.String(50), db.ForeignKey('producto.cod_producto'), nullable=False)
  id_turno = db.Column(db.Integer, db.ForeignKey('turno.id'), nullable=False)
  fecha = db.Column(db.DateTime, nullable=False)
  #Aqui abajo nueva columna de operador a empleado
  id_operador = db.Column(db.Integer, db.ForeignKey('empleado.id'), nullable=False)
  id_maquina = db.Column(db.Integer, db.ForeignKey('maquina.id'), nullable=False)
  cantidad = db.Column(db.Integer, nullable=False)
  mezcla = db.relationship('Mezcla', backref='producto_terminado', cascade='all, delete-orphan', single_parent=True)

class AnalisisProductoTerminado(db.Model):
  __tablename__ = 'analisis_producto_terminado'
  id = db.Column(db.Integer, primary_key=True, autoincrement=True)
  #Nueva columna abajo de usuario a empleado
  id_responsable = db.Column(db.Integer, db.ForeignKey('empleado.id'), nullable=False)
  id_turno = db.Column(db.Integer, db.ForeignKey('turno.id'), nullable=False)
  caja_contramuestra = db.Column(db.Integer, nullable=False)
  fecha = db.Column(db.DateTime, nullable=False)

class LoteProductoTerminadoAnalisis(db.Model):
  __tablename__ = 'lote_producto_terminado_analisis'
  id_analisis_producto_terminado = db.Column(db.Integer, db.ForeignKey('analisis_producto_terminado.id'), primary_key=True)
  id_producto_terminado = db.Column(db.Integer, db.ForeignKey('producto_terminado.id'), primary_key=True)
  producto_terminado = db.relationship('ProductoTerminado', backref='lote_producto_terminado_analisis', cascade='all, delete-orphan', single_parent=True)
  analisis_producto_terminado = db.relationship('AnalisisProductoTerminado', backref='lote_producto_terminado_analisis', cascade='all, delete-orphan', single_parent=True)

class MuestraParametrosFisicos(db.Model):
  __tablename__ = 'muestra_parametros_fisicos'
  id = db.Column(db.Integer, primary_key=True, autoincrement=True)
  nro_muestra = db.Column(db.Integer, nullable=False)
  id_analisis_producto_terminado = db.Column(db.Integer, db.ForeignKey('analisis_producto_terminado.id'), nullable=False)
  polvo = db.Column(db.Float, nullable=False)
  fracturado = db.Column(db.Integer, nullable=False)
  peso_neto = db.Column(db.Float, nullable=False)
  #analisis_producto_terminado = db.relationship('AnalisisProductoTerminado', backref='muestra_parametros_fisicos', cascade='all, delete-orphan', single_parent=True)

class MuestraTableta(db.Model):
  __tablename__ = 'muestra_tableta'
  id = db.Column(db.Integer, primary_key=True, autoincrement=True)
  id_muestra_parametros_fisicos = db.Column(db.Integer, db.ForeignKey('muestra_parametros_fisicos.id'), nullable=False)
  peso = db.Column(db.Float, nullable=False)
  dureza = db.Column(db.Float, nullable=False)
  muestra_parametros_fisicos = db.relationship('MuestraParametrosFisicos', backref='muestra_tableta', cascade='all, delete-orphan', single_parent=True)

class Autorizacion(db.Model):
  __tablename__ = 'autorizacion'
  id = db.Column(db.Integer, primary_key=True, autoincrement=True)
  id_analisis_producto_terminado = db.Column(db.Integer, db.ForeignKey('analisis_producto_terminado.id'), nullable=False, unique=True)
  numero_autorizacion = db.Column(db.Integer, nullable=False)
  cantidad = db.Column(db.Integer, nullable=False)
  id_determinacion = db.Column(db.Integer, db.ForeignKey('determinacion.id'), nullable=False)
  analisis_producto_terminado = db.relationship('AnalisisProductoTerminado', backref='autorizacion', cascade='all, delete-orphan', single_parent=True)

class Rechazo(db.Model):
  __tablename__ = 'rechazo'
  id = db.Column(db.Integer, primary_key=True, autoincrement=True)
  id_analisis_producto_terminado = db.Column(db.Integer, db.ForeignKey('analisis_producto_terminado.id'), nullable=False, unique=True)
  numero_rechazo = db.Column(db.Integer, nullable=False)
  id_determinacion = db.Column(db.Integer, db.ForeignKey('determinacion.id'), nullable=False)
  causa = db.Column(db.String(100), nullable=False)
  cantidad = db.Column(db.Integer, nullable=False)
  analisis_producto_terminado = db.relationship('AnalisisProductoTerminado', backref='rechazo', cascade='all, delete-orphan', single_parent=True)

class Determinacion(db.Model):
  __tablename__ = 'determinacion'
  id = db.Column(db.Integer, primary_key=True, autoincrement=True)
  nombre = db.Column(db.String(20), nullable=False)
#gunicorn -w 4 -b 0.0.0.0:5000 main:app
import os
import time
from flask import Flask, request, jsonify, session, Response
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import text, func, case
from sqlalchemy.orm import aliased
from datetime import datetime, timedelta, timezone
from flask_bcrypt import Bcrypt
from flask_cors import CORS
import jwt

#importacion de flask admin
from flask_admin import Admin
from flask_admin.contrib.sqla import ModelView
from flask_admin.form.widgets import Select2Widget
from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SelectField, DateField
from wtforms.validators import DataRequired, Length

#Importacion de reportlab para generar PDF
from reportlab.lib.pagesizes import letter
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph
from io import BytesIO

#importacion schemas
from flask_marshmallow import Marshmallow
from marshmallow import fields, Schema, post_load, ValidationError, validates
from marshmallow_sqlalchemy import SQLAlchemyAutoSchema

app = Flask(__name__)
#CORS(app, supports_credentials=True)
CORS(app, resources={r"/*": {"origins": "*"}}, supports_credentials=True)
app.config['DEBUG'] = True
app.config['SQLALCHEMY_DATABASE_URI'] = 'private'
app.config['SESSION_COOKIE_SAMESITE'] = 'None'  # Para permitir cookies cross-origin
app.config['SESSION_COOKIE_SECURE'] = True

app.secret_key = 'private'
db = SQLAlchemy(app)
bcrypt = Bcrypt(app)
ma = Marshmallow(app)


# Define una carpeta para guardar los PDFs generados
UPLOAD_FOLDER = './static/pdfs'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
# Asegúrate de crear la carpeta si no existe
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

#importacion models
from models import IngredienteActivo, Maquina, Empleado, Producto, Turno, RecetaMezcla, OperadorReceta, Mezcla, AnalisisParametrosQuimicos, ProductoTerminado, AnalisisProductoTerminado, LoteProductoTerminadoAnalisis, MuestraParametrosFisicos, MuestraTableta, Autorizacion, Rechazo, Seccion, Cargo, Usuario, Determinacion
#importacion schemas
from schemas import RecetaMezclaSchema, OperadorRecetaSchema, IngredienteActivoSchema, MezclaSchema, ProductoTerminadoSchema, AnalisisParametrosQuimicosSchema, AddAutorizacionSchema

#source env/bin/activate
#export FLASK_APP=main.py
#flask run

@app.route('/')
def hello_world():
    return "Hello world"


# Función para generar el PDF
def generate_pdf_autorizacion_pterminado(arreglo_definido, nro_autorizacion):
    # Crear un objeto PDF en memoria
    buffer = BytesIO()
    document = SimpleDocTemplate(buffer, pagesize=letter)

    # Crear los estilos para el texto
    styles = getSampleStyleSheet()

    # Establecer el estilo para centrar el título
    title_style = styles['Heading1']
    title_style.alignment = 1 

    #nro_autorizacion = "22"
    #arreglo_definido=[["33","test","10"],["33","test","10"]]
    
    # Definir los datos para la tabla
    data = [
                ["N° Autorización", "", nro_autorizacion],  # Primera fila
                ["Lote", "Presentación", "Cantidad"],       # Segunda fila (encabezados de la tabla)
            ] + arreglo_definido
        #["4042146-0", "P-20000", "22"],
        #["4042146-0", "P-20000", "22"],
        #["4042146-0", "P-20000", "22"]
    #]
    # Crear una tabla
    table = Table(data)
    # Definir el estilo de la tabla (alineación, colores, bordes, etc.)
    style = TableStyle([
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),  # Color de fondo de la primera fila
        ('BACKGROUND', (0, 0), (-1, 0), colors.darkblue),  # Color de fondo de la cabecera
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),  # Alinear el texto al centro
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),  # Fuente en negrita para la cabecera
        ('FONTSIZE', (0, 0), (-1, -1), 10),  # Tamaño de fuente
        ('BOTTOMPADDING', (0, 0), (-1, 0), 12),  # Espaciado debajo de la cabecera
        ('TOPPADDING', (0, 0), (-1, -1), 6),  # Espaciado encima de la tabla
        ('GRID', (0, 0), (-1, -1), 0.5, colors.black),  # Bordes de las celdas
        
        # Fusión de celdas
        #('SPAN', (columna_inicio, fila), (columna_fin, fila))
        #('SPAN', (0, 0), (4, 0)) 
    ])
    table.setStyle(style)
    title = Paragraph("AUTORIZACIÓN PARÁMETROS FÍSICOS<br/>PRODUCTO TERMINADO A LOGÍSTICA", title_style)
    footer_text_left = Paragraph(
        """
        <br/><br/><br/><br/><br/>___________________________<br/>
        Control de Calidad (firma)
        """,
        styles['Normal']
    )

    #description = Paragraph("Este documento contiene los parámetros físicos de los productos autorizados para logística.", styles['Normal'])
    # Crear el documento con el título, la descripción y la tabla
    elements = [title, table, footer_text_left]
    document.build(elements)
    # Mover el puntero al inicio del buffer
    buffer.seek(0)
    return buffer

# Ruta para generar el PDF
#@app.route("/generate_pdf")
#def generate_pdf_route():
    #buffer = generate_pdf()
    # Enviar el PDF como respuesta
    #return Response(buffer, mimetype="application/pdf", headers={"Content-Disposition": "inline; filename=autorizacion.pdf"})

def generate_pdf_rechazo_pterminado(arreglo_definido, nro_rechazo):
    # Crear un objeto PDF en memoria
    buffer = BytesIO()
    document = SimpleDocTemplate(buffer, pagesize=letter)

    # Crear los estilos para el texto
    styles = getSampleStyleSheet()

    # Establecer el estilo para centrar el título
    title_style = styles['Heading1']
    title_style.alignment = 1 

    
    # Definir los datos para la tabla
    data = [
                ["N° Rechazo", "", nro_rechazo],  # Primera fila
                ["Lote", "Presentación", "Cantidad rechazada"],       # Segunda fila (encabezados de la tabla)
            ] + arreglo_definido
        #["4042146-0", "P-20000", "22"],
        #["4042146-0", "P-20000", "22"],
        #["4042146-0", "P-20000", "22"]
    #]
    # Crear una tabla
    table = Table(data)
    # Definir el estilo de la tabla (alineación, colores, bordes, etc.)
    style = TableStyle([
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),  # Color de fondo de la primera fila
        ('BACKGROUND', (0, 0), (-1, 0), colors.darkblue),  # Color de fondo de la cabecera
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),  # Alinear el texto al centro
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),  # Fuente en negrita para la cabecera
        ('FONTSIZE', (0, 0), (-1, -1), 10),  # Tamaño de fuente
        ('BOTTOMPADDING', (0, 0), (-1, 0), 12),  # Espaciado debajo de la cabecera
        ('TOPPADDING', (0, 0), (-1, -1), 6),  # Espaciado encima de la tabla
        ('GRID', (0, 0), (-1, -1), 0.5, colors.black),  # Bordes de las celdas
        
        # Fusión de celdas
        #('SPAN', (columna_inicio, fila), (columna_fin, fila))
        #('SPAN', (0, 0), (4, 0)) 
    ])
    table.setStyle(style)
    title = Paragraph("RECHAZO PARÁMETROS FÍSICOS", title_style)
    footer_text_left = Paragraph(
        """
        <br/><br/><br/><br/><br/>___________________________<br/>
        Control de Calidad (firma)
        """,
        styles['Normal']
    )

    #description = Paragraph("Este documento contiene los parámetros físicos de los productos autorizados para logística.", styles['Normal'])
    # Crear el documento con el título, la descripción y la tabla
    elements = [title, table, footer_text_left]
    document.build(elements)
    # Mover el puntero al inicio del buffer
    buffer.seek(0)
    return buffer


def generate_pdf_receta(arreglo_definido, nro_receta):
    # Crear un objeto PDF en memoria
    buffer = BytesIO()
    document = SimpleDocTemplate(buffer, pagesize=letter)

    # Crear los estilos para el texto
    styles = getSampleStyleSheet()

    # Establecer el estilo para centrar el título
    title_style = styles['Heading1']
    title_style.alignment = 1 

    
    # Definir los datos para la tabla
    data = [
                ["N° Receta", nro_receta],  # Primera fila
                ["Lote", "Fecha"],       # Segunda fila (encabezados de la tabla)
            ] + arreglo_definido
        #["4042146-0", "P-20000", "22"],
        #["4042146-0", "P-20000", "22"],
        #["4042146-0", "P-20000", "22"]
    #]
    # Crear una tabla
    table = Table(data)
    # Definir el estilo de la tabla (alineación, colores, bordes, etc.)
    style = TableStyle([
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),  # Color de fondo de la primera fila
        ('BACKGROUND', (0, 0), (-1, 0), colors.darkblue),  # Color de fondo de la cabecera
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),  # Alinear el texto al centro
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),  # Fuente en negrita para la cabecera
        ('FONTSIZE', (0, 0), (-1, -1), 10),  # Tamaño de fuente
        ('BOTTOMPADDING', (0, 0), (-1, 0), 12),  # Espaciado debajo de la cabecera
        ('TOPPADDING', (0, 0), (-1, -1), 6),  # Espaciado encima de la tabla
        ('GRID', (0, 0), (-1, -1), 0.5, colors.black),  # Bordes de las celdas
        
        # Fusión de celdas
        #('SPAN', (columna_inicio, fila), (columna_fin, fila))
        #('SPAN', (0, 0), (4, 0)) 
    ])
    table.setStyle(style)
    title = Paragraph("INFOME DE RECETAS", title_style)
    footer_text_left = Paragraph(
        """
        <br/><br/><br/><br/><br/>___________________________<br/>
        Control de Calidad (firma)
        """,
        styles['Normal']
    )

    #description = Paragraph("Este documento contiene los parámetros físicos de los productos autorizados para logística.", styles['Normal'])
    # Crear el documento con el título, la descripción y la tabla
    elements = [title, table, footer_text_left]
    document.build(elements)
    # Mover el puntero al inicio del buffer
    buffer.seek(0)
    return buffer


#curl -X POST http://127.0.0.1:5000/login -H "Content-Type: application/json" -d '{"nombre_usuario":"john_doe_1", "contrasena":"123"}' -c cookies.txt
#curl -X POST http://127.0.0.1:5000/login -H "Content-Type: application/json" -d '{"nombre_usuario":"john_doe_2", "contrasena":"123"}' -c cookies.txt
@app.route('/login', methods=['POST'])
def login():
    try:
        prod_data = request.get_json(force=True)
        nombre_usuario = prod_data['nombre_usuario']
        contrasena = prod_data['contrasena']

        user = Usuario.query.filter_by(nombre_usuario=nombre_usuario).first()
        empleado = Empleado.query.filter_by(id=user.id_empleado).first()

        if user and bcrypt.check_password_hash(user.contrasena, contrasena):
            payload = {
                'user_id': user.id,
                'exp': datetime.now(timezone.utc) + timedelta(seconds=20)
            }
            token = jwt.encode(payload, app.config['SECRET_KEY'], algorithm='HS256')

            #Manejo de login en caso de que el usuario logeado sea administrador
            if user.id==7:
                session['id_usuario'] = user.id

                return jsonify({
                    'status': True,
                    'message': 'Inicio de sesion exitoso',
                    'id_usuario': user.id,
                    'token': token
                }),200
            else:
                session['id_usuario'] = user.id
                session['empleado_id'] = empleado.id  # Almacena el empleado_id en la sesión
                session['empleado_id_seccion'] = empleado.id_seccion  # Almacena la id de seccion en la sesion
                session['empleado_id_cargo'] = empleado.id_cargo  # Almacena el id de cargo en la sesion

                return jsonify({
                    'status': True,
                    'message': 'Inicio de sesion exitoso',
                    'id_usuario': user.id,
                    'nombre': empleado.nombre + ' ' + empleado.apellido,
                    'id_seccion': empleado.id_seccion,
                    'id_cargo': empleado.id_cargo,
                    'token': token
                }),200
            
        return jsonify({"error": "Nombre de usuario o contraseña incorrectos"}), 401
    except Exception as e:
        return jsonify({'status': False, 'message': 'Operation not permitted', 'error': str(e)})



#GET /generateInformePorReceta?nro_receta=1
@app.route('/generateInformePorReceta', methods=['GET'])
def generate_informe_por_receta():
    # Obtener el parámetro de la URL (nro_receta)
    nro_receta = request.args.get('nro_receta')
    
    # Realizar la consulta directamente sobre la tabla Mezcla
    results = db.session.query(
        Mezcla.nro_lote,  # Traemos el campo nro_lote
        Mezcla.fecha  # Traemos el campo fecha
    ).filter(
        Mezcla.nro_receta == nro_receta  # Filtro por nro_receta
    ).all()  # Traemos todos los resultados (no first())

    # Procesar los resultados y extraer los nro_lote y fecha
    #processed_results = [{"nro_lote": nro_lote, "fecha": fecha} for nro_lote, fecha in results]
    processed_results = [
        [nro_lote, fecha.strftime('%d/%m/%Y')] for nro_lote, fecha in results
    ]

    # Generar el PDF y guardarlo en un archivo
    filename = f"receta_{nro_receta}_{int(time.time())}.pdf"  # Nombre único basado en la receta
    file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)

    buffer = generate_pdf_receta(processed_results, nro_receta)

    # Guardar el PDF en el servidor
    with open(file_path, 'wb') as f:
        f.write(buffer.getvalue()) 

    # Generar el enlace de acceso al archivo
    pdf_url = f"/static/pdfs/{filename}"

    # Retornar la URL en formato JSON
    return jsonify({"pdf_link": pdf_url})
    #return jsonify(processed_results)



#GET /generateInformeAutorizacionPTerminado?numero_autorizacion=1
@app.route('/generateInformeAutorizacionPTerminado', methods=['GET'])
def generate_informe_autorizacion_p_terminado():
    # Obtener los parámetros de la URL (ajustar según lo que necesites)
    numero_autorizacion = request.args.get('numero_autorizacion')
    #numero_autorizacion = 1  # Por ejemplo, se podría obtener de la URL o de la lógica de la app

    # Realizar la consulta con db.session.query
    results = db.session.query(
        Autorizacion,  # Queremos la tabla Autorizacion
        ProductoTerminado.nro_lote,  # Traemos el campo nro_lote de ProductoTerminado
        Producto  # Traemos la información del producto
    ).select_from(
        Autorizacion  # Establecemos la tabla base desde la cual realizaremos los joins
    ).join(
        AnalisisProductoTerminado,  # Hacemos un JOIN con la tabla AnalisisProductoTerminado
        AnalisisProductoTerminado.id == Autorizacion.id_analisis_producto_terminado  # Condición de la unión
    ).join(
        LoteProductoTerminadoAnalisis,  # Hacemos un JOIN con la tabla LoteProductoTerminadoAnalisis
        LoteProductoTerminadoAnalisis.id_analisis_producto_terminado == AnalisisProductoTerminado.id  # Condición de la unión
    ).join(
        ProductoTerminado,  # Hacemos un JOIN con la tabla ProductoTerminado
        ProductoTerminado.id == LoteProductoTerminadoAnalisis.id_producto_terminado  # Condición de la unión
    ).join(
        Producto,  # Hacemos un JOIN con la tabla Producto
        Producto.cod_producto == ProductoTerminado.cod_producto  # Condición de la unión
    ).filter(
        Autorizacion.numero_autorizacion == numero_autorizacion  # Filtro por numero_autorizacion
    ).all()  # Traemos todos los resultados (no first())

    # Procesar los resultados y estructurarlos en el formato de matriz
    processed_results = []
    for autorizacion, nro_lote, producto in results:
        # Agregar los valores directamente a la lista, sin encapsular en otras listas
        processed_results.append([
            nro_lote,  # Directamente el nro_lote como un string
            producto.nombre,  # Presentación como un string
            str(autorizacion.cantidad) # Cantidad como un número
        ])

    # Generar el PDF y guardarlo en un archivo
    filename = f"producto_terminado_autorizacion_{numero_autorizacion}_{int(time.time())}.pdf"  # Nombre único basado en la autorización
    file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)

    buffer = generate_pdf_autorizacion_pterminado(processed_results, numero_autorizacion)

    # Guardar el PDF en el servidor
    with open(file_path, 'wb') as f:
        f.write(buffer.getvalue()) 

    # Generar el enlace de acceso al archivo
    pdf_url = f"/static/pdfs/{filename}"

    # Retornar la URL en formato JSON
    return jsonify({"pdf_link": pdf_url})
    # Devolver la lista de resultados procesados en el formato requerido
    #return jsonify(processed_results)
    #buffer = generate_pdf_autorizacion_pterminado(processed_results, numero_autorizacion)
    # Enviar el PDF como respuesta
    #return Response(buffer, mimetype="application/pdf", headers={"Content-Disposition": "inline; filename=autorizacion.pdf"})



#GET /generateInformeRechazoPTerminado?numero_rechazo=1
@app.route('/generateInformeRechazoPTerminado', methods=['GET'])
def generate_informe_rechazo_p_terminado():
    # Obtener los parámetros de la URL (ajustar según lo que necesites)
    numero_rechazo = request.args.get('numero_rechazo')
    #numero_rechazo = 1  # Por ejemplo, se podría obtener de la URL o de la lógica de la app

    # Realizar la consulta con db.session.query
    results = db.session.query(
        Rechazo,  # Queremos la tabla Rechazo
        ProductoTerminado.nro_lote,  # Traemos el campo nro_lote de ProductoTerminado
        Producto  # Traemos la información del producto
    ).select_from(
        Rechazo  # Establecemos la tabla base desde la cual realizaremos los joins
    ).join(
        AnalisisProductoTerminado,  # Hacemos un JOIN con la tabla AnalisisProductoTerminado
        AnalisisProductoTerminado.id == Rechazo.id_analisis_producto_terminado  # Condición de la unión
    ).join(
        LoteProductoTerminadoAnalisis,  # Hacemos un JOIN con la tabla LoteProductoTerminadoAnalisis
        LoteProductoTerminadoAnalisis.id_analisis_producto_terminado == AnalisisProductoTerminado.id  # Condición de la unión
    ).join(
        ProductoTerminado,  # Hacemos un JOIN con la tabla ProductoTerminado
        ProductoTerminado.id == LoteProductoTerminadoAnalisis.id_producto_terminado  # Condición de la unión
    ).join(
        Producto,  # Hacemos un JOIN con la tabla Producto
        Producto.cod_producto == ProductoTerminado.cod_producto  # Condición de la unión
    ).filter(
        Rechazo.numero_rechazo == numero_rechazo  # Filtro por numero_rechazo
    ).all()  # Traemos todos los resultados (no first())

    # Procesar los resultados y estructurarlos en el formato de matriz
    processed_results = []
    for rechazo, nro_lote, producto in results:
        # Agregar los valores directamente a la lista, sin encapsular en otras listas
        processed_results.append([
            nro_lote,  # Directamente el nro_lote como un string
            producto.nombre,  # Presentación como un string
            str(rechazo.cantidad) # Cantidad como un número
        ])

    # Generar el PDF y guardarlo en un archivo
    filename = f"producto_terminado_rechazo_{numero_rechazo}_{int(time.time())}.pdf"  # Nombre único basado en la autorización
    file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)

    buffer = generate_pdf_rechazo_pterminado(processed_results, numero_rechazo)

    # Guardar el PDF en el servidor
    with open(file_path, 'wb') as f:
        f.write(buffer.getvalue()) 

    # Generar el enlace de acceso al archivo
    pdf_url = f"/static/pdfs/{filename}"

    # Retornar la URL en formato JSON
    return jsonify({"pdf_link": pdf_url})



#curl -X POST http://127.0.0.1:5000/addRecetaMezcla -H "Content-Type: application/json" -d '{"nro_receta":10, "fecha_fabricacion":"2023-10-27T15:30:00Z", "id_ingrediente_activo":1, "cantidad_ingrediente_activo":2, "carbamato_de_amonio":2, "sulfato_de_bario":2, "grafito":2, "estearato_de_zinc":2, "id_operadores":[1,2]}' -b cookies.txt
@app.route('/addRecetaMezcla', methods=['POST'])  #añadir nueva receta a la BD
def add_receta_mezcla():
    try:
        prod_data = request.get_json(force=True)

        receta_schema = RecetaMezclaSchema()
        receta_data = receta_schema.load(prod_data, session=db.session)

        if 'empleado_id' in session:
            if session.get('empleado_id_seccion') == 4 and session.get('empleado_id_cargo') == 13:
                rm = RecetaMezcla()
                rm.nro_receta = prod_data['nro_receta']
                rm.id_ingrediente_activo = prod_data['id_ingrediente_activo']
                rm.cantidad_ingrediente_activo = prod_data['cantidad_ingrediente_activo']
                rm.carbamato_de_amonio = prod_data['carbamato_de_amonio']
                rm.sulfato_de_bario = prod_data['sulfato_de_bario']
                rm.grafito = prod_data['grafito']
                rm.estearato_de_zinc = prod_data['estearato_de_zinc']
                #Transformacion de fecha, desde formato ISO 8601
                fecha_fabricacion_str = prod_data['fecha_fabricacion']
                fecha_fabricacion = datetime.fromisoformat(fecha_fabricacion_str.replace("Z", "+00:00")).date()
                rm.fecha_fabricacion = fecha_fabricacion
                
                db.session.add(rm)
                db.session.commit()
                
                if len(prod_data['id_operadores']) != len(set(prod_data['id_operadores'])):
                    return jsonify({'status': False, 'message': 'Los operadores no pueden estar repetidos'})

                operadores = []
                for i in prod_data['id_operadores']:
                    op = OperadorReceta()
                    op.id_operador = i
                    op.nro_receta = prod_data['nro_receta']
                    operadores.append(op)
                
                db.session.add_all(operadores)
                db.session.commit() 

                return jsonify({'status': True, 'message': 'Receta guardada con exito'})
            else:
                return jsonify({'status': False, 'message': 'Usuario rechazado: tipo de usuario no aceptado'})
        else:
            return jsonify({'status': False, 'message': 'Usuario no ha iniciado sesion'})
    except Exception as e:
        db.session.rollback()
        return jsonify({'status': False, 'message': 'Operation not permitted', 'error': str(e)})


#curl -X POST https://automatic-zebra-9r4v9496rg427gx-5000.app.github.dev/addMezcla -H "Content-Type: application/json" -d "{\"user_id\":\"1\", \"fecha\":\"2024-10-27T15:30:00Z\", \"nro_receta\":\"1\", \"lotes\":[3,4,5], \"lotes_parafinado\":[3,4,5]}"
@app.route('/addMezcla', methods=['POST'])  #añadir nuevas mezclas a la BD
def add_mezcla():
    try:
        prod_data = request.get_json(force=True)

        mezcla_schema = MezclaSchema()
        mezcla_data = mezcla_schema.load(prod_data, session=db.session)

        if 'empleado_id' in session:
            if session.get('empleado_id_seccion') == 4 and session.get('empleado_id_cargo') == 13:
                nro_receta_guardada = prod_data['nro_receta']

                fecha_str = prod_data['fecha']
                fecha_guardada = datetime.fromisoformat(fecha_str.replace("Z", "+00:00")).date()

                lotes = prod_data['lotes']
                lotes_parafinado = prod_data['lotes_parafinado']
                lotes_to_db = []

                if len(lotes) == len(lotes_parafinado):
                    for i in range(len(lotes)):
                        print("Lote :", lotes[i])
                        print("Lote parafinado: ", lotes_parafinado[i])
                        m = Mezcla()
                        m.nro_receta = nro_receta_guardada
                        m.fecha = fecha_guardada
                        m.nro_lote = lotes[i]
                        m.nro_lote_parafinado = lotes_parafinado[i]
                        lotes_to_db.append(m)
                else:
                    return jsonify({'status': False, 'message': 'Debe ingresar por cada lote, el lote de parafinado o viceversa'})

                # Agregar todos los lotes a la sesión y hacer commit
                db.session.add_all(lotes_to_db)
                db.session.commit() 

                return jsonify({'status': True, 'message': 'Lotes guardados con exito'})
            else:
                return jsonify({'status': False, 'message': 'Usuario rechazado: tipo de usuario no aceptado'})
        else:
            return jsonify({'status': False, 'message': 'Usuario no encontrado'})
    except Exception as e:
        #db.session.rollback()
        return jsonify({'status': False, 'message': 'Operation not permitted', 'error': str(e)})


@app.route('/addAnalisisMezcla', methods=['POST'])  #añadir analisis de mezcla a la BD
def add_analisis_mezcla():
    try:
        prod_data = request.get_json(force=True)

        analisis_mezcla_schema = AnalisisParametrosQuimicosSchema()
        analisis_mezcla_data = analisis_mezcla_schema.load(prod_data, session=db.session)

        if 'empleado_id' in session:
            if session.get('empleado_id_seccion') == 2 and session.get('empleado_id_cargo') == 18:
                am = AnalisisParametrosQuimicos()
                am.nro_lote = prod_data['nro_lote']
                am.aprobada = prod_data['aprobada']
                #am.id_responsable = prod_data['user_id']
                am.id_responsable = session.get('empleado_id')
                am.NH4 = prod_data['NH4']
                am.AIP = prod_data['AIP']
                am.observaciones = prod_data['observaciones']
                #Transformacion de fecha, desde formato ISO 8601
                fecha_str = prod_data['fecha']
                fecha = datetime.fromisoformat(fecha_str.replace("Z", "+00:00")).date()
                am.fecha = fecha

                db.session.add(am)
                db.session.commit()
                return jsonify({'status': True, 'message': 'Analisis mezcla guardado con exito'})
            else:
                return jsonify({'status': False, 'message': 'Usuario rechazado: tipo de usuario no aceptado'})
        else:
            return jsonify({'status': False, 'message': 'Usuario no encontrado'})
    except Exception as e:
        db.session.rollback()
        return jsonify({'status': False, 'message': 'Operation not permitted', 'error': str(e)}) 


@app.route('/addProductoTerminado', methods=['POST'])  #añadir nueva ingreso de producto terminado a la BD
def add_producto_terminado():
    try:
        prod_data = request.get_json(force=True)

        producto_terminado_schema = ProductoTerminadoSchema()
        producto_terminado_data = producto_terminado_schema.load(prod_data, session=db.session)

        if 'empleado_id' in session:
            if session.get('empleado_id_seccion') == 4 and session.get('empleado_id_cargo') == 13:
                pt = ProductoTerminado()
                pt.nro_lote = prod_data['nro_lote']
                pt.observaciones = prod_data['observaciones']
                pt.cod_producto = prod_data['cod_producto']
                pt.id_turno = prod_data['id_turno']
                pt.id_maquina = prod_data['id_maquina']
                pt.id_operador = prod_data['id_operador']
                pt.cantidad = prod_data['cantidad']
                #Transformacion de fecha, desde formato ISO 8601
                fecha_str = prod_data['fecha']
                fecha = datetime.fromisoformat(fecha_str.replace("Z", "+00:00")).date()
                pt.fecha = fecha

                db.session.add(pt)
                db.session.commit()
                return jsonify({'status': True, 'message': 'Ingreso de producto terminado guardado con exito'})
            else:
                return jsonify({'status': False, 'message': 'Usuario rechazado: tipo de usuario no aceptado'})
        else:
            return jsonify({'status': False, 'message': 'Usuario no encontrado'})
    except Exception as e:
        db.session.rollback()
        return jsonify({'status': False, 'message': 'Operation not permitted', 'error': str(e)})
        

#curl -X POST http://127.0.0.1:5000/addAnalisisProductoTerminado -H "Content-Type: application/json" -d '{"nro_lote":"1", "fecha":"2023-10-27T15:30:00Z", "id_turno":1, "caja_contramuestra":1}'
@app.route('/addAnalisisProductoTerminado', methods=['POST'])  #añadir nuevo ingreso de analisis de producto terminado a la BD
def add_analisis_producto_terminado():
    try:
        prod_data = request.get_json(force=True)
        
        if 'empleado_id' in session:
            if session.get('empleado_id_seccion') == 2 and session.get('empleado_id_cargo') == 18:
                # Buscamos el producto terminado por el nro_lote
                busqueda_p_terminado = ProductoTerminado.query.filter_by(nro_lote=prod_data['nro_lote']).first()

                # Verificamos si se encontró el producto
                if busqueda_p_terminado is None:
                    return jsonify({'status': False, 'message': 'Este lote aun no ha sido ingresado como producto terminado'})

                # Buscamos el lote de producto terminado relacionado
                busqueda_analisis_p_terminado = LoteProductoTerminadoAnalisis.query.filter_by(id_producto_terminado=busqueda_p_terminado.id).first()

                # Verificamos si se encontró el lote
                if busqueda_analisis_p_terminado is not None:
                    return jsonify({'status': False, 'message': 'Este lote ya fue ingresado'})
                else:
                    apt = AnalisisProductoTerminado()
                    #apt.id_responsable = prod_data['user_id']
                    apt.id_responsable = session.get('empleado_id')
                    apt.id_turno = prod_data['id_turno']
                    apt.caja_contramuestra = prod_data['caja_contramuestra']
                    #Transformacion de fecha, desde formato ISO 8601
                    fecha_str = prod_data['fecha']
                    fecha = datetime.fromisoformat(fecha_str.replace("Z", "+00:00")).date()
                    apt.fecha = fecha
                    db.session.add(apt)
                    db.session.commit()
                    id_analisis_producto_terminado = apt.id

                    productos_terminados = ProductoTerminado.query.filter_by(nro_lote=prod_data['nro_lote']).all()
                    for producto_terminado in productos_terminados:
                        lpa = LoteProductoTerminadoAnalisis()
                        lpa.id_analisis_producto_terminado = id_analisis_producto_terminado
                        lpa.id_producto_terminado = producto_terminado.id  # Asignar la id del producto terminado actual
                        db.session.add(lpa)
                    db.session.commit()

                    return jsonify({'status': True, 'message': 'Ingreso de analisis de producto terminado guardado con exito'})
                
            else:
                return jsonify({'status': False, 'message': 'Usuario rechazado: tipo de usuario no aceptado'})
        else:
            return jsonify({'status': False, 'message': 'Usuario no encontrado'})
    except Exception as e:
        db.session.rollback()
        return jsonify({'status': False, 'message': 'Operation not permitted', 'error': str(e)})
    
"""
#curl -X POST http://127.0.0.1:5000/addMuestraProductoTerminado -H "Content-Type: application/json" -d '{"user_id":1, "nro_lote":"1", "polvo_muestra1":10, "polvo_muestra2":15, "polvo_muestra3":20, "fracturado_muestra1":25, "fracturado_muestra2":30, "fracturado_muestra3":35, "peso_neto_muestra1":40, "peso_neto_muestra2":45, "peso_neto_muestra3":50, "pesos_muestra1": [1, 2, 3], "pesos_muestra2": [1, 2, 3], "pesos_muestra3": [1, 2, 3], "durezas_muestra1": [1, 2, 3], "durezas_muestra2": [1, 2, 3], "durezas_muestra3": [1, 2, 3]}'
#Añadir muestra del producto terminado
@app.route('/addMuestraProductoTerminado', methods=['POST'])  #añadir nuevas mezclas a la BD
def add_muestra_producto_terminado():
    try:
        prod_data = request.get_json(force=True)
        
        producto_terminado = ProductoTerminado.query.filter_by(nro_lote=prod_data['nro_lote']).first()
        lote_producto_terminado_analisis = LoteProductoTerminadoAnalisis.query.filter_by(id_producto_terminado=producto_terminado.id).first()

        #Consulta si hay muestras guardadas con anterioridad
        max_nro_muestra = db.session.query(func.max(MuestraParametrosFisicos.nro_muestra)) \
                    .filter(MuestraParametrosFisicos.id_analisis_producto_terminado == lote_producto_terminado_analisis.id_analisis_producto_terminado) \
                    .scalar()

        if max_nro_muestra is None:
            max_nro_muestra = 0

        if 'empleado_id' in session:
            if session.get('empleado_id_seccion') == 4 and session.get('empleado_id_cargo') == 13:

                muestras = []  # Inicializa la lista de muestras

                # Inicializa el contador
                i = 1

                # Recorrer el diccionario
                while True:
                    # Genera las claves que estás buscando
                    polvo_key = "polvo_muestra" + str(i)
                    fracturado_key = "fracturado_muestra" + str(i)
                    peso_neto_key = "peso_neto_muestra" + str(i)

                    #Lista de pesos y durezas por número de muestra
                    pesos_key = "pesos_muestra" + str(i)
                    durezas_key = "durezas_muestra" + str(i)

                    # Condición de parada
                    if polvo_key not in prod_data and fracturado_key not in prod_data and peso_neto_key not in prod_data and pesos_key not in prod_data and durezas_key not in prod_data:
                        break

                    #Inicilizacion y llenado del objeto MuestraParametrosFisicos
                    mpf = MuestraParametrosFisicos()
                    mpf.id_analisis_producto_terminado = lote_producto_terminado_analisis.id_analisis_producto_terminado
                    mpf.nro_muestra = i + max_nro_muestra
                    
                    # Verifica si alguna de las claves existe en prod_data
                    if polvo_key in prod_data:
                        value = prod_data[polvo_key]
                        if value is not None:
                            mpf.polvo = value
                        else:
                            return jsonify({'status': False, 'message': 'Debe ingresar un valor válido para Polvo'})
                    
                    if fracturado_key in prod_data:
                        value = prod_data[fracturado_key]
                        if value is not None:
                            mpf.fracturado = value
                        else:
                            return jsonify({'status': False, 'message': 'Debe ingresar un valor válido para Fracturado'})
                    
                    if peso_neto_key in prod_data:
                        value = prod_data[peso_neto_key]
                        if value is not None:
                            mpf.peso_neto = value
                        else:
                            return jsonify({'status': False, 'message': 'Debe ingresar un valor válido para Peso Neto'})
                    
                    db.session.add(mpf)
                    db.session.commit()
                    id_muestra = mpf.id

                    mt = MuestraTableta()
                    mt.id_muestra_parametros_fisicos = id_muestra
                    
                    if len(prod_data[pesos_key]) == len(prod_data[durezas_key]):
                        for x in range(len(prod_data[pesos_key])):
                            mt = MuestraTableta()
                            mt.id_muestra_parametros_fisicos = id_muestra
                            
                            # Asigna el peso y la dureza correspondientes
                            mt.peso = prod_data[pesos_key][x]
                            mt.dureza = prod_data[durezas_key][x]

                            # Agrega el objeto a la sesión
                            db.session.add(mt)

                        # Commit una sola vez después del bucle
                        db.session.commit()
                    else:
                        return jsonify({'status': False, 'message': 'Debe ingresar cantidad total de muestra de parametros fisicos'})
                    
                    # Incrementa el contador
                    i += 1

                #for muestra in muestras:
                #    print(f"Polvo: {muestra.polvo}, Fracturado: {muestra.fracturado}, Peso Neto: {muestra.peso_neto}")
 
                return jsonify({'status': True, 'message': 'Muestras guardadas con exito'})
                
            else:
                return jsonify({'status': False, 'message': 'Usuario rechazado: tipo de usuario no aceptado'})
        else:
            return jsonify({'status': False, 'message': 'Usuario no encontrado'})
    except Exception as e:
        db.session.rollback()
        return jsonify({'status': False, 'message': 'Operation not permitted', 'error': str(e)})
"""
#curl -X POST http://127.0.0.1:5000/addMuestraProductoTerminado -H "Content-Type: application/json" -d '{"user_id":1, "nro_lote":"1", "polvo_muestra1":10, "polvo_muestra2":15, "polvo_muestra3":20, "fracturado_muestra1":25, "fracturado_muestra2":30, "fracturado_muestra3":35, "peso_neto_muestra1":40, "peso_neto_muestra2":45, "peso_neto_muestra3":50, "pesos_muestra1": [1, 2, 3], "pesos_muestra2": [1, 2, 3], "pesos_muestra3": [1, 2, 3], "durezas_muestra1": [1, 2, 3], "durezas_muestra2": [1, 2, 3], "durezas_muestra3": [1, 2, 3]}'
#Añadir muestra del producto terminado
@app.route('/addMuestraProductoTerminado', methods=['POST'])  #añadir nuevas mezclas a la BD
def add_muestra_producto_terminado():
    try:
        prod_data = request.get_json(force=True)
        
        producto_terminado = ProductoTerminado.query.filter_by(nro_lote=prod_data['nro_lote']).first()
        lote_producto_terminado_analisis = LoteProductoTerminadoAnalisis.query.filter_by(id_producto_terminado=producto_terminado.id).first()

        #Consulta si hay muestras guardadas con anterioridad
        max_nro_muestra = db.session.query(func.max(MuestraParametrosFisicos.nro_muestra)) \
                    .filter(MuestraParametrosFisicos.id_analisis_producto_terminado == lote_producto_terminado_analisis.id_analisis_producto_terminado) \
                    .scalar()

        if max_nro_muestra is None:
            max_nro_muestra = 0

        if 'empleado_id' in session:
            if session.get('empleado_id_seccion') == 2 and session.get('empleado_id_cargo') == 18:
                
                mpf = MuestraParametrosFisicos()
                mpf.id_analisis_producto_terminado = lote_producto_terminado_analisis.id_analisis_producto_terminado
                mpf.nro_muestra = max_nro_muestra +1

                if mpf.nro_muestra > 3:
                    return jsonify({'status': False, 'message': 'Solo se pueden ingresar un maximo de 3 muestras por lote'})
                else:
                    mpf.polvo = prod_data['polvo']
                    mpf.fracturado = prod_data['fracturado']
                    mpf.peso_neto = prod_data['peso_neto']

                    db.session.add(mpf)
                    db.session.commit()
                    id_muestra = mpf.id

                    mt = MuestraTableta()
                    mt.id_muestra_parametros_fisicos = id_muestra

                    if len(prod_data['pesos']) == len(prod_data['durezas']):
                        for x in range(len(prod_data['pesos'])):
                            mt = MuestraTableta()
                            mt.id_muestra_parametros_fisicos = id_muestra
                            
                            # Asigna el peso y la dureza correspondientes
                            mt.peso = prod_data['pesos'][x]
                            mt.dureza = prod_data['durezas'][x]

                            # Agrega el objeto a la sesión
                            db.session.add(mt)

                        # Commit una sola vez después del bucle
                        db.session.commit()
                        return jsonify({'status': True, 'message': 'Muestra guardadas con exito'})
                    else:
                        return jsonify({'status': False, 'message': 'Debe ingresar cantidad total de tabletas'})
            else:
                return jsonify({'status': False, 'message': 'Usuario rechazado: tipo de usuario no aceptado'})
        else:
            return jsonify({'status': False, 'message': 'Usuario no encontrado'})
    except Exception as e:
        db.session.rollback()
        return jsonify({'status': False, 'message': 'Operation not permitted', 'error': str(e)})


#curl -X POST http://127.0.0.1:5000/addAutorizacionProductoTerminado -H "Content-Type: application/json" -d '{"nro_lote":"1", "id_determinacion":2, "numero_autorizacion":1, "cantidad_aprobada": 1, "numero_rechazo":1, "cantidad_rechazada": 1, "causa":"test"}'
@app.route('/addAutorizacionProductoTerminado', methods=['POST'])  #Ingresar autorizacion de lote a la BD
def add_autorizacion_producto_terminado():
    try:
        prod_data = request.get_json(force=True)
        
        autorizacion_schema = AddAutorizacionSchema()
        autorizacion_data = autorizacion_schema.load(prod_data)

        if 'empleado_id' in session:
            if session.get('empleado_id_seccion') == 2 and session.get('empleado_id_cargo') == 18:
                producto_terminado = ProductoTerminado.query.filter_by(nro_lote=prod_data['nro_lote']).first()
                lote_producto_terminado_analisis = LoteProductoTerminadoAnalisis.query.filter_by(id_producto_terminado=producto_terminado.id).first()

                if lote_producto_terminado_analisis is None:
                    return jsonify({'status': False, 'message': 'Para ingresar la decisión de un lote, primero debe ingresar los parametros'})

                if prod_data['id_determinacion'] == 1:
                    a = Autorizacion()
                    a.id_analisis_producto_terminado = lote_producto_terminado_analisis.id_analisis_producto_terminado
                    a.numero_autorizacion = prod_data['numero_autorizacion']
                    a.cantidad = prod_data['cantidad_aprobada']
                    a.id_determinacion = prod_data['id_determinacion']
                    db.session.add(a)
                    db.session.commit()

                elif prod_data['id_determinacion'] == 2:
                    a = Autorizacion()
                    a.id_analisis_producto_terminado = lote_producto_terminado_analisis.id_analisis_producto_terminado
                    a.numero_autorizacion = prod_data['numero_autorizacion']
                    a.cantidad = prod_data['cantidad_aprobada']
                    a.id_determinacion = prod_data['id_determinacion']
                    
                    r = Rechazo()
                    r.id_analisis_producto_terminado = lote_producto_terminado_analisis.id_analisis_producto_terminado
                    r.numero_rechazo = prod_data['numero_rechazo']
                    r.id_determinacion = prod_data['id_determinacion']
                    r.cantidad = prod_data['cantidad_rechazada']
                    r.causa = prod_data['causa']

                    db.session.add(a)
                    db.session.add(r)
                    db.session.commit()

                elif prod_data['id_determinacion'] == 3:
                    r = Rechazo()
                    r.id_analisis_producto_terminado = lote_producto_terminado_analisis.id_analisis_producto_terminado
                    r.numero_rechazo = prod_data['numero_rechazo']
                    r.id_determinacion = prod_data['id_determinacion']
                    r.cantidad = prod_data['cantidad_rechazada']
                    r.causa = prod_data['causa']
                    db.session.add(r)
                    db.session.commit()

                return jsonify({'status': True, 'message': 'Ingreso de analisis guardado con exito'})
            else:
                return jsonify({'status': False, 'message': 'Usuario rechazado: tipo de usuario no aceptado'})
        else:
            return jsonify({'status': False, 'message': 'Usuario no encontrado'})
    except ValidationError as err:
        # Si ocurre un error de validación, devuelve el mensaje de error
        return jsonify(err.messages), 400
    except Exception as e:
        db.session.rollback()
        return jsonify({'status': False, 'message': 'Operation not permitted', 'error': str(e)})


"""
Edición del producto terminado guardado
curl -X PUT http://localhost:5000/editProductoTerminado/1 \
     -H "Content-Type: application/json" \
     -d '{"user_id": 2, "cantidad": 30, "observaciones": "prueba edicion"}'
"""
@app.route('/editProductoTerminado/<id>', methods=['PUT'])
def edit_producto_terminado(id):
    try:
        prod_data = request.get_json(force=True)
        
        instance = ProductoTerminado.query.get(id)

        if 'empleado_id' in session:
            if session.get('empleado_id_seccion') == 4 and session.get('empleado_id_cargo') == 13:
                for key, value in prod_data.items():
                    if hasattr(instance, key):  # Verifica si el atributo existe en el modelo
                        setattr(instance, key, value)  # Actualiza el atributo

                db.session.commit()
                return jsonify({'status': True, 'message': 'Edicion producto terminado guardada con exito'})
            else:
                return jsonify({'status': False, 'message': 'Usuario rechazado: tipo de usuario no aceptado'})
        else:
            return jsonify({'status': False, 'message': 'Usuario no encontrado'})
    except Exception as e:
        db.session.rollback()
        return jsonify({'status': False, 'message': 'Operation not permitted', 'error': str(e)}) 


"""
Edición del analisis de parametros quimicos
curl -X PUT http://localhost:5000/editAnalisisMezcla/1 \
     -H "Content-Type: application/json" \
     -d '{"NH4": 30, "AIP": 40}'
"""
@app.route('/editAnalisisMezcla/<id>', methods=['PUT'])
def edit_analisis_mezcla(id):
    try:
        prod_data = request.get_json(force=True)
        
        instance = AnalisisParametrosQuimicos.query.get(id)

        if 'empleado_id' in session:
            if session.get('empleado_id_seccion') == 2 and session.get('empleado_id_cargo') == 18:
                for key, value in prod_data.items():
                    if hasattr(instance, key):  # Verifica si el atributo existe en el modelo
                        setattr(instance, key, value)  # Actualiza el atributo

                db.session.commit()
                return jsonify({'status': True, 'message': 'Analisis mezcla guardado con exito'})
            else:
                return jsonify({'status': False, 'message': 'Usuario rechazado: tipo de usuario no aceptado'})
        else:
            return jsonify({'status': False, 'message': 'Usuario no encontrado'})
    except Exception as e:
        db.session.rollback()
        return jsonify({'status': False, 'message': 'Operation not permitted', 'error': str(e)})


"""
Edición del analisis de producto terminado, esto lo agregué recien
curl -X PUT http://localhost:5000/editAnalisisProductoTerminado/1 \
     -H "Content-Type: application/json" \
     -d '{"user_id": 2, "caja_contramuestra": 30}'
"""
@app.route('/editAnalisisProductoTerminado/<nro_lote>', methods=['PUT'])
def edit_analisis_producto_terminado(nro_lote):
    try:
        prod_data = request.get_json(force=True)
        

        producto_terminado = ProductoTerminado.query.filter_by(nro_lote=nro_lote).first()
        lote_producto_terminado_analisis = LoteProductoTerminadoAnalisis.query.filter_by(id_producto_terminado=producto_terminado.id).first()

        instance = AnalisisProductoTerminado.query.get(lote_producto_terminado_analisis.id_analisis_producto_terminado)

        if 'empleado_id' in session:
            if session.get('empleado_id_seccion') == 2 and session.get('empleado_id_cargo') == 18:
                for key, value in prod_data.items():
                    if hasattr(instance, key):  # Verifica si el atributo existe en el modelo
                        setattr(instance, key, value)  # Actualiza el atributo

                db.session.commit()
                return jsonify({'status': True, 'message': 'Analisis producto terminado guardado con exito'})
            else:
                return jsonify({'status': False, 'message': 'Usuario rechazado: tipo de usuario no aceptado'})
        else:
            return jsonify({'status': False, 'message': 'Usuario no encontrado'})
    except Exception as e:
        db.session.rollback()
        return jsonify({'status': False, 'message': 'Operation not permitted', 'error': str(e)})
    

"""
Edición de de muestra de producto terminado
curl -X PUT http://localhost:5000/editMuestraProductoTerminado/1 \
     -H "Content-Type: application/json" \
     -d '{"user_id": 2, "nro_muestra": 1, "polvo":1, "fracturado":2, "peso_neto":3}'
"""
@app.route('/editMuestraProductoTerminado/<nro_lote>', methods=['PUT'])
def edit_muestra_producto_terminado(nro_lote):
    try:
        prod_data = request.get_json(force=True)
        

        producto_terminado = ProductoTerminado.query.filter_by(nro_lote=nro_lote).first()
        lote_producto_terminado_analisis = LoteProductoTerminadoAnalisis.query.filter_by(id_producto_terminado=producto_terminado.id).first()
        
        instance = MuestraParametrosFisicos.query.filter(
        MuestraParametrosFisicos.id_analisis_producto_terminado == lote_producto_terminado_analisis.id_analisis_producto_terminado,
        MuestraParametrosFisicos.nro_muestra == prod_data['nro_muestra']  
        ).first()

        if 'empleado_id' in session:
            if session.get('empleado_id_seccion') == 2 and session.get('empleado_id_cargo') == 18:
                for key, value in prod_data.items():
                    if hasattr(instance, key):  # Verifica si el atributo existe en el modelo
                        setattr(instance, key, value)  # Actualiza el atributo

                db.session.commit()
                return jsonify({'status': True, 'message': 'Muestra guardado con exito'})
            else:
                return jsonify({'status': False, 'message': 'Usuario rechazado: tipo de usuario no aceptado'})
        else:
            return jsonify({'status': False, 'message': 'Usuario no encontrado'})
    except Exception as e:
        db.session.rollback()
        return jsonify({'status': False, 'message': 'Operation not permitted', 'error': str(e)})
    

"""
Edición de de muestra de tabletas
curl -X PUT http://localhost:5000/editMuestraTableta/1 \
     -H "Content-Type: application/json" \
     -d '{"user_id": 2, "nro_muestra": 2, "pesos": [10, 20, 30], "durezas": [10, 20, 30]}'
"""
@app.route('/editMuestraTableta/<nro_lote>', methods=['PUT'])
def edit_muestra_tableta(nro_lote):
    try:
        prod_data = request.get_json(force=True)
        

        producto_terminado = ProductoTerminado.query.filter_by(nro_lote=nro_lote).first()
        lote_producto_terminado_analisis = LoteProductoTerminadoAnalisis.query.filter_by(id_producto_terminado=producto_terminado.id).first()
        
        muestra_parametros_fisicos = MuestraParametrosFisicos.query.filter(
        MuestraParametrosFisicos.id_analisis_producto_terminado == lote_producto_terminado_analisis.id_analisis_producto_terminado,
        MuestraParametrosFisicos.nro_muestra == prod_data['nro_muestra']  
        ).first()

        instances = MuestraTableta.query.filter_by(id_muestra_parametros_fisicos=muestra_parametros_fisicos.id).all()

        if 'empleado_id' in session:
            if session.get('empleado_id_seccion') == 2 and session.get('empleado_id_cargo') == 18:
                #son igual la cantidad de pesos ingresados y los guardados
                if len(prod_data['pesos']) == len(instances):
                    pesos = prod_data['pesos']
                    for i in range(len(instances)):
                        instances[i].peso = pesos[i]
                        db.session.commit()
                else:
                    return jsonify({'status': False, 'message': 'Valores ingresado no corresponden al total guardado en la BD'})
                
                if len(prod_data['durezas']) == len(instances):
                    durezas = prod_data['durezas']
                    for i in range(len(instances)):
                        instances[i].dureza = durezas[i]
                        db.session.commit()
                else:
                    return jsonify({'status': False, 'message': 'Valores ingresado no corresponden al total guardado en la BD'})
                
                return jsonify({'status': True, 'message': 'Muestra guardado con exito'})
            else:
                return jsonify({'status': False, 'message': 'Usuario rechazado: tipo de usuario no aceptado'})
        else:
            return jsonify({'status': False, 'message': 'Usuario no encontrado'})
    except Exception as e:
        db.session.rollback()
        return jsonify({'status': False, 'message': 'Operation not permitted', 'error': str(e)})


#curl -X POST https://5000-idx-dback-1731507916069.cluster-ve345ymguzcd6qqzuko2qbxtfe.cloudworkstations.dev/register -H "Content-Type: application/json" -d "{\"id_empleado\":\"2\", \"nombre_usuario\":\"john_doe_2\", \"contrasena\":\"123\"}"
@app.route('/register', methods=['POST'])  #añadir nuevo usuario a la BD
def register():
    try:
        prod_data = request.get_json(force=True)
        #hashed_password = bcrypt.generate_password_hash(prod_data['contrasena']).decode('utf-8')
        
        u = Usuario()
        u.nombre_usuario = prod_data['nombre_usuario']
        #u.contrasena = hashed_password
        u.set_password(prod_data['contrasena'])
        u.id_empleado = prod_data['id_empleado']

        db.session.add(u)
        db.session.commit()
        return jsonify({'status': True, 'message': 'Registro de usuario exitoso'})
            
    except Exception as e:
        db.session.rollback()
        return jsonify({'status': False, 'message': 'Operation not permitted', 'error': str(e)})


#curl -X POST http://127.0.0.1:5000/logout -H
@app.route('/logout', methods=['POST'])
def logout():
    if request.method == 'POST':
        session.clear()
        return jsonify({'status': True, 'message': 'Cierre de sesion exitoso'})
    else:
        return jsonify({'status': False, 'message': 'Metodo no permitido'})


#GET /listMezclas?start_date=2000-01-01&end_date=2024-12-30
@app.route('/listMezclas', methods=['GET'])   #traer mezclas por fecha de producción, con su estado de analisis
def list_mezclas():
    try:
        start_date = request.args.get('start_date')
        end_date = request.args.get('end_date')
        
        if not start_date or not end_date:
            return jsonify({'status': False, 'message': 'Fecha de inicio y de fin no especificadas'}), 400

        # Convertir las fechas desde strings a objetos de fecha
        start_date = datetime.strptime(start_date, '%Y-%m-%d').date()
        end_date = datetime.strptime(end_date, '%Y-%m-%d').date()
        
        lista_mezclas = []

        subquery = (
            db.session.query(
                OperadorReceta.nro_receta,
                func.group_concat(func.concat(Empleado.nombre, ' ', Empleado.apellido)).label('operadores')
            )
            .join(Empleado, OperadorReceta.id_operador == Empleado.id)  # Join con Empleado
            .group_by(OperadorReceta.nro_receta)  # Agrupamos por nro_receta
            .subquery()  # Convertir a subconsulta
        )

        # Consulta principal
        mezclas = (
            db.session.query(
                Mezcla.nro_lote,
                Mezcla.fecha,
                func.coalesce(AnalisisParametrosQuimicos.aprobada, None).label('aprobada'),
                subquery.c.operadores  # Traemos la columna operadores de la subconsulta
            )
            .join(subquery, Mezcla.nro_receta == subquery.c.nro_receta)  # Unir con la subconsulta por nro_receta
            .outerjoin(AnalisisParametrosQuimicos)  # Outerjoin con AnalisisParametrosQuimicos
            .filter(Mezcla.fecha >= start_date, Mezcla.fecha <= end_date)  # Filtro por fechas
            .group_by(Mezcla.nro_lote, Mezcla.fecha, subquery.c.operadores, AnalisisParametrosQuimicos.aprobada)  # Agrupamos por los campos de Mezcla y los operadores
            .order_by(Mezcla.fecha.asc())  # Orden por fecha
            .all()
        )

        for mezcla in mezclas:
            operadores = mezcla.operadores.split(",") if mezcla.operadores else []  # Separar por coma y espacio
            mezcla_dict = {
                "nro_lote": mezcla.nro_lote,
                "fecha": mezcla.fecha,
                "aprobada": mezcla.aprobada,
                "operadores": operadores  # Convertimos la cadena en lista
            }
            lista_mezclas.append(mezcla_dict)
        
        return jsonify(lista_mezclas)
        
    except ValueError as e:
        return jsonify({'status': False, 'message': f'Error in date format: {str(e)}'}), 400
    except Exception as e:
        return jsonify({'status': False, 'message': str(e)}), 500


#GET /listLoteAnalisisParametrosQuimicos?nro_lote=33
# Ruta GET para obtener los registros de ProductoTerminado filtrados por nro_lote
@app.route('/listLoteAnalisisParametrosQuimicos', methods=['GET'])
def list_lote_analisis_parametros_quimicos():
    try:
        # Obtener el parámetro 'nro_lote' de la query string
        nro_lote = request.args.get('nro_lote')
        # Si se proporciona nro_lote, filtrar los registros
        if nro_lote:
            analisis_parametros_quimicos = db.session.query(AnalisisParametrosQuimicos).filter(AnalisisParametrosQuimicos.nro_lote == nro_lote).all()
        else:
            return jsonify({'status': False, 'message': 'Debe seleccionar un número de lote'})
        # Lista para almacenar los registros serializados
        lista_analisis = []
        # Iterar sobre los registros y crear una lista con la estructura que se requiere
        for analisis in analisis_parametros_quimicos:
            lista_analisis.append({
                'id': analisis.id,
                'nro_lote': analisis.nro_lote,
                'aprobada': analisis.aprobada,
                'fecha': analisis.fecha.strftime('%Y-%m-%d'),
                'NH4': analisis.NH4,
                'AIP': analisis.AIP,
                'observaciones': analisis.observaciones
            })
        # Devolver los datos en formato JSON
        return jsonify(lista_analisis)
    except Exception as e:
        return jsonify({'status': False, 'message': 'Operation not permitted', 'error': str(e)})



#GET /listLoteProductoTerminado?nro_lote=33
# Ruta GET para obtener los registros de ProductoTerminado filtrados por nro_lote
@app.route('/listLoteProductoTerminado', methods=['GET'])
def list_lote_producto_terminado():
    try:
        # Obtener el parámetro 'nro_lote' de la query string
        nro_lote = request.args.get('nro_lote')

        # Si se proporciona nro_lote, filtrar los registros
        if nro_lote:
            productos = db.session.query(ProductoTerminado).filter(ProductoTerminado.nro_lote == nro_lote).all()
        else:
            # Si no se proporciona nro_lote, traer todos los registros
            return jsonify({'status': False, 'message': 'Debe seleccionar un número de lote'})

        # Lista para almacenar los registros serializados
        lista_productos = []

        # Iterar sobre los registros y crear una lista con la estructura que se requiere
        for producto in productos:
            lista_productos.append({
                'id': producto.id,
                'nro_lote': producto.nro_lote,
                'observaciones': producto.observaciones,
                'cod_producto': producto.cod_producto,
                'id_turno': producto.id_turno,
                'fecha': producto.fecha.strftime('%Y-%m-%d'),  # Formato de fecha
                'id_operador': producto.id_operador,
                'id_maquina': producto.id_maquina,
                'cantidad': producto.cantidad,
            })

        # Devolver los datos en formato JSON
        return jsonify(lista_productos)

    except Exception as e:
        return jsonify({'status': False, 'message': 'Operation not permitted', 'error': str(e)})
    

#GET /listProductoTerminado?start_date=2000-01-01&end_date=2024-12-30
@app.route('/listProductoTerminado', methods=['GET'])   #traer lotes por fecha de producción, con su estado de analisis
def list_producto_terminado():
    try:
        start_date = request.args.get('start_date')
        end_date = request.args.get('end_date')
        
        if not start_date or not end_date:
            return jsonify({'status': False, 'message': 'Fecha de inicio y de fin no especificadas'}), 400

        # Convertir las fechas desde strings a objetos de fecha
        start_date = datetime.strptime(start_date, '%Y-%m-%d').date()
        end_date = datetime.strptime(end_date, '%Y-%m-%d').date()
        
        lista_lotes = []

        lotes = (
            db.session.query(ProductoTerminado.nro_lote,
                            ProductoTerminado.fecha,
                            func.coalesce(func.sum(Autorizacion.cantidad), 0).label('cantidad_aprobada'),
                            func.coalesce(func.sum(Rechazo.cantidad), 0).label('cantidad_rechazada'))
            .outerjoin(LoteProductoTerminadoAnalisis)
            .outerjoin(AnalisisProductoTerminado)
            .outerjoin(Autorizacion, Autorizacion.id_analisis_producto_terminado == AnalisisProductoTerminado.id)
            .outerjoin(Rechazo, Rechazo.id_analisis_producto_terminado == AnalisisProductoTerminado.id)
            .filter(ProductoTerminado.fecha >= start_date, ProductoTerminado.fecha <= end_date)
            .group_by(ProductoTerminado.nro_lote, ProductoTerminado.fecha)  # Agrupando por nro_lote
            .order_by(ProductoTerminado.fecha.asc())
            .all()
        )

        #for nro_lote, fecha, cantidad_aprobada, cantidad_rechazada in lotes:
        for lote in lotes:
            if lote.cantidad_aprobada:
                # Si tiene tanto cantidad_aprobada como cantidad_rechazada
                if lote.cantidad_rechazada:
                    lista_lotes.append({
                        'nro_lote': lote.nro_lote,
                        'estado': "Parcialmente Aprobado",
                        'cantidad_aprobada': lote.cantidad_aprobada,
                        'cantidad_rechazada': lote.cantidad_rechazada,
                        'fecha_produccion': lote.fecha.isoformat()
                    })
                else:
                    # Solo aprobados, sin rechazo
                    lista_lotes.append({
                        'nro_lote': lote.nro_lote,
                        'estado': "Aprobado",
                        'cantidad_aprobada': lote.cantidad_aprobada,
                        'cantidad_rechazada': None,
                        'fecha_produccion': lote.fecha.isoformat()
                    })
            elif lote.cantidad_rechazada:
                lista_lotes.append({
                    'nro_lote': lote.nro_lote,
                    'estado': "Rechazado",
                    'cantidad_aprobada': None,
                    'cantidad_rechazada': lote.cantidad_rechazada,
                    'fecha_produccion': lote.fecha.isoformat()
                })
            else:
                lista_lotes.append({
                    'nro_lote': lote.nro_lote,
                    'estado': "No analizado",
                    'cantidad_aprobada': None,
                    'cantidad_rechazada': None,
                    'fecha_produccion': lote.fecha.isoformat()
                })

        return jsonify(lista_lotes)
        
    except ValueError as e:
        return jsonify({'status': False, 'message': f'Error in date format: {str(e)}'}), 400
    except Exception as e:
        return jsonify({'status': False, 'message': str(e)}), 500


@app.route('/addProducto', methods=['POST'])  #añadir nuevo tipo de producto a la BD
def add_producto():
    try:
        prod_data = request.get_json(force=True)
        
        if 'empleado_id' in session:
            if session.get('empleado_id_seccion') == 2 or session.get('empleado_id_cargo') == 4:
                p = Producto()
                p.cod_producto = prod_data['cod_producto']
                p.nombre = prod_data['nombre']

                db.session.add(p)
                db.session.commit()
                return jsonify({'status': True, 'message': 'Ingreso de producto guardado con exito'})
            else:
                return jsonify({'status': False, 'message': 'Usuario rechazado: tipo de usuario no aceptado'})
        else:
            return jsonify({'status': False, 'message': 'Usuario no encontrado'})
    except Exception as e:
        db.session.rollback()
        return jsonify({'status': False, 'message': 'Operation not permitted', 'error': str(e)})
    
#GET http://localhost:5000/listPromedioMuestra?nro_lote=1&nro_muestra=1
@app.route('/listPromedioMuestra', methods=['GET'])  #trae todos las muestras, por nro_lote y nro_muestra
def list_promedio_muestra():
    try:
        nro_lote = request.args.get('nro_lote')
        nro_muestra = request.args.get('nro_muestra')

        producto_terminado = ProductoTerminado.query.filter_by(nro_lote=nro_lote).first()
        lote_producto_terminado_analisis = LoteProductoTerminadoAnalisis.query.filter_by(id_producto_terminado=producto_terminado.id).first()

        if lote_producto_terminado_analisis is None:
            return jsonify({'status': False, 'message': 'El lote ingresado no tiene parametros registrados'})

        producto = Producto.query.filter(
            Producto.cod_producto == producto_terminado.cod_producto
        ).first()

        operador = Empleado.query.filter(
            Empleado.id == producto_terminado.id_operador
        ).all()

        maquina = Maquina.query.filter(
            Maquina.id == producto_terminado.id_maquina
        ).all()

        producto_terminado_cantidad_sumada = ProductoTerminado.query \
        .filter_by(nro_lote=nro_lote) \
        .with_entities(func.sum(ProductoTerminado.cantidad).label('total_cantidad')) \
        .scalar()

        analisis_producto_terminado = AnalisisProductoTerminado.query.filter(
            AnalisisProductoTerminado.id == lote_producto_terminado_analisis.id_analisis_producto_terminado
        ).first()
        
        muestra_parametros_fisicos = MuestraParametrosFisicos.query.filter(
            MuestraParametrosFisicos.id_analisis_producto_terminado == lote_producto_terminado_analisis.id_analisis_producto_terminado,
            MuestraParametrosFisicos.nro_muestra == nro_muestra
        ).first()

        promedio_peso_tableta = MuestraTableta.query.filter_by(
            id_muestra_parametros_fisicos=muestra_parametros_fisicos.id
        ).with_entities(
            func.avg(MuestraTableta.peso)
        ).scalar()

        promedio_dureza_tableta = MuestraTableta.query.filter_by(
            id_muestra_parametros_fisicos=muestra_parametros_fisicos.id
        ).with_entities(
            func.avg(MuestraTableta.dureza)
        ).scalar()

        data = {
            "fecha": analisis_producto_terminado.fecha,
            "peso_neto": muestra_parametros_fisicos.peso_neto,
            "fracturado": muestra_parametros_fisicos.fracturado,
            "polvo": muestra_parametros_fisicos.polvo,
            "promedio_peso_tableta": promedio_peso_tableta,
            "promedio_dureza_tableta": promedio_dureza_tableta,
            "nombre_producto": producto.nombre,
            #"cod_productos": ', '.join([p.cod_producto for p in producto_terminado])
            "operadores": ', '.join([f"{o.nombre} {o.apellido}" for o in operador]),
            "maquinas": ', '.join([m.nombre for m in maquina]),
            "cantidad": producto_terminado_cantidad_sumada
        }
        #return jsonify(data)
        #return jsonify({'status': True}, data)
        return jsonify({'status': True, 'data': data})
    except Exception as e:
        return jsonify({'status': False, 'message': 'Operation not permitted', 'error': str(e)})


#http://localhost:5000/listCodProducto?cod_producto=1
@app.route('/listCodProducto', methods=['GET'])
def list_cod_producto():
    try:
        # Obtener el parámetro 'cod_producto' de la query string
        cod_producto = request.args.get('cod_producto')

        # Si se proporciona cod_producto, filtrar los registros
        if cod_producto:
            tipo_producto = db.session.query(Producto).filter(Producto.cod_producto == cod_producto).all()
        else:
            # Si no se proporciona cod_producto, traer todos los registros
            tipo_producto = db.session.query(Producto).all()

        # Lista para almacenar los productos serializados
        lista_tipo_producto = []

        # Iterar sobre los registros y crear una lista con la estructura que se requiere
        for tp in tipo_producto:
            lista_tipo_producto.append({
                'cod_producto': tp.cod_producto,
                'nombre': tp.nombre
            })

        # Devolver los datos en formato JSON
        return jsonify(lista_tipo_producto)

    except Exception as e:
        return jsonify({'status': False, 'message': 'Operation not permitted', 'error': str(e)})



@app.route('/listTipoProducto', methods=['GET'])  #trae todos los formato de producto
def list_tipo_producto():
    try:
        lista_tipo_producto=[]
        tipo_producto = db.session.query(Producto).all()

        for tp in tipo_producto:
            lista_tipo_producto.append({
                'cod_producto': tp.cod_producto,
                'nombre': tp.nombre
            })
        return jsonify(lista_tipo_producto)
    except Exception as e:
        return jsonify({'status': False, 'message': 'Operation not permitted', 'error': str(e)})


@app.route('/listDeterminacion', methods=['GET'])  #trae todos los formato de producto
def list_determinacion():
    try:
        lista_determinacion=[]
        determinaciones = db.session.query(Determinacion).all()

        for d in determinaciones:
            lista_determinacion.append({
                'id': d.id,
                'nombre': d.nombre
            })
        return jsonify(lista_determinacion)
    except Exception as e:
        return jsonify({'status': False, 'message': 'Operation not permitted', 'error': str(e)})
    

@app.route('/listMaquina', methods=['GET'])  #trae todas las maquinas
def list_maquina():
    try:
        lista_maquinas=[]
        maquinas = db.session.query(Maquina).all()

        for m in maquinas:
            lista_maquinas.append({
                'id': m.id,
                'nombre': m.nombre
            })
        return jsonify(lista_maquinas)
    except Exception as e:
        return jsonify({'status': False, 'message': 'Operation not permitted', 'error': str(e)})
    

@app.route('/listTurno', methods=['GET'])  #trae todos los turnos
def list_turno():
    try:
        lista_turnos=[]
        turnos = db.session.query(Turno).all()

        for t in turnos:
            lista_turnos.append({
                'id': t.id,
                'tipo': t.tipo
            })
        return jsonify(lista_turnos)
    except Exception as e:
        return jsonify({'status': False, 'message': 'Operation not permitted', 'error': str(e)})


@app.route('/listIngredienteActivo', methods=['GET'])  #trae todos los ingredientes activos
def list_ingrediente_activo():
    try:
        lista_ingrediente_activo=[]
        ingredientes_activos = db.session.query(IngredienteActivo).all()

        for ai in ingredientes_activos:
            lista_ingrediente_activo.append({
                'id': ai.id,
                'nombre': ai.nombre
            })
        return jsonify(lista_ingrediente_activo)
    except Exception as e:
        return jsonify({'status': False, 'message': 'Operation not permitted', 'error': str(e)})
    

@app.route('/listNroReceta', methods=['GET'])  #trae todas las recetas
def list_nro_receta():
    try:
        lista_nro_receta=[]
        recetas = db.session.query(RecetaMezcla).all()

        for tp in recetas:
            lista_nro_receta.append({
                'nro_receta': tp.nro_receta
            })
        return jsonify(lista_nro_receta)
    except Exception as e:
        return jsonify({'status': False, 'message': 'Operation not permitted', 'error': str(e)})


@app.route('/addEmpleado', methods=['POST'])  #añadir nuevo operador a la BD
def add_operador():
    try:
        prod_data = request.get_json(force=True)
        
        if 'empleado_id' in session:
            if session.get('empleado_id_seccion') == 2 or session.get('empleado_id_cargo') == 4:
                e = Empleado()
                e.nombre = prod_data['nombre']
                e.apellido = prod_data['apellido']
                e.id_cargo = prod_data['id_cargo']
                e.id_seccion = prod_data['id_seccion']

                db.session.add(e)
                db.session.commit()
                return jsonify({'status': True, 'message': 'Ingreso de operador guardado con exito'})
            else:
                return jsonify({'status': False, 'message': 'Usuario rechazado: tipo de usuario no aceptado'})
        else:
            return jsonify({'status': False, 'message': 'Usuario no encontrado'})
    except Exception as e:
        db.session.rollback()
        return jsonify({'status': False, 'message': 'Operation not permitted', 'error': str(e)})


#GET /listEmpleado?id_seccion=2
@app.route('/listEmpleado', methods=['GET'])  #trae los empleados filtrados por seccion
def list_empleado():
    try:
        id_seccion = int(request.args.get('id_seccion'))

        # Verificar si la sección existe (opcional)
        seccion = Seccion.query.get(id_seccion)
        if not seccion:
            return jsonify({'error': 'Sección no encontrada'}), 404
        
        lista_empleados=[]

        operadores = (
            db.session.query(Empleado)
            .filter(Empleado.id_seccion == id_seccion)
            .with_entities(
                Empleado.id,
                Empleado.nombre,
                Empleado.apellido
            ) 
            .order_by(Empleado.apellido.asc())  # Ordena por apellido
            .all()
        )

        for id, nombre, apellido in operadores:
            lista_empleados.append({
                'id': id,
                'nombre': nombre,
                'apellido': apellido
            })

        return jsonify(lista_empleados)
    
    except ValueError:
        return jsonify({'error': 'El ID de sección debe ser un número entero'}), 400
    except Exception as e:
        return jsonify({'error': f'Ocurrió un error al obtener los operadores: {str(e)}'}), 500


@app.route('/listLastProductoTerminado', methods=['GET'])  # Traer los últimos 5 registros de ProductoTerminado
def list_last_producto_terminado():
    try:
        # Consulta para obtener los últimos 5 elementos agregados por 'id'
        lista_lotes = []

        lotes = (
            db.session.query(ProductoTerminado.nro_lote,
                            ProductoTerminado.fecha,
                            func.coalesce(func.sum(Autorizacion.cantidad), 0).label('cantidad_aprobada'),
                            func.coalesce(func.sum(Rechazo.cantidad), 0).label('cantidad_rechazada'))
            .outerjoin(LoteProductoTerminadoAnalisis)
            .outerjoin(AnalisisProductoTerminado)
            .outerjoin(Autorizacion, Autorizacion.id_analisis_producto_terminado == AnalisisProductoTerminado.id)
            .outerjoin(Rechazo, Rechazo.id_analisis_producto_terminado == AnalisisProductoTerminado.id)
            .group_by(ProductoTerminado.nro_lote, ProductoTerminado.fecha, ProductoTerminado.id)  # Agregar id en GROUP BY
            .order_by(ProductoTerminado.id.desc())  # Ordenar por id de manera descendente
            .limit(5)  # Limitar a los 5 últimos
            .all()
        )

        # Procesar los datos obtenidos
        for lote in lotes:
            if lote.cantidad_aprobada:
                if lote.cantidad_rechazada:
                    lista_lotes.append({
                        'nro_lote': lote.nro_lote,
                        'estado': "Parcialmente Aprobado",
                        'cantidad_aprobada': lote.cantidad_aprobada,
                        'cantidad_rechazada': lote.cantidad_rechazada,
                        'fecha_produccion': lote.fecha.isoformat()
                    })
                else:
                    lista_lotes.append({
                        'nro_lote': lote.nro_lote,
                        'estado': "Aprobado",
                        'cantidad_aprobada': lote.cantidad_aprobada,
                        'cantidad_rechazada': None,
                        'fecha_produccion': lote.fecha.isoformat()
                    })
            elif lote.cantidad_rechazada:
                lista_lotes.append({
                    'nro_lote': lote.nro_lote,
                    'estado': "Rechazado",
                    'cantidad_aprobada': None,
                    'cantidad_rechazada': lote.cantidad_rechazada,
                    'fecha_produccion': lote.fecha.isoformat()
                })
            else:
                lista_lotes.append({
                    'nro_lote': lote.nro_lote,
                    'estado': "No analizado",
                    'cantidad_aprobada': None,
                    'cantidad_rechazada': None,
                    'fecha_produccion': lote.fecha.isoformat()
                })

        return jsonify(lista_lotes)

    except Exception as e:
        return jsonify({'status': False, 'message': str(e)}), 500


class EmpleadoForm(FlaskForm):
    nombre = StringField('Nombre', validators=[DataRequired(), Length(min=3, max=50)])
    apellido = StringField('Apellido', validators=[DataRequired(), Length(min=3, max=50)])
    # Crear un SelectField para id_cargo que obtendrá los cargos de la base de datos
    id_cargo = SelectField('Cargo', validators=[DataRequired()])
    # Crear un SelectField para id_seccion que obtendrá las secciones de la base de datos
    id_seccion = SelectField('Sección', validators=[DataRequired()])

    def __init__(self, *args, **kwargs):
        super(EmpleadoForm, self).__init__(*args, **kwargs)
        
        # Obtener todas las secciones de la base de datos y mostrar por pantalla
        secciones = Seccion.query.all()
        seccion_lista = [(seccion.id, f"{seccion.nombre}") for seccion in secciones]
        self.id_seccion.choices = seccion_lista

        # Obtener todos los cargos de la base de datos y mostrar por pantalla
        cargos = Cargo.query.all()
        cargo_lista = [(cargo.id, f"{cargo.nombre}") for cargo in cargos]
        self.id_cargo.choices = cargo_lista

# Vista personalizada de Flask-Admin para Empleado
class EmpleadoModelView(ModelView):
    # Método para controlar el acceso a la vista
    def is_accessible(self):
        # Verificar si el id_usuario en la sesión es 7
        if session.get('id_usuario') == 7:
            return True
        return False
    # Configuración del formulario y acciones
    form = EmpleadoForm
    can_create = True
    can_edit = True
    can_delete = True

# Crear un formulario personalizado para la creación de usuarios
class UsuarioForm(FlaskForm):
    nombre_usuario = StringField('Nombre de Usuario', validators=[DataRequired(), Length(min=3, max=50)])
    contrasena = PasswordField('Contraseña', validators=[DataRequired(), Length(min=6)])
    
    # Crear un SelectField para id_empleado que obtendrá los empleados de la base de datos
    id_empleado = SelectField('Empleado', validators=[DataRequired()])

    def __init__(self, *args, **kwargs):
        super(UsuarioForm, self).__init__(*args, **kwargs)
        
        # Obtener los empleados de la base de datos
        empleados = Empleado.query.all()  # Obtener todos los empleados
        # Crear una lista de tuplas (id_empleado, nombre completo)
        empleados_lista = [(empleado.id, f"{empleado.nombre} {empleado.apellido}") for empleado in empleados]
        
        # Establecer las opciones del campo SelectField
        self.id_empleado.choices = empleados_lista

# Vista personalizada de Flask-Admin para Usuario del sistema
class UsuarioModelView(ModelView):
    # Método para controlar el acceso a la vista
    def is_accessible(self):
        # Verificar si el id_usuario en la sesión es 7
        if session.get('id_usuario') == 7:
            return True
        return False
    # Configuración del formulario y acciones
    form = UsuarioForm
    def on_model_change(self, form, model, is_created):
        """Cifrar la contraseña antes de guardarla"""
        if is_created or form.contrasena.data:  # Si es un nuevo usuario o se ha cambiado la contraseña
            model.set_password(form.contrasena.data)  # Llamar a set_password para encriptar la contraseña
        return super(UsuarioModelView, self).on_model_change(form, model, is_created)

class RecetaMezclaForm(FlaskForm):
    #nro_receta = StringField('Número de Receta', validators=[DataRequired()])
    nro_receta = StringField('Número de Receta', validators=[DataRequired()], render_kw={'readonly': False}) 
    fecha_fabricacion = StringField('Fecha de Fabricación', validators=[DataRequired()])
    cantidad_ingrediente_activo = StringField('Cantidad Ingrediente Activo', validators=[DataRequired()])
    carbamato_de_amonio = StringField('Carbamato de Amonio', validators=[DataRequired()])
    sulfato_de_bario = StringField('Sulfato de Bario', validators=[DataRequired()])
    grafito = StringField('Grafito', validators=[DataRequired()])
    estearato_de_zinc = StringField('Estearato de Zinc', validators=[DataRequired()])

    # Crear un SelectField para id_ingrediente_activo que obtendrá los ingredintes activos de la base de datos
    id_ingrediente_activo = SelectField('Ingrediente Activo', validators=[DataRequired()])

    def __init__(self, *args, **kwargs):
        super(RecetaMezclaForm, self).__init__(*args, **kwargs)
        
        # Obtener los ingrediente activos de la base de datos
        ingredientes = IngredienteActivo.query.all()  # Obtener todos los empleados
        # Crear una lista de tuplas (id_empleado, nombre completo)
        ingredientes_lista = [(ingrediente_activo.id, f"{ingrediente_activo.nombre}") for ingrediente_activo in ingredientes]
        
        # Establecer las opciones del campo SelectField
        self.id_ingrediente_activo.choices = ingredientes_lista

# Vista personalizada de Flask-Admin para RecetaMezcla
class RecetaMezclaModelView(ModelView):
    # Método para controlar el acceso a la vista
    def is_accessible(self):
        # Verificar si el id_usuario en la sesión es 7 (o cualquier otro valor que desees)
        if session.get('id_usuario') == 7:
            return True
        return False
    # Configuración del formulario y acciones
    form = RecetaMezclaForm
    can_create = False
    can_edit = True
    can_delete = True
     # Configuración para que el campo 'nro_receta' sea visible en la tabla
    column_list = ('nro_receta', 'fecha_fabricacion', 'id_ingrediente_activo', 'cantidad_ingrediente_activo', 'carbamato_de_amonio', 'sulfato_de_bario', 'grafito', 'estearato_de_zinc')

#Crear formulario Mezcla
class MezclaForm(FlaskForm):
    nro_lote_parafinado = StringField('Número de Lote Parafinado', validators=[DataRequired()])
    fecha = DateField('Fecha preparación', validators=[DataRequired()])
    nro_receta = StringField('Número de Receta', validators=[DataRequired()])
    nro_lote = StringField('Número de Lote', validators=[DataRequired()])

# Vista personalizada de Flask-Admin para Mezcla
class MezclaModelView(ModelView):
    # Método para controlar el acceso a la vista
    def is_accessible(self):
        # Verificar si el id_usuario en la sesión es 7 (o cualquier otro valor que desees)
        if session.get('id_usuario') == 7:
            return True
        return False
    # Configuración del formulario y acciones
    form = MezclaForm
    can_create = False
    can_edit = True
    can_delete = True
    column_list = ['nro_lote_parafinado', 'fecha', 'nro_receta', 'nro_lote']

# Vista personalizada de Flask-Admin para Muestra Parametros Fisicos
class MuestraParametrosFisicosModelView(ModelView):
    # Método para controlar el acceso a la vista
    def is_accessible(self):
        # Verificar si el id_usuario en la sesión es 7 (o cualquier otro valor que desees)
        if session.get('id_usuario') == 7:
            return True
        return False
    # Configuración del formulario y acciones
    form_columns = ['nro_muestra', 'id_analisis_producto_terminado', 'polvo', 'fracturado', 'peso_neto']
    can_create = False
    can_edit = True
    can_delete = True

# Vista personalizada de Flask-Admin para Mueestra tableta
class MuestraTabletaModelView(ModelView):
    # Método para controlar el acceso a la vista
    def is_accessible(self):
        # Verificar si el id_usuario en la sesión es 7 (o cualquier otro valor que desees)
        if session.get('id_usuario') == 7:
            return True
        return False
    # Configuración del formulario y acciones
    #form_columns = ['nro_muestra', 'id_analisis_producto_terminado', 'polvo', 'fracturado', 'peso_neto']
    can_create = False
    can_edit = True
    can_delete = True


# Crear el panel de administración
admin = Admin(app, name='Panel de Administración', template_mode='bootstrap4')
admin.add_view(EmpleadoModelView(Empleado, db.session))
admin.add_view(UsuarioModelView(Usuario, db.session))
admin.add_view(RecetaMezclaModelView(RecetaMezcla, db.session))
admin.add_view(MezclaModelView(Mezcla, db.session))
admin.add_view(MuestraParametrosFisicosModelView(MuestraParametrosFisicos, db.session))
admin.add_view(MuestraTabletaModelView(MuestraTableta, db.session))



if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
    app.run(ssl_context='adhoc')

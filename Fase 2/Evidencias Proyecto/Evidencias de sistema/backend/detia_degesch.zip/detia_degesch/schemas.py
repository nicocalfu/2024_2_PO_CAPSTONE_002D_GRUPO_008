# schemas.py
from main import Marshmallow, fields, Schema, post_load, ValidationError, validates
from main import SQLAlchemyAutoSchema
from marshmallow.validate import Range
#importacion de models
from models import IngredienteActivo, Maquina, Empleado, Producto, Turno, RecetaMezcla, OperadorReceta, Mezcla, AnalisisParametrosQuimicos, ProductoTerminado, AnalisisProductoTerminado, LoteProductoTerminadoAnalisis, MuestraParametrosFisicos, MuestraTableta, Autorizacion, Rechazo, Seccion, Cargo, Usuario, Determinacion

#ma = Marshmallow()

class IngredienteActivoSchema(SQLAlchemyAutoSchema):
    class Meta:
        model = IngredienteActivo
        include_relationships = True
        load_instance = True

class MaquinaSchema(SQLAlchemyAutoSchema):
    class Meta:
        model = Maquina
        include_relationships = True
        load_instance = True

class SeccionSchema(SQLAlchemyAutoSchema):
    class Meta:
        model = Seccion
        include_relationships = True
        load_instance = True

class CargoSchema(SQLAlchemyAutoSchema):
    class Meta:
        model = Cargo
        include_relationships = True
        load_instance = True

class EmpleadoSchema(SQLAlchemyAutoSchema):
    seccion = fields.Nested('SeccionSchema', exclude=('empleado',))
    cargo = fields.Nested('CargoSchema', exclude=('empleado',))
    
    class Meta:
        model = Empleado
        include_relationships = True
        load_instance = True

class UsuarioSchema(SQLAlchemyAutoSchema):
    empleado = fields.Nested('EmpleadoSchema', exclude=('usuario',))

    class Meta:
        model = Usuario
        include_relationships = True
        load_instance = True

class ProductoSchema(SQLAlchemyAutoSchema):
    class Meta:
        model = Producto
        include_relationships = True
        load_instance = True

class TurnoSchema(SQLAlchemyAutoSchema):
    class Meta:
        model = Turno
        include_relationships = True
        load_instance = True

class RecetaMezclaSchema(SQLAlchemyAutoSchema):
    #ingrediente_activo = fields.Nested('IngredienteActivoSchema', exclude=('recetas',))
    class Meta:
        model = RecetaMezcla
        include_relationships = True
        load_instance = True
    id_ingrediente_activo = fields.Integer(required=True)
    id_operadores = fields.List(fields.Integer(), required=True)  # Esto es para una lista de ids de operadores
    cantidad_ingrediente_activo = fields.Float(required=True, validate=Range(min=0, max=200))  # Validación para evitar números negativos
    carbamato_de_amonio = fields.Float(required=True, validate=Range(min=0, max=25))  # Validación para evitar números negativos
    sulfato_de_bario = fields.Float(required=True, validate=Range(min=0, max=25))
    grafito = fields.Float(required=True, validate=Range(min=0, max=25))
    estearato_de_zinc = fields.Float(required=True, validate=Range(min=0, max=25))
    # Lanzar exception personalizado:
    """
    @validates('cantidad_ingrediente_activo')
    def validate_cantidad_ingrediente_activo(self, value):
        if value < 0:
            raise ValidationError("La cantidad de ingrediente activo no puede ser negativa.")
    """

class OperadorRecetaSchema(SQLAlchemyAutoSchema):
    receta_mezcla = fields.Nested('RecetaMezclaSchema', exclude=('operador_receta',))
    empleado = fields.Nested('EmpleadoSchema', exclude=('operador_receta',))

    class Meta:
        model = OperadorReceta
        include_relationships = True
        load_instance = True

class MezclaSchema(SQLAlchemyAutoSchema):
    #receta_mezcla = fields.Nested('RecetaMezclaSchema', exclude=('mezcla',))
    #class Meta:
    #    model = Mezcla
    #    include_relationships = True
    #    load_instance = True
    nro_receta = fields.Integer(required=True)
    fecha = fields.String(required=True)
    lotes = fields.List(fields.String(), required=True)
    lotes_parafinado = fields.List(fields.String(), required=True)


class AnalisisParametrosQuimicosSchema(SQLAlchemyAutoSchema):
    nro_lote = fields.String(required=True)
    fecha = fields.String(required=True)
    aprobada = fields.Boolean(required=True)
    NH4 = fields.Integer(required=True)
    AIP = fields.Integer(required=True)
    observaciones = fields.String(required=True)
    """
    mezcla = fields.Nested('MezclaSchema', exclude=('analisis_parametros_quimicos',))
    empleado = fields.Nested('EmpleadoSchema', exclude=('analisis_parametros_quimicos',))
    class Meta:
        model = AnalisisParametrosQuimicos
        include_relationships = True
        load_instance = True
    """

class ProductoTerminadoSchema(SQLAlchemyAutoSchema):
    """
    mezcla = fields.Nested('MezclaSchema', exclude=('producto_terminado',))
    producto = fields.Nested('ProductoSchema', exclude=('producto_terminado',))
    turno = fields.Nested('TurnoSchema', exclude=('producto_terminado',))
    empleado = fields.Nested('EmpleadoSchema', exclude=('producto_terminado',))
    maquina = fields.Nested('MaquinaSchema', exclude=('producto_terminado',))
    """
    class Meta:
        model = ProductoTerminado
        include_relationships = True
        load_instance = True
    nro_lote = fields.String(required=True)
    fecha = fields.String(required=True)
    id_turno = fields.Integer(required=True)
    id_operador = fields.Integer(required=True)
    id_maquina = fields.Integer(required=True)
    cod_producto = fields.String(required=True)

class AnalisisProductoTerminadoSchema(SQLAlchemyAutoSchema):
    producto_terminado = fields.Nested('ProductoTerminadoSchema', exclude=('lote_producto_terminado_analisis',))
    turno = fields.Nested('TurnoSchema', exclude=('analisis_producto_terminado',))
    empleado = fields.Nested('EmpleadoSchema', exclude=('analisis_producto_terminado',))

    class Meta:
        model = AnalisisProductoTerminado
        include_relationships = True
        load_instance = True

class AddAutorizacionSchema(Schema):
    nro_lote = fields.String(required=True)  # Siempre obligatorio
    id_determinacion = fields.Integer(required=True)  # Siempre obligatorio
    numero_autorizacion = fields.Integer()
    cantidad_aprobada = fields.Integer()
    numero_rechazo = fields.Integer()
    cantidad_rechazada = fields.Integer()
    causa = fields.String()

    @validates('id_determinacion')
    def validate_id_determinacion(self, value):
        """
        Validación general de 'id_determinacion' (para comprobar que tiene un valor esperado).
        """
        if value not in [1, 2, 3]:
            raise ValidationError('El campo id_determinacion debe ser 1, 2 o 3.')

    @post_load
    def validate_required_fields(self, data, **kwargs):
        """
        Aplica las validaciones condicionales basadas en el valor de 'id_determinacion'.
        """
        id_determinacion = data.get('id_determinacion')

        # Si 'id_determinacion' es 2, todos los campos son obligatorios
        if id_determinacion == 2:
            for field in ['numero_autorizacion', 'cantidad_aprobada', 'numero_rechazo', 'cantidad_rechazada', 'causa']:
                if data.get(field) is None:
                    raise ValidationError(f'El campo {field} es obligatorio cuando id_determinacion es 2.')

        # Si 'id_determinacion' es 1, solo 'numero_autorizacion' y 'cantidad_aprobada' son obligatorios
        elif id_determinacion == 1:
            if data.get('numero_autorizacion') is None:
                raise ValidationError('El campo numero_autorizacion es obligatorio cuando id_determinacion es 1.')
            if data.get('cantidad_aprobada') is None:
                raise ValidationError('El campo cantidad_aprobada es obligatorio cuando id_determinacion es 1.')

        # Si 'id_determinacion' es 3, 'numero_rechazo', 'cantidad_rechazada' y 'causa' son obligatorios
        elif id_determinacion == 3:
            if data.get('numero_rechazo') is None:
                raise ValidationError('El campo numero_rechazo es obligatorio cuando id_determinacion es 3.')
            if data.get('cantidad_rechazada') is None:
                raise ValidationError('El campo cantidad_rechazada es obligatorio cuando id_determinacion es 3.')
            if data.get('causa') is None:
                raise ValidationError('El campo causa es obligatorio cuando id_determinacion es 3.')
                

class LoteProductoTerminadoAnalisisSchema(SQLAlchemyAutoSchema):
    producto_terminado = fields.Nested('ProductoTerminadoSchema', exclude=('lote_producto_terminado_analisis',))
    analisis_producto_terminado = fields.Nested('AnalisisProductoTerminadoSchema', exclude=('lote_producto_terminado_analisis',))

    class Meta:
        model = LoteProductoTerminadoAnalisis
        include_relationships = True
        load_instance = True

class MuestraParametrosFisicosSchema(SQLAlchemyAutoSchema):
    analisis_producto_terminado = fields.Nested('AnalisisProductoTerminadoSchema', exclude=('muestra_parametros_fisicos',))

    class Meta:
        model = MuestraParametrosFisicos
        include_relationships = True
        load_instance = True

class MuestraTabletaSchema(SQLAlchemyAutoSchema):
    muestra_parametros_fisicos = fields.Nested('MuestraParametrosFisicosSchema', exclude=('muestra_tableta',))

    class Meta:
        model = MuestraTableta
        include_relationships = True
        load_instance = True

class AutorizacionSchema(SQLAlchemyAutoSchema):
    analisis_producto_terminado = fields.Nested('AnalisisProductoTerminadoSchema', exclude=('autorizacion',))
    determinacion = fields.Nested('DeterminacionSchema', exclude=('autorizacion',))

    class Meta:
        model = Autorizacion
        include_relationships = True
        load_instance = True

class RechazoSchema(SQLAlchemyAutoSchema):
    analisis_producto_terminado = fields.Nested('AnalisisProductoTerminadoSchema', exclude=('rechazo',))
    determinacion = fields.Nested('DeterminacionSchema', exclude=('rechazo',))

    class Meta:
        model = Rechazo
        include_relationships = True
        load_instance = True

class DeterminacionSchema(SQLAlchemyAutoSchema):
    class Meta:
        model = Determinacion
        include_relationships = True
        load_instance = True
